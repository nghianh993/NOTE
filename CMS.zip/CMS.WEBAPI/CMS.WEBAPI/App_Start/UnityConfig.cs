using CMS.WEBAPI.BUSINESS.Implements;
using CMS.WEBAPI.BUSINESS.Interfaces;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace CMS.WEBAPI
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            container.RegisterType<ILoginService, LoginService>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}