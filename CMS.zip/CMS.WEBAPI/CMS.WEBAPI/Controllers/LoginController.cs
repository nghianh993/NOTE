﻿using CMS.WEBAPI.BUSINESS.Implements;
using CMS.WEBAPI.Jwt;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [AllowAnonymous]
    public class LoginController : ApiController
    {
        #region Initialize
        public readonly ILoginService _loginService;

        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        #endregion
        public IHttpActionResult Post([FromBody] LoginModel loginModel)
        {
            try
            {
                var userModel = _loginService.GetCurrentUser(loginModel.Username, loginModel.Password);
                if (userModel == null)
                    return Ok(new JwtResponseModel {
                        Access = "Tên đăng nhập hoặc mật khẩu không chính xác! Vui lòng kiểm tra lại.",
                        Type = "Bearer",
                        Name = loginModel.Username
                    });

                var jwt = JwtManager.GenerateToken(loginModel.Username);

                return Ok(new JwtResponseModel
                {
                    Access = jwt,
                    Type = "Bearer",
                    Name = loginModel.Username
                });
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
