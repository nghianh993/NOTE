USE [master]
GO
/****** Object:  Database [BEDATA]    Script Date: 8/11/2020 8:29:12 AM ******/
CREATE DATABASE [BEDATA]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'BEDATA', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL11.BOSS\MSSQL\DATA\BEDATA.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'BEDATA_log', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL11.BOSS\MSSQL\DATA\BEDATA_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [BEDATA] SET COMPATIBILITY_LEVEL = 110
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [BEDATA].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [BEDATA] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [BEDATA] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [BEDATA] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [BEDATA] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [BEDATA] SET ARITHABORT OFF 
GO
ALTER DATABASE [BEDATA] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [BEDATA] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [BEDATA] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [BEDATA] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [BEDATA] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [BEDATA] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [BEDATA] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [BEDATA] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [BEDATA] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [BEDATA] SET  DISABLE_BROKER 
GO
ALTER DATABASE [BEDATA] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [BEDATA] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [BEDATA] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [BEDATA] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [BEDATA] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [BEDATA] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [BEDATA] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [BEDATA] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [BEDATA] SET  MULTI_USER 
GO
ALTER DATABASE [BEDATA] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [BEDATA] SET DB_CHAINING OFF 
GO
ALTER DATABASE [BEDATA] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [BEDATA] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
USE [BEDATA]
GO
/****** Object:  Table [dbo].[Answer]    Script Date: 8/11/2020 8:29:12 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Answer](
	[AnswerId] [int] IDENTITY(1,1) NOT NULL,
	[AnswerName] [nvarchar](500) NULL,
	[AnswerType] [nvarchar](50) NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[Status] [int] NULL,
	[IsRightAnswer] [bit] NULL,
 CONSTRAINT [PK_Answer] PRIMARY KEY CLUSTERED 
(
	[AnswerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AnswerType]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AnswerType](
	[Type] [nvarchar](50) NOT NULL,
	[TypeName] [nvarchar](150) NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_AnswerType] PRIMARY KEY CLUSTERED 
(
	[Type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BalanceHistory]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BalanceHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Username] [nvarchar](50) NULL,
	[Amount] [decimal](18, 2) NULL,
	[Type] [int] NULL,
	[Status] [int] NULL,
	[CreatedDate] [datetime] NULL,
 CONSTRAINT [PK_BalanceHistory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Class]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Class](
	[ClassCode] [nvarchar](50) NOT NULL,
	[ClassName] [nvarchar](250) NULL,
	[Avatar] [nvarchar](500) NULL,
	[Price] [decimal](18, 2) NULL,
	[Status] [int] NULL,
	[BeginDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[MaxTotalStudent] [int] NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [datetime] NULL,
 CONSTRAINT [PK_Class] PRIMARY KEY CLUSTERED 
(
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Exam]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Exam](
	[ExamId] [int] IDENTITY(1,1) NOT NULL,
	[ExamName] [nvarchar](250) NULL,
	[PassPoint] [int] NOT NULL,
	[Status] [int] NULL,
	[CreateDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
 CONSTRAINT [PK_Exam] PRIMARY KEY CLUSTERED 
(
	[ExamId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ExamQuestionMapping]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ExamQuestionMapping](
	[ExamId] [int] NOT NULL,
	[QuestionId] [int] NOT NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_ExamQuestionMapping] PRIMARY KEY CLUSTERED 
(
	[ExamId] ASC,
	[QuestionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[List]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[List](
	[ListCode] [nvarchar](50) NULL,
	[ListName] [nvarchar](250) NULL,
	[ListType] [nvarchar](50) NULL,
	[Status] [bit] NULL,
	[Description] [nvarchar](250) NULL,
	[UserCreate] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LoginHistory]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginHistory](
	[Username] [nvarchar](50) NULL,
	[Uid] [varchar](100) NULL,
	[LoginTime] [datetime] NULL,
	[LoginStatus] [int] NULL,
	[Token] [nvarchar](1000) NULL,
	[Retoken] [nvarchar](1000) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Notification]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Notification](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[Message] [nvarchar](500) NULL,
	[Usercreate] [nvarchar](50) NOT NULL,
	[UserReceived] [nvarchar](50) NOT NULL,
	[DateCreate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[Type] [int] NOT NULL,
 CONSTRAINT [PK_Notification] PRIMARY KEY CLUSTERED 
(
	[MessageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Permission]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Permission](
	[PermistionId] [nvarchar](50) NOT NULL,
	[Description] [nchar](10) NULL,
	[Method] [varchar](10) NULL,
	[Url] [nvarchar](500) NULL,
	[Status] [int] NULL,
	[CreateDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Permission] PRIMARY KEY CLUSTERED 
(
	[PermistionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Question]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Question](
	[QuestionId] [int] IDENTITY(1,1) NOT NULL,
	[QuestionName] [nvarchar](50) NULL,
	[Level] [nvarchar](50) NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_Question] PRIMARY KEY CLUSTERED 
(
	[QuestionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Role](
	[RoleId] [varchar](50) NOT NULL,
	[RoleName] [nvarchar](100) NULL,
	[Description] [nvarchar](250) NULL,
	[CreatedDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RolePermissionMapping]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RolePermissionMapping](
	[RoleId] [nvarchar](50) NOT NULL,
	[PermissionId] [nvarchar](50) NOT NULL,
	[Usercreate] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL,
 CONSTRAINT [PK_RolePermissionMapping] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC,
	[PermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TeacherClass]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TeacherClass](
	[Username] [nvarchar](50) NOT NULL,
	[ClassCode] [nvarchar](50) NOT NULL,
	[IsTeacher] [bit] NULL,
	[DateCreate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
 CONSTRAINT [PK_TeacherClass] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TeacherOrStudentClass]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TeacherOrStudentClass](
	[Username] [nvarchar](50) NOT NULL,
	[ClassCode] [nvarchar](50) NOT NULL,
	[UserCreate] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL,
 CONSTRAINT [PK_TeacherOrStudentClass] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[Username] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](500) NULL,
	[Fullname] [nvarchar](100) NULL,
	[Gender] [nchar](10) NULL,
	[Birthday] [date] NULL,
	[Avatar] [nvarchar](250) NULL,
	[School] [nvarchar](100) NULL,
	[Address] [nchar](250) NULL,
	[Status] [int] NULL,
	[IsParents] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[LastLogin] [datetime] NULL,
	[Amount] [decimal](18, 2) NULL,
	[Type] [int] NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserExam]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserExam](
	[Username] [nvarchar](50) NOT NULL,
	[ExamId] [int] NOT NULL,
	[Score] [int] NULL,
	[IsPass] [bit] NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_UserExam] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[ExamId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserRoleMapping]    Script Date: 8/11/2020 8:29:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserRoleMapping](
	[Username] [nvarchar](50) NOT NULL,
	[RoleId] [varchar](50) NOT NULL,
	[Usercreated] [nvarchar](50) NOT NULL,
	[DateCreate] [datetime] NOT NULL,
 CONSTRAINT [PK_UserRoleMapping] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Phương thức thanh toán' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'BalanceHistory', @level2type=N'COLUMN',@level2name=N'Type'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Điểm tối thiểu được để hoàn thành' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Exam', @level2type=N'COLUMN',@level2name=N'PassPoint'
GO
USE [master]
GO
ALTER DATABASE [BEDATA] SET  READ_WRITE 
GO
