﻿using System;

namespace CMS.WEBAPI.MODEL
{
    public class PermissionModel
    {
        public string PermistionId { get; set; }
        public string Description { get; set; }
        public string Method { get; set; }
        public string Url { get; set; }
        public int Status { get; set; }
        public DateTime CreateDate { get; set; }
        public string ParentId { get; set; }
        public bool? IsMenu { get; set; }
        public int? Position { get; set; }
        public string Icon { get; set; }
    }
}
