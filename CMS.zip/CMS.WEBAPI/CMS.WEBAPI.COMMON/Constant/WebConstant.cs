﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Constant
{
    public static class WebConstant
    {
        //Static config
        public static string AUTHENTICATION_KEY = "AUTHENTICATION_KEY";

        //Webconfig
        public static string PAGESIZE = "PAGESIZE";
        public static string SECRETKEY = "SECRETKEY";
        public static string TIMEOUT_TOKEN = "TIMEOUT_TOKEN";
    }
}
