﻿using AutoMapper;
using CMS.WEBAPI.BASE;
using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Mappings
{
    public static class MapperHelper
    {
        private static readonly IMapper staticMapper;
        static MapperHelper()
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<User, UserModel>();
                cfg.CreateMap<Permission, PermissionModel>();
            });

            staticMapper = config.CreateMapper();
        }

        public static T MapFrom<T>(object entity)
        {
            return staticMapper.Map<T>(entity);
        }

        public static IMapperConfig GetMapperFor<TSource, TDestination>()
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<TSource, TDestination>();
            });

            var _mapper = config.CreateMapper();

            return new MappingConfig(_mapper);
        }

        public static TDestination Map<TDestination, TSource>(TSource entity)
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<TSource, TDestination>();
            });

            var _mapper = config.CreateMapper();

            return _mapper.Map<TDestination>(entity);
        }

        public static TDestination Map<TDestination, TSource>(List<TSource> entity)
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<TSource, TDestination>();
            });

            var _mapper = config.CreateMapper();

            return _mapper.Map<TDestination>(entity);
        }
    }
}
