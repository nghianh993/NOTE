﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/teacherClass")]
    [JwtAuthentication]
    public class TeacherClassController : ApiController
    {
        #region Initialize
        public readonly ITeacherClassService _teacherClassService;

        public TeacherClassController(ITeacherClassService teacherClassService)
        {
            _teacherClassService = teacherClassService;
        }
        #endregion
        
        [HttpGet]
        public IHttpActionResult GetAllTeacherClasses()
        {
            try
            {
                var listItems = _teacherClassService.GetTeacherClasses();
                if (listItems == null)
                {
                    return NotFound();
                }

                return Ok(listItems);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        [Route("getTeacherClassById")]
        public IHttpActionResult GetTeacherClassById([FromBody] TeacherClassModel model)
        {
            try
            {
                var item = _teacherClassService.GetTeacherClassById(model);
                if (item == null)
                {
                    return NotFound();
                }

                return Ok(item);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [HttpPost]
        [Route("getTeacherIdByClassId")]
        public IHttpActionResult GetTeacherIdByClassId([FromBody] TeacherClassModel model)
        {
            try
            {
                var item = _teacherClassService.GetTeacherIdByClassId(model);
                if (item == null)
                {
                    return NotFound();
                }

                return Ok(item);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Post([FromBody] TeacherClassModel model)
        {
            try
            {
                _teacherClassService.CreateTeacherClass(model);

                return Ok();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
       
        
        public IHttpActionResult Delete([FromBody] TeacherClassModel model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.ClassCode))
                {
                    return BadRequest();
                }
                var data = _teacherClassService.DeleteTeacherClass(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
