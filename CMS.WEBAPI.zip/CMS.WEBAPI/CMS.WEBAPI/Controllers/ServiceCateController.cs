﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/cate/service")]
    public class ServiceCateController : ApiController
    {
        private readonly IServiceService _serviceService;
        public ServiceCateController(IServiceService serviceService)
        {
            _serviceService = serviceService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] ServiceModel model)
        {
            try
            {
                var data = _serviceService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        [HttpPost]
        public IHttpActionResult Add([FromBody] ServiceModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _serviceService.Add(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] ServiceModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _serviceService.Update(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] ServiceModel model)
        {
            try
            {
                var data = _serviceService.LockOrUnlock(model.ids, model.Status ?? 0);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("list_by_type")]
        [HttpGet]
        public IHttpActionResult GetAllParent([FromUri] int type)
        {
            try
            {
                var data = _serviceService.GetAllByType(type);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("list_by_type_v2")]
        [HttpGet]
        public IHttpActionResult GetAllParentV2([FromUri] int type)
        {
            try
            {
                var data = _serviceService.GetAllByTypeV2(type);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}