﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/cate/question")]
    public class QuestionCateController : ApiController
    {
        private readonly IQuestionCateService _questionCateService;
        public QuestionCateController(IQuestionCateService questionCateService)
        {
            _questionCateService = questionCateService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] CateQuestionModel model)
        {
            try
            {
                var data = _questionCateService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        [HttpPost]
        public IHttpActionResult Add([FromBody] CateQuestionModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _questionCateService.Add(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] CateQuestionModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _questionCateService.Update(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] CateQuestionModel model)
        {
            try
            {
                var data = _questionCateService.LockOrUnlock(model.ids, (model.Status ?? 0));
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("get_parent")]
        [HttpGet]
        public IHttpActionResult GetAllParent()
        {
            try
            {
                var data = _questionCateService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}