﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/user")]
    public class UserController : ApiController
    {
        private readonly IUserService _userService;
        private readonly IUserClassService _userClassService;
        private readonly ITeacherClassService _teacherClassService;
        private readonly INotificationService _notificationService;
        public UserController(IUserService userService, IUserClassService userClassService, 
            ITeacherClassService teacherClassService, INotificationService notificationService)
        {
            _userService = userService;
            _userClassService = userClassService;
            _teacherClassService = teacherClassService;
            _notificationService = notificationService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] UserModel model)
        {
            try
            {
                var data = _userService.GetAllUser(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("list_staff")]
        [HttpPost]
        public IHttpActionResult ListStaff([FromBody] UserModel model)
        {
            try
            {
                var data = _userService.GetAllUserStaff(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("cash")]
        [HttpPost]
        public IHttpActionResult Cash([FromBody] CashModel model)
        {
            try
            {
                model.currentUser = Common.GetUsernameLogin();
                var data = _userService.Cash(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("get_all_role")]
        public IHttpActionResult Get()
        {
            try
            {
                var data = _userService.GetAllRoleActive();
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        [HttpPost]
        public IHttpActionResult Add([FromBody] UserModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _userService.Add(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] UserModel model)
        {
            try
            {
                model.UserCreated = Common.GetUsernameLogin();
                var data = _userService.Update(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] UserModel userModel)
        {
            try
            {
                var data = _userService.LockOrUnlock(userModel.userIds, (userModel.Status ?? 0));
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("change_info")]
        [HttpPost]
        public async Task<IHttpActionResult> ChangeInfo()
        {
            try
            {
                var provider = new MultipartMemoryStreamProvider();
                await Request.Content.ReadAsMultipartAsync(provider);
                var fileNameParam = provider.Contents[0].Headers.ContentDisposition.Parameters.FirstOrDefault(p => p.Name.ToLower() == "filename");
                string fileName = (fileNameParam == null) ? "" : fileNameParam.Value.Trim('"');
                var currentUser = Common.GetUsernameLogin();
                var avatarUrl = string.Empty;
                if (!string.IsNullOrEmpty(fileName))
                {
                    avatarUrl = WebUtils.GetAppSettingsConfigValue(WebConstant.URL_IMAGE) + @"/" + WebUtils.GetAppSettingsConfigValue(WebConstant.FOLDERUPOAD) + @"/" + currentUser + "_" + fileName;
                    var path = HttpContext.Current.Server.MapPath(@"~/" + WebUtils.GetAppSettingsConfigValue(WebConstant.FOLDERUPOAD)) + @"\" + currentUser + "_" + fileName;
                    byte[] file = await provider.Contents[0].ReadAsByteArrayAsync();
                    File.WriteAllBytes(path, file);
                }
                var data = HttpContext.Current.Request.Params["data"];
                var model = JsonConvert.DeserializeObject<UserModel>(data);
                model.Avatar = avatarUrl;
                model.Username = currentUser;
                var responseModel = _userService.ChangeInfo(model);
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("check_duplicate")]
        [HttpPost]
        public IHttpActionResult CheckDuplicate([FromBody] UserModel userModel)
        {
            try
            {
                var data = _userService.CheckDuplicateUser(userModel.Username);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("get_children")]
        [HttpGet]
        public IHttpActionResult GetAllChildren([FromUri] string user)
        {
            try
            {
                var data = _userService.GetAllChildren(user);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("get_info")]
        [HttpGet]
        public IHttpActionResult GetInfo()
        {
            try
            {
                var data = _userService.GetDetailUser(Common.GetUsernameLogin());
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("get_info_by_username")]
        [HttpGet]
        public IHttpActionResult GetInfobyUserName([FromUri] string username)
        {
            try
            {
                var data = _userService.GetDetailUser(username);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("getUsersNoClass")]
        [HttpPost]
        public IHttpActionResult GetUsersNoClass([FromBody] UserModel userModel)
        {
            try
            {
                var data = _userClassService.GetUsersNoClass(userModel);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("getUsersByClassCode")]
        [HttpPost]
        public IHttpActionResult GetUsersByClassCode([FromBody] UserModel model)
        {
            try
            {
                var data = _userClassService.GetUsersByClassCode(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("addUserToClass")]
        [HttpPost]
        public IHttpActionResult AddUserToClass([FromBody] StudentClassModel model)
        {
            try
            {
                model.UserCreate = Common.GetUsernameLogin();
                model.CreateDate = DateTime.Now;
                model.Status = (int)Status.ACTIVE;
                var data = _userClassService.AddStudentToClass(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("getTeachersNoClass")]
        [HttpPost]
        public IHttpActionResult GetTeachersNoClass([FromBody] UserModel model)
        {
            try
            {
                var data = _teacherClassService.GetTeachersNoClass(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("addTeacherToClass")]
        [HttpPost]
        public IHttpActionResult AddTeacherToClass([FromBody] TeacherClassModel model)
        {
            try
            {
                model.UserCreate = Common.GetUsernameLogin();
                model.DateCreate = DateTime.Now;
                var data = _teacherClassService.AddTeacherToClass(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("checkinStudent")]
        [HttpPost]
        public IHttpActionResult CheckinStudent([FromBody] CheckInRequestModel model)
        {
            try
            {
                var teacher = Common.GetUsernameLogin();
                var data = _userClassService.CheckInStudent(model, teacher);
                //Check success and send notification
                if(data.Success)
                {
                    foreach (var ci in model.CheckIns)
                    {
                        if(ci.Status == 0)
                        {
                            var userInfo = _userService.GetDetailUser(ci.StudentId);
                            var parentUser = _userService.GetParentUser(ci.StudentId);
                            if(parentUser != null && userInfo != null)
                            {
                                var message = string.Format("Hệ thống DWH xin thông báo học sinh \"{0}\" đã nghỉ học vào thời gian \"{1}\". Vui lòng liên hệ với trường để cập nhật thông tin. Xin cảm ơn!", 
                                    userInfo.Fullname, (ci.DateCheckIn ?? DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss"));
                                _notificationService.PushNotification(message, "system", parentUser.Username);
                                if(!string.IsNullOrEmpty(userInfo.UserCreated))
                                _notificationService.PushNotification(message, "system", userInfo.UserCreated);
                            }
                        }
                    }
                }
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("changePassword")]
        [HttpPost]
        public IHttpActionResult ChangePassword([FromBody] ChangePasswordModel model)
        {
            try
            {
                model.CurrentUser = Common.GetUsernameLogin();
                var data = _userService.ChangePassword(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("deleteStudent")]
        [HttpPost]
        public IHttpActionResult DeleteStudent([FromBody] StudentClassModel model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.StudentId) || string.IsNullOrEmpty(model.ClassId))
                {
                    return BadRequest();
                }
                var data = _userClassService.DeleteStudentClass(model);

                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("getCheckInStudentByClass")]
        [HttpPost]
        public IHttpActionResult GetCheckInStudent([FromBody] StudentClassModel model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.StudentId) || string.IsNullOrEmpty(model.ClassId))
                {
                    return BadRequest();
                }
                var data = _userClassService.GetCheckInUserByClassCode(model);

                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}