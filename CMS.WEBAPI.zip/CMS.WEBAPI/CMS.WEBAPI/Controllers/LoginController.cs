﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Jwt;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace CMS.WEBAPI.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/login")]
    public class LoginController : ApiController
    {
        #region Initialize
        public readonly ILoginService _loginService;

        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        #endregion
        [Route("")]
        public IHttpActionResult Post([FromBody] LoginModel loginModel)
        {
            try
            {
                var userModel = _loginService.GetCurrentUser(loginModel.Username, loginModel.Password);
                if (userModel == null)
                    return Ok(new JwtResponseModel {
                        Access = "Tên đăng nhập hoặc mật khẩu không chính xác! Vui lòng kiểm tra lại.",
                        Type = "Bearer",
                        Name = loginModel.Username,
                        Success = false,
                        Avatar = string.Empty
                    });

                var jwt = JwtManager.GenerateToken(userModel);

                return Ok(new JwtResponseModel
                {
                    Access = jwt,
                    Type = "Bearer",
                    Name = loginModel.Username,
                    Success = true,
                    Avatar = userModel.Avatar ?? string.Empty
                });
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
