﻿using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.MODEL;
using Elmah;
using System.Web;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.Utils;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/notification")]
    public class NotificationsController : ApiController
    {
        private readonly INotificationService _notificationService;
        public NotificationsController(INotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] NoticeModel model)
        {
            try
            {
                model.UserReceived = Common.GetUsernameLogin();
                var data = _notificationService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("push")]
        public IHttpActionResult Push([FromBody] MessageModel model)
        {
            try
            {
                model.UserSend = Common.GetUsernameLogin();
                var response = new ResponseModel()
                {
                    Success = true,
                    StatusCode = (int)COMMON.Constant.HttpStatusCode.SUCCESS,
                    Message = Message.ADD_SUCCESS
                };
                if (string.IsNullOrEmpty(model.UserReceived) && string.IsNullOrEmpty(model.Segment))
                {
                    response.Success = false;
                    response.Message = Message.PUSH_NOTICE_ERROR;
                }
                if(!string.IsNullOrEmpty(model.UserReceived))
                {
                    _notificationService.PushNotification(model.Message, model.UserSend, model.UserReceived);
                }
                if (!string.IsNullOrEmpty(model.Segment))
                {
                    _notificationService.PushNotifications(model.Message, model.UserSend, model.Segment);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("read")]
        [HttpPost]
        public IHttpActionResult Read([FromBody] List<int> messageIds)
        {
            try
            {
                _notificationService.UpdateRead(messageIds);
                return Ok();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
