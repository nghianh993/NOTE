﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/answer")]
    [JwtAuthentication]
    public class AnswerController : ApiController
    {
        #region Initialize
        public readonly IAnswerService _answerService;

        public AnswerController(IAnswerService answerService)
        {
            _answerService = answerService;
        }
        #endregion
        
        [Route("")]
        [HttpPost]
        public IHttpActionResult GetAllAnswersByQuestionId([FromBody] AnswerModel model)
        {
            try
            {
                var listItems = _answerService.GetAnswerByQuestionId(model);
                return Ok(listItems);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        public IHttpActionResult Post([FromBody] AnswerModel model)
        {
            try
            {
                return Ok(_answerService.Add(model));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        public IHttpActionResult Put([FromBody] AnswerModel model)
        {
            try
            {
                if (model.AnswerId == 0)
                {
                    return BadRequest();
                }
                return Ok(_answerService.Update(model));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("delete")]

        public IHttpActionResult Delete([FromUri] int answerId)
        {
            try
            {
                if (answerId == 0)
                {
                    return BadRequest();
                }
                return Ok(_answerService.Delete(answerId));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
