﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/report")]
    [JwtAuthentication]
    public class ReportController : ApiController
    {
        #region Initialize
        public readonly IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService;
        }
        #endregion

        [HttpPost]
        [Route("download")]
        public HttpResponseMessage ExportData([FromBody] UserModel model)
        {
            try
            {
                var data = _reportService.GetReportData(model.Username, model.fromDate, model.endDate);
                if(data != null && data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    var documentStream = ExcelHelper.ExportExcelByDataSet(data, "DWN_Template.xlsx", 9, ".xlsx", true);
                    var result = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new ByteArrayContent(documentStream.ToArray())
                    };
                    result.Content.Headers.ContentDisposition =
                        new ContentDispositionHeaderValue("attachment")
                        {
                            FileName = Common.GetUsernameLogin() +"_" + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss") + ".xlsx"
                        };
                    result.Content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

                    return result;
                }
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return Request.CreateResponse(HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("userunder")]
        public IHttpActionResult GetUserUnder([FromBody] ReportUserModel model)
        {
            try
            {
                model.username = string.IsNullOrEmpty(model.username) ? "system" : model.username;
                model.userCreated = model.userCreated ?? string.Empty;
                var data = _reportService.GetUserUnder(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Post([FromBody] UserModel model)
        {
            try
            {
                var data = _reportService.GetAllData(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
