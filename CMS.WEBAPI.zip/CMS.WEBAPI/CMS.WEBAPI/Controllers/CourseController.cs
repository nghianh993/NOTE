﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/course")]
    [JwtAuthentication]
    public class CourseController : ApiController
    {
        #region Initialize
        public readonly ICourseService _courseService;

        public CourseController(ICourseService courseService)
        {
            _courseService = courseService;
        }
        #endregion

        [HttpPost]
        [Route("getAllCourses")]
        public IHttpActionResult GetAllCourses([FromBody] CourseModel model)
        {
            try
            {
                var courseModels = _courseService.GetListCourses(model);
                if (courseModels == null)
                {
                    return NotFound();
                }

                return Ok(courseModels);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Post([FromBody] CourseModel model)
        {
            try
            {
                var userLogin = Common.GetUsernameLogin();
                model.CreatedDate = DateTime.Now;
                model.CreatedBy = userLogin;
                model.Status = (int)Status.ACTIVE;
                var data = _courseService.CreateCourse(model);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Put([FromBody] CourseModel model)
        {
            try
            {
                if (model.Id == 0)
                {
                    return BadRequest();
                }

                var data = _courseService.UpdateCourse(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("delete")]
        [HttpPost]
        public IHttpActionResult Delete([FromBody] CourseModel model)
        {
            try
            {
                if (model.Id == 0)
                {
                    return BadRequest();
                }
                var data = _courseService.DeleteCourse(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("deleteMultiCourse")]
        [HttpPost]
        public IHttpActionResult DeleteMultiCourse([FromBody] CourseModel model)
        {
            try
            {
                var data = _courseService.DeleteMultiCourses(model.Ids);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] CourseModel model)
        {
            try
            {
                var data = _courseService.LockOrUnlock(model.Ids, (model.Status ?? 0));
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
