﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/balance")]
    [JwtAuthentication]
    public class BalanceHistoryController : ApiController
    {
        #region Initialize
        public readonly IBalanceHistoryService _balanceHistoryService;

        public BalanceHistoryController(IBalanceHistoryService balanceHistoryService)
        {
            _balanceHistoryService = balanceHistoryService;
        }
        #endregion

        [Route("")]
        public IHttpActionResult Post([FromBody] BalanceHistoryModel model)
        {
            try
            {
                var data = _balanceHistoryService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        public IHttpActionResult Add([FromBody] BalanceHistoryModel model)
        {
            try
            {
                model.CreatedUser = Common.GetUsernameLogin();
                return Ok(_balanceHistoryService.Add(model));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("approve")]
        [HttpPut]
        public IHttpActionResult Approve([FromUri] int id)
        {
            try
            {
                return Ok(_balanceHistoryService.Approve(id, Common.GetUsernameLogin()));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("reject")]
        [HttpDelete]
        public IHttpActionResult Reject([FromUri] int id)
        {
            try
            {
                return Ok(_balanceHistoryService.Reject(id));
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
