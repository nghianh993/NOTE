﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/ExamQuestionMapping")]
    [JwtAuthentication]
    public class ExamQuestionMappingController : ApiController
    {
        #region Initialize
        public readonly IExamQuestionMappingService _examQuestionMappingService;

        public ExamQuestionMappingController(IExamQuestionMappingService examQuestionMappingService)
        {
            _examQuestionMappingService = examQuestionMappingService;
        }
        #endregion
        
        public IHttpActionResult Post([FromBody] ExamQuestionMappingModel model)
        {
            try
            {
                var data = _examQuestionMappingService.CreateExamQuestionMappings(model.ListQuestionIds,model.ExamId);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        [Route("Delete")]
        [HttpPost]
        public IHttpActionResult Delete([FromBody] ExamQuestionMappingModel model)
        {
            try
            {
                if (model.ExamId == 0)
                {
                    return BadRequest();
                }
                var data = _examQuestionMappingService.DeleteExamQuestionMappings(model.ListQuestionIds, model.ExamId);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
