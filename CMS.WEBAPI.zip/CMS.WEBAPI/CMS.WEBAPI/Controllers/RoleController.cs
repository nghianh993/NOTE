﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/role")]
    public class RoleController : ApiController
    {
        private readonly IRoleService _roleService;
        public RoleController(IRoleService roleService)
        {
            _roleService = roleService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] RoleModel model)
        {
            try
            {
                var data = _roleService.GetAllRole(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("getmenu")]
        public IHttpActionResult GetMenu()
        {
            try
            {
                var userLogin = Common.GetUsernameLogin();
                var data = _roleService.GetMenuByUser(userLogin);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("permission")]
        public IHttpActionResult GetPermission()
        {
            try
            {
                var currentUser = Common.GetUsernameLogin();
                var data = _roleService.GetPermissionByUser(currentUser);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        public IHttpActionResult Add([FromBody] RoleModel model)
        {
            try
            {
                var userLogin = Common.GetUsernameLogin();
                model.UserCreate = userLogin;
                model.CreatedDate = DateTime.Now;
                model.Status = (int)Status.ACTIVE;
                var data = _roleService.AddRole(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] RoleModel model)
        {
            try
            {
                var data = _roleService.UpdateRole(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] RoleModel roleModel)
        {
            try
            {
                var data = _roleService.LockOrUnlock(roleModel.roleIds, (roleModel.Status ?? 0));
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("permissions")]
        [HttpGet]
        public IHttpActionResult GetPermissionByRoleId([FromUri] string roleId)
        {
            try
            {
                var data = _roleService.GetDataTreeRole(roleId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update_permissions")]
        [HttpPost]
        public IHttpActionResult UpdatePermission([FromBody] RolePermissionModel rolePermission)
        {
            try
            {
                var currentUser = Common.GetUsernameLogin();
                var data = _roleService.UpdatePermission(rolePermission.permissionIds, rolePermission.roleId, currentUser);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
