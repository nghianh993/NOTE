﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/Exam")]
    public class ExamController : ApiController
    {
        #region Initialize
        public readonly IExamService _excamService;

        public ExamController(IExamService excamService)
        {
            _excamService = excamService;
        }
        #endregion

        [HttpPost]
        [Route("getAllExam")]
        public IHttpActionResult GetAllExams([FromBody] ExamModel model)
        {
            try
            {
                var examModels = _excamService.GetListExams(model);
                if (examModels == null)
                {
                    return NotFound();
                }

                return Ok(examModels);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        [Route("getExamById")]
        public IHttpActionResult GetExamById([FromBody] ExamModel model)
        {
            try
            {
                var examModel = _excamService.GetExamByExamId(model.ExamId);
                if (examModel == null)
                {
                    return NotFound();
                }

                return Ok(examModel);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        public IHttpActionResult Post([FromBody] ExamModel model)
        {
            try
            {
                var userLogin = Common.GetUsernameLogin();
                model.CreateDate = DateTime.Now;
                model.UserCreate = userLogin;
                model.Status = (int)Status.ACTIVE;
                var data = _excamService.CreateExam(model);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        public IHttpActionResult Put([FromBody] ExamModel model)
        {
            try
            {
                if (model.ExamId == 0)
                {
                    return BadRequest();
                }

                var data = _excamService.UpdateExam(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("delete")]
        [HttpPut]
        public IHttpActionResult Delete([FromBody] ExamModel model)
        {
            try
            {
                if (model.ExamId == 0)
                {
                    return BadRequest();
                }
                var data = _excamService.DeleteExam(model.ExamId);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("calculatorPointExam")]
        [HttpPost]
        public IHttpActionResult CalculatorPointExam([FromBody] ExamResultModel model)
        {
            try
            {
                if (model == null)
                {
                    return BadRequest();
                }
                var data = _excamService.CalculatorPoint(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("addExamForUser")]
        [HttpPost]
        public IHttpActionResult AddExamForUser([FromBody] UserExamModel model)
        {
            try
            {
                var data = _excamService.AddExamForUser(model);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("addExamForClass")]
        [HttpPost]
        public IHttpActionResult AddExamForClass([FromBody] ClassExamModel model)
        {
            try
            {
                var data = _excamService.AddExamForClass(model);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("deleteExamOfUser")]
        [HttpPost]
        public IHttpActionResult DeleteExamOfUser([FromBody] UserExamModel model)
        {
            try
            {
                var data = _excamService.DeleteExamOfUser(model);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("getQuestionForExam")]
        [HttpPost]
        public IHttpActionResult GetQuestionForExam([FromBody] UserExamModel model)
        {
            try
            {
                var data = _excamService.GetQuestionsForExam(model.ExamId);

                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
