﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/list")]
    [JwtAuthentication]
    public class ListController : ApiController
    {
        #region Initialize
        public readonly IListService _listService;

        public ListController(IListService listService)
        {
            _listService = listService;
        }
        #endregion
        
        [HttpGet]
        public IHttpActionResult GetAllLists()
        {
            try
            {
                var listModels = _listService.GetLists();
                if (listModels == null)
                {
                    return NotFound();
                }

                return Ok(listModels);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        [Route("getListById")]
        public IHttpActionResult GetListById([FromBody] ListModel model)
        {
            try
            {
                var listModel = _listService.GetListById(model.Id);
                if (listModel == null)
                {
                    return NotFound();
                }

                return Ok(listModel);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        public IHttpActionResult Post([FromBody] ListModel model)
        {
            try
            {
                _listService.CreateList(model);

                return Ok();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        public IHttpActionResult Put([FromBody] ListModel model)
        {
            try
            {
                if (model.Id == 0)
                {
                    return BadRequest();
                }

                _listService.UpdateList(model);


                return Ok();

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        
        public IHttpActionResult Delete([FromBody] ListModel model)
        {
            try
            {
                if (model.Id == 0)
                {
                    return BadRequest();
                }
                _listService.DeleteList(model.Id);


                return Ok();

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
