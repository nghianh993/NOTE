﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/question")]
    [JwtAuthentication]
    public class QuestionController : ApiController
    {
        #region Initialize
        public readonly IQuestionService _questionService;

        public QuestionController(IQuestionService questionService)
        {
            _questionService = questionService;
        }
        #endregion

        [Route("")]
        public IHttpActionResult Post([FromBody] QuestionModel model)
        {
            try
            {
                var data = _questionService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        [HttpPost]
        public IHttpActionResult Add([FromBody] QuestionModel model)
        {
            try
            {
                model.UserCreate = Common.GetUsernameLogin();
                var data = _questionService.Add(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] QuestionModel model)
        {
            try
            {
                model.UserCreate = Common.GetUsernameLogin();
                var data = _questionService.Update(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("lock_unlock")]
        [HttpPost]
        public IHttpActionResult LockOrUnlock([FromBody] QuestionModel model)
        {
            try
            {
                var data = _questionService.LockOrUnlock(model.ids, (model.Status ?? 0));
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("tree")]
        [HttpGet]
        public IHttpActionResult GetCateQuestionTree()
        {
            try
            {
                var data = _questionService.GetAllQuestionCate();
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("getAllQuestionByExamId")]
        [HttpPost]
        public IHttpActionResult GetAllQuestionsByExamId([FromBody] QuestionModel model)
        {
            try
            {
                var listItems = _questionService.GetAllQuestionByExamId(model);
                return Ok(listItems);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("get_all_level")]
        [HttpGet]
        public IHttpActionResult GetAllLevel()
        {
            try
            {
                var listItems = _questionService.GetAllLevel();
                return Ok(listItems);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
