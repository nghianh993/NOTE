﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;
using System.Linq;

namespace CMS.WEBAPI.Controllers
{
    [JwtAuthentication]
    [RoutePrefix("api/cate/backamount")]
    public class BackAmountController : ApiController
    {
        private readonly IBackAmountService _backAmountService;
        public BackAmountController(IBackAmountService backAmountService)
        {
            _backAmountService = backAmountService;
        }

        [Route("")]
        public IHttpActionResult Post([FromBody] BackAmountModel model)
        {
            try
            {
                var data = _backAmountService.GetAll(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("add")]
        [HttpPost]
        public IHttpActionResult Add([FromBody] BackAmountModel model)
        {
            try
            {
                model.CreateBy = Common.GetUsernameLogin();
                var data = _backAmountService.Add(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("update")]
        [HttpPut]
        public IHttpActionResult Update([FromBody] BackAmountModel model)
        {
            try
            {
                var data = _backAmountService.Update(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("delete")]
        [HttpDelete]
        public IHttpActionResult Delete([FromUri] string ids)
        {
            try
            {
                var data = _backAmountService.Delete(ids.Split(',').ToList());
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

    }
}