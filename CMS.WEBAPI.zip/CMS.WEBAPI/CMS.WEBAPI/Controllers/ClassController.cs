﻿using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.Filters;
using CMS.WEBAPI.MODEL;
using CMS.WEBAPI.Utils;
using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.WebPages;

namespace CMS.WEBAPI.Controllers
{
    [RoutePrefix("api/Class")]
    [JwtAuthentication]
    public class ClassController : ApiController
    {
        #region Initialize
        public readonly IClassService _classService;

        public ClassController(IClassService classService)
        {
            _classService = classService;
        }
        #endregion

        [HttpPost]
        [Route("getAllClass")]
        public IHttpActionResult GetAllClass([FromBody] ClassModel model)
        {
            try
            {
                var classModel = _classService.GetListClasses(model);
                if (classModel == null)
                {
                    return NotFound();
                }

                return Ok(classModel);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        [Route("getClassByClassCode")]
        public IHttpActionResult GetClassByClassCode([FromBody] ClassModel model)
        {
            try
            {
                var classModel = _classService.GetClassByClassCode(model.ClassCode);
                if (classModel == null)
                {
                    return NotFound();
                }

                return Ok(classModel);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Post([FromBody] ClassModel model)
        {
            try
            {
                if (model == null || string.IsNullOrEmpty(model.ClassCode.Trim()))
                {
                    return BadRequest();
                }

                var userLogin = Common.GetUsernameLogin();
                if(model.Date != null)
                {
                    if (!string.IsNullOrEmpty(model.Date[0]))
                    {
                        model.BeginDate = Convert.ToDateTime(model.Date[0]);
                    }
                    if (!string.IsNullOrEmpty(model.Date[1]))
                    {
                        model.EndDate = Convert.ToDateTime(model.Date[1]);
                    }
                }
               
                model.CreateDate = DateTime.Now;
                //model.UserCreate = userLogin;
                model.Status = (int)Status.ACTIVE;

                var data = _classService.CreateClass(model);

                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }

        public IHttpActionResult Put([FromBody] ClassModel model)
        {
            try
            {
                if (model == null || string.IsNullOrEmpty(model.ClassCode.Trim()))
                {
                    return BadRequest();
                }
                if(model.Date != null)
                {
                    if (!string.IsNullOrEmpty(model.Date[0]))
                    {
                        model.BeginDate = Convert.ToDateTime(model.Date[0]);
                    }
                    if (!string.IsNullOrEmpty(model.Date[1]))
                    {
                        model.EndDate = Convert.ToDateTime(model.Date[1]);
                    }
                }
                var data = _classService.UpdateClass(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [HttpPut]
        [Route("delete")]
        public IHttpActionResult DeleteClass([FromBody] ClassModel model)
        {
            try
            {
                if (model == null || string.IsNullOrEmpty(model.ClassCode))
                {
                    return BadRequest();
                }
                model.Status = (int)Status.DELETE;
                var data = _classService.DeleteClass(model);


                return Ok(data);

            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("listCourse")]
        [HttpGet]
        public IHttpActionResult GetAllCourse()
        {
            try
            {
                var data = _classService.GetAllCourse();
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("listClassesByUserServices")]
        [HttpPost]
        public IHttpActionResult GetListClassesByUserServices([FromBody] ClassModel model)
        {
            try
            {
                var data = _classService.GetListClassesByUserServices(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
        [Route("listClassesNoTeacher")]
        [HttpPost]
        public IHttpActionResult GetListClassesNoTeacher([FromBody] ClassModel model)
        {
            try
            {
                var data = _classService.GetListClassesNoTeacher(model);
                return Ok(data);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return InternalServerError();
            }
        }
    }
}
