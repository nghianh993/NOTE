﻿using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;

namespace CMS.WEBAPI.Utils
{
    public class Common
    {
        public static string GetUsernameLogin()
        {
            var username = string.Empty;
			try
			{
                var claimsIdentity = HttpContext.Current.User.Identity as ClaimsIdentity;

                var targetClaim = claimsIdentity.FindFirst(ClaimTypes.Name);
                if (targetClaim == null)
                {
                    return username;
                }

                return targetClaim.Value;
            }
            catch (Exception ex)
			{
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
                return username;
            }
        }
    }
}