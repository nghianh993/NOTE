﻿using Elmah;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

namespace CMS.WEBAPI.Utils
{
    public static class ExcelHelper
    {
        public static MemoryStream ExportExcelByDataSet(DataSet dsData, string fileNameTemplate, int rowBegin, string extention, bool isBorder)
        {
            var documentStream = new MemoryStream();
            try
            {
                string pathFileTemplate = HttpContext.Current.Server.MapPath("~") + "\\Templates\\" + fileNameTemplate;
                using(var templateDocumentStream = File.OpenRead(pathFileTemplate))
                {
                    using(var package = new ExcelPackage(templateDocumentStream))
                    {
                        var dt = new DataTable();
                        for (int n = 0; n < dsData.Tables.Count; n++)
                        {
                            int row = rowBegin;
                            var worksheet = package.Workbook.Worksheets[n];
                            dt = (DataTable)dsData.Tables[n];
                            if(dt.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dt.Rows)
                                {
                                    int col = 1;
                                    for (int i = 0; i < dr.ItemArray.Length; i++)
                                    {
                                        worksheet.Cells[row, col].Value = dr[i];
                                        if(isBorder)
                                        {
                                            worksheet.Cells[row, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            worksheet.Cells[row, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            worksheet.Cells[row, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                        }
                                        col++;
                                    }
                                    row++;
                                }
                                worksheet.View.PageLayoutView = false;
                            }
                            package.SaveAs(documentStream);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(HttpContext.Current).Log(new Error(ex));
            }

            return documentStream;
        }
    }
}