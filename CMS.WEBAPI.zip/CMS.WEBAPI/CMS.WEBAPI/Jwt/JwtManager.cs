﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.MODEL;
using Microsoft.IdentityModel.Tokens;

namespace CMS.WEBAPI.Jwt
{
    public static class JwtManager
    {
        private static readonly string Secret = WebUtils.GetAppSettingsConfigValue(WebConstant.SECRETKEY);
        private static readonly int timeout = Convert.ToInt32(WebUtils.GetAppSettingsConfigValue(WebConstant.TIMEOUT_TOKEN));

        public static string GenerateToken(UserModel userModel)
        {
            var symmetricKey = Convert.FromBase64String(Secret);
            var tokenHandler = new JwtSecurityTokenHandler();

            var now = DateTime.UtcNow;
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, userModel.Username),
                    new Claim("Avatar", userModel.Avatar ?? string.Empty),
                    new Claim("Name", userModel.Username),
                }),

                Expires = now.AddMinutes(Convert.ToInt32(timeout)),

                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(symmetricKey), SecurityAlgorithms.HmacSha256Signature)
            };

            SecurityToken securityToken = tokenHandler.CreateToken(tokenDescriptor);
            var token = tokenHandler.WriteToken(securityToken);

            return token;
        }

        public static ClaimsPrincipal GetPrincipal(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;

                if (jwtToken == null)
                    return null;

                var symmetricKey = Convert.FromBase64String(Secret);

                var validationParameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = new SymmetricSecurityKey(symmetricKey)
                };

                var principal = tokenHandler.ValidateToken(token, validationParameters, out _);

                return principal;
            }

            catch (Exception)
            {
                return null;
            }
        }
    }
}