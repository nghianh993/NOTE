﻿using CMS.WEBAPI.BUSINESS.Authentication;
using CMS.WEBAPI.Jwt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace CMS.WEBAPI.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class JwtAuthenticationAttribute : AuthorizationFilterAttribute
    {
        private AuthenticationServices objAuth = null;

        public override void OnAuthorization(HttpActionContext filterContext)
        {
            try
            {
                var request = filterContext.Request;
                var authorization = request.Headers.Authorization;

                if (authorization == null || authorization.Scheme != "Bearer")
                {
                    filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    return;
                }
                if (string.IsNullOrEmpty(authorization.Parameter))
                {
                    filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    return;
                }
                var token = authorization.Parameter;
                var url = request.RequestUri.AbsolutePath;
                var method = request.Method;
                var username = string.Empty;
                if (!ValidateToken(token, url, method.Method, ref username))
                {
                    filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    return;
                }
                //set claim
                var claims = new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, username)
                };
                var id = new ClaimsIdentity(claims, "Basic");
                var principal = new ClaimsPrincipal(new[] { id });
                filterContext.Request.GetRequestContext().Principal = principal;
            }
            catch (Exception)
            {
                filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                return;
            }
            base.OnAuthorization(filterContext);
        }

        private bool ValidateToken(string token, string url, string method, ref string username)
        {
            var simplePrinciple = JwtManager.GetPrincipal(token);
            var identity = simplePrinciple?.Identity as ClaimsIdentity;

            if (identity == null)
                return false;

            if (!identity.IsAuthenticated)
                return false;

            var usernameClaim = identity.FindFirst(ClaimTypes.Name);
            username = usernameClaim?.Value;

            if (string.IsNullOrEmpty(username))
                return false;

            //Validate user role from database
            objAuth = new AuthenticationServices();
            return objAuth.CheckAuthentication(username, url, method);
        }
    }
}
