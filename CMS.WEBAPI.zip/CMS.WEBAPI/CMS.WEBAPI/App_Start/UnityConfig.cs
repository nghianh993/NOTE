using CMS.WEBAPI.BUSINESS.Implements;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace CMS.WEBAPI
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            container.RegisterType<ILoginService, LoginService>();
            container.RegisterType<IRoleService, RoleService>();
            container.RegisterType<IClassService, ClassService>();
            container.RegisterType<IExamService, ExamService>();
            container.RegisterType<IExamQuestionMappingService, ExamQuestionMappingService>();
            container.RegisterType<IListService, ListService>();
            container.RegisterType<IQuestionService, QuestionService>();
            container.RegisterType<IBalanceHistoryService, BalanceHistoryService>();
            container.RegisterType<IAnswerService, AnswerService>();
            container.RegisterType<IUserService, UserService>();
            container.RegisterType<IQuestionCateService, QuestionCateService>();
            container.RegisterType<IAnswerService, AnswerService>();
            container.RegisterType<ICourseService, CourseService>();
            container.RegisterType<IServiceService, ServiceService>();
            container.RegisterType<IBackAmountService, BackAmountService>();
            container.RegisterType<IUserClassService, UserClassService>();
            container.RegisterType<ITeacherClassService, TeacherClassService>();
            container.RegisterType<INotificationService, NotificationService>();
            container.RegisterType<IReportService, ReportService>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}