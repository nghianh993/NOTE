﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Constant
{
    public static class WebConstant
    {
        //Static config
        public static string AUTHENTICATION_KEY = "AUTHENTICATION_KEY";

        //Webconfig
        public static string PAGESIZE = "PAGESIZE";
        public static string SECRETKEY = "SECRETKEY";
        public static string TIMEOUT_TOKEN = "TIMEOUT_TOKEN";
        public static string DEFAULT_PASS = "DEFAULT_PASS";
        public static string APP_ID = "APP_ID";
        public static string SECRET_KEY = "SECRET_KEY";
        public static string URL_NOTIFICATIONS = "URL_NOTIFICATIONS";
        public static string FOLDERUPOAD = "FOLDERUPOAD";
        public static string URL_IMAGE = "URL_IMAGE";
    }
}
