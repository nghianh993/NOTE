﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Constant
{
    public class Message
    {
        public static string SERVER_ERROR = "Hệ thống gặp sự cố trong quá trình cập nhật dữ liệu";
        public static string ADD_SUCCESS = "Thêm mới dữ liệu thành công";
        public static string UPDATE_SUCCESS = "Cập nhật dữ liệu thành công";
        public static string ADD_EXISTS = "Dữ liệu đã tồn tại trong hệ thống vui lòng kiểm tra lại";
        public static string NOT_EXISTS = "Dữ liệu cần cập nhật không tồn tại trong hệ thống";
        public static string NOT_ENOUGH = "Số tiền trong tài khoản không đủ";
        public static string MAX_STUDENT = "Đã quá số lượng học sinh có thể thêm";
        public static string BACK_AMOUNT_NOTICE = "Kế toán phê duyệt thanh toán";
        public static string BACK_AMOUNT = "Bạn đã được hoàn lại {0} VNĐ vào tài khoản, tổng số tiền hiện tại là {1} VNĐ";
        public static string REJECT_AMOUNT = "Kế toán không phê duyệt số tiền {0} VNĐ bạn đã nạp cho khách hàng";
        public static string CHANGE_AMOUNT = "Tài khoản của bạn vừa bị trừ {0} VNĐ với lý do: {1}";
        public static string PUSH_NOTICE_ERROR = "Bạn chưa đẩy thông tin người nhận, nhóm người nhận để gửi thông báo";
        public static string PW_ERROR = "Mật khẩu cũ không chính xác! Vui lòng kiểm tra lại.";
        public static string PW_ERROR1 = "Mật khẩu mới không khớp.";
    }
}
