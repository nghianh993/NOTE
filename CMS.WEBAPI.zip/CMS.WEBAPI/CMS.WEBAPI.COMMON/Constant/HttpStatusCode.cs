﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Constant
{
    public enum HttpStatusCode
    {
        SUCCESS = 200,
        SERVER_ERROR = 500
    }
}
