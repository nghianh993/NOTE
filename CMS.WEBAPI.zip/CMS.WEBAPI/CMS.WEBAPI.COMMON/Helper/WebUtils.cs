﻿using System.Configuration;

namespace CMS.WEBAPI.COMMON
{
    public class WebUtils
    {
        public static string GetAppSettingsConfigValue(string key)
        {
            return ConfigurationManager.AppSettings[key].ToString();
        }
    }
}
