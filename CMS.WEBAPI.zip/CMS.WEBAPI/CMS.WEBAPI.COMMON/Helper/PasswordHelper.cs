﻿using CMS.WEBAPI.COMMON.Constant;

namespace CMS.WEBAPI.COMMON.Helper
{
    public class PasswordHelper
    {
        private static readonly string secretKey = WebUtils.GetAppSettingsConfigValue(WebConstant.SECRETKEY);

        public static string GeneratePassword(string username, string password)
        {
            var pwdToHash = string.Format("{0}{1}{2}", username, secretKey, password);
            return BCrypt.Net.BCrypt.HashPassword(pwdToHash);
        }

        public static bool VerifyPassword(string username, string password, string hashPassword)
        {
            var pwdToHash = string.Format("{0}{1}{2}", username, secretKey, password);
            return BCrypt.Net.BCrypt.Verify(pwdToHash, hashPassword);
        }
    }
}
