﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Enum
{
    public enum Status
    {
        NOT_ACTIVE = 0,
        ACTIVE = 1,
        NOT_APPROVE = 2,
        DELETE = -1,
        WAITING = 3
    }
}
