﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.COMMON.Enum
{
    public enum UserType
    {
        //Học sinh
        STUDENT = 1,
        //Giáo viên
        TEACHER = 2,
        //Phụ huynh
        PARENT = 3,
        //Khác
        OTHER = 4
    }
    public enum ExamIdDefault
    {
        EXAMID = 1
    }
}
