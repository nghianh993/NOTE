﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ExamModel
    {
        public int ExamId { get; set; }
        public string ExamName { get; set; }
        public int PassPoint { get; set; }
        public int? Status { get; set; }
        public string UserName { get; set; }
        public bool? IsPass { get; set; }
        public string QuestionCateId { get; set; }
        public int TestTime { get; set; }
        public string ClassCode { get; set; }
        public List<ExamLevelMappingModel> ExamLevels { get; set; }
        public DateTime? CreateDate { get; set; }
        public string UserCreate { get; set; }
        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }
        public bool? IsMulti { get; set; }
    }
}
