﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class BalanceHistoryModel
    {
        public int ID { get; set; }
        public string Username { get; set; }
        public decimal Amount { get; set; }
        public int? Type { get; set; }
        public int? Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedUser { get; set; }
        public string Note { get; set; }
        public DateTime? ApproveDate { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }
    }
}
