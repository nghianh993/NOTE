﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class StudentClassModel
    {
        public int Id { get; set; }
        public string StudentId { get; set; }
        public string ClassId { get; set; }
        public string Checkin { get; set; }
        public int Status { get; set; }
        public DateTime CreateDate { get; set; }
        public string UserCreate { get; set; }
    }
}
