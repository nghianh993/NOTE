﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class JwtResponseModel
    {
        public string Access { get; set; }
        public string Type { get; set; } = "Bearer ";
        public string Name { get; set; }
        public string Avatar { get; set; }
        public bool Success { get; set; }
    }
}
