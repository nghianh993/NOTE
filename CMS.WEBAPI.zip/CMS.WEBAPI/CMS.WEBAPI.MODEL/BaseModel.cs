﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class BaseModel
    {
        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }
    }
}
