﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class PagingModel<T>
    {
        public List<T> data { get; set; }
        public int page { get; set; }
        public bool success { get; set; }
        public int total { get; set; }
        public int totalUnder { get; set; }
    }
}
