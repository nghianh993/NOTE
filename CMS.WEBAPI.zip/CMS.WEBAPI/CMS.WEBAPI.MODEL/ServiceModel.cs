﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ServiceModel
    {
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
        public int? Type { get; set; }
        public DateTime? CreateDate { get; set; }
        public string UserCreated { get; set; }
        public decimal Price { get; set; }
        public int? Status { get; set; }
        public string Training { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<string> ids { get; set; }
    }
}
