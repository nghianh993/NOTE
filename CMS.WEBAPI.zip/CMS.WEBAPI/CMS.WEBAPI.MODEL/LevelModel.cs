﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class LevelModel
    {
        public string LevelCode { get; set; }
        public string LevelName { get; set; }
    }
}
