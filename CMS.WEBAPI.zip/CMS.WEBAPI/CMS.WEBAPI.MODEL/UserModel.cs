﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class UserModel
    {
        public string Username { get; set; }
        //[JsonIgnore]
        public string Password { get; set; }
        public string Fullname { get; set; }
        public string Gender { get; set; }
        public DateTime? Birthday { get; set; }
        public string Avatar { get; set; }
        public string School { get; set; }
        public string Address { get; set; }
        public int? Status { get; set; }
        public bool IsParents { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public DateTime? LastLogin { get; set; }
        public decimal Amount { get; set; }
        public int? Type { get; set; }
        public string ChildrenAccount { get; set; }
        public string Title { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int? Services { get; set; }
        public string UserServices { get; set; }
        public string IdentityCard { get; set; }
        public decimal? BackAmount { get; set; }
        public decimal? TotalPay { get; set; }
        public decimal? TotalPayEUR { get; set; }
        public string Branch { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? endDate { get; set; }
        public string Class { get; set; }
        public long? Number { get; set; }
        public decimal Total { get; set; }
        public decimal TotalAmount { get; set; }
        public string ParentAccount { get; set; }
        public string ParentFullname { get; set; }
        public string ParentPhone { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<string> userIds { get; set; }
        public List<string> roleIds { get; set; }
        public string UserCreated { get; set; }
        public int? IsArrange { get; set; }
        public string ClassCode { get; set; }
    }

    public class ChangePasswordModel
    {
        [JsonIgnore]
        public string CurrentUser { get; set; }
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
        public string ReNewPassword { get; set; }
    }
}
