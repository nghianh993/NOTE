﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class MenuModel
    {
        public MenuModel()
        {
            children = new List<MenuModel>();
        }
        public string key { get; set; }
        public string path { get; set; }
        public string name { get; set; }
        public string icon { get; set; }
        public bool exact { get; set; }
        public bool locale { get; set; }
        public string authority { get; set; }
        public string parentKeys { get; set; }
        public List<MenuModel> children { get; set; }
    }
}
