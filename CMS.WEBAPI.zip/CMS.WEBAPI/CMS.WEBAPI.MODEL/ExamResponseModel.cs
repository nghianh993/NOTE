﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ExamResponseModel
    {
        public int ExamId { get; set; }
        public string UserName { get; set; }
        public string ExamName { get; set; }
        public int PassPoint { get; set; }
        public int? Score { get; set; }
        public bool? IsPass { get; set; }
        public int? TestTime { get; set; }
        public bool? IsMulti { get; set; }

    }
}
