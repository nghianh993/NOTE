﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ExamQuestionMappingModel
    {
        public int ExamId { get; set; }
        public List<int> ListQuestionIds { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
