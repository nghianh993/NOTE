﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class QuestionModel
    {
        public int QuestionId { get; set; }
        public string QuestionName { get; set; }
        public string Level { get; set; }
        public string LevelName { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string UserCreate { get; set; }
        public int? Status { get; set; }
        public int? CateId { get; set; }
        public int TotalAnswer { get; set; }
        public List<AnswerModel> Answers { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<int> ids { get; set; }
        public int Examid { get; set; }
    }
}
