﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ClassModel
    {
        public string ClassCode { get; set; }
        public string ClassName { get; set; }
        public string Avatar { get; set; }
        public int? Status { get; set; }
        public DateTime? BeginDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? MaxTotalStudent { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string UserCreate { get; set; }
        public int? CourseId { get; set; }
        public string TimeTable { get; set; }
        public int? MaxDayOff { get; set; }
        public string Services { get; set; }
        public int NumberLesson { get; set; }
        public int TotalCurrentStudent { get; set; }
        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }
        public List<string> classCodes { get; set; }
        public String[] Date { get; set; }
        public int? IsArrange { get; set; }
        public string UserName { get; set; }
        public string ClassLevel { get; set; }
        public int Total { get; set; }
    }
}
