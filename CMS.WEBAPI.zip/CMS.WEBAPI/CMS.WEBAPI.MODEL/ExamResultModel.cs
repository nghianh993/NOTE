﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ExamResultModel
    {
        public int ExamId { get; set; }
        public string UserId { get; set; }
        public List<AnswerRequestModel> Answers { get; set; }
    }
    public class AnswerRequestModel
    {
        public int QuestionId { get; set; }
        public List<int> AnswerIds { get; set; }
    }
    public class AnswerResponseModel : ResponseModel
    {
        public AnswerResultResponseModel data { get; set; }
    }
    public class AnswerResultResponseModel
    {
        public string UserId { get; set; }
        public int PassPoint { get; set; }
        public int TotalQuestion { get; set; }
        public int TotalPassQuestion { get; set; }
        public bool IsPass { get; set; }

    }
    public class ExamHistoryModel
    {
        public int Id { get; set; }
        public int ExamId { get; set; }
        public string UserId { get; set; }
        public int TotalCore { get; set; }
        public bool PassOrNotPass { get; set; }
        public DateTime CreateDate { get; set; }
        public string UserAnswerKey { get; set; }
    }
}
