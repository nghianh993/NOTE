﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class PermissionTreeModel
    {
        public string key { get; set; }
        public string title { get; set; }
        public List<PermissionTreeModel> children { get; set; }
    }

    public class TreeRole
    {
        public TreeRole()
        {
            treeData = new List<PermissionTreeModel>();
        }
        public List<PermissionTreeModel> treeData { get; set; }
        public List<string> treeSelected { get; set; }
    }
}
