﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class QuestionForExamModel
    {
        public int QuestionId { get; set; }
        public string QuestionName { get; set; }
        public string Level { get; set; }
        public List<AnswerModel> Answers { get; set; }
    }
}
