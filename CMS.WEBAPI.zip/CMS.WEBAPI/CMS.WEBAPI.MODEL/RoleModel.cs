﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class RoleModel
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public string Description { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UserCreate { get; set; }
        public int? Status { get; set; }
        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }
        public List<string> roleIds { get; set; }
    }

    public class RolePermissionModel
    {
        public List<string> permissionIds { get; set; }
        public string roleId { get; set; }
    }

    public class RoleForUserModel
    {
        public string label { get; set; }
        public string value { get; set; }
    }
}
