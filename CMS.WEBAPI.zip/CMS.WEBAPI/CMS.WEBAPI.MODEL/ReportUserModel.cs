﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ReportUserModel
    {
        public string username { get; set; }
        public string userCreated { get; set; }
        public int? status { get; set; }
        public int type { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public int pageIndex { get; set; } 
        public int pageSize { get; set; }
    }
}
