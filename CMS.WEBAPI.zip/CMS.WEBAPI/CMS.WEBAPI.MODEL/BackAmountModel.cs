﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class BackAmountModel
    {
        public BackAmountModel()
        {
            ids = new List<string>();
        }
        public string Code { get; set; }
        public decimal BackAmount1 { get; set; }
        public DateTime CreateDate { get; set; }
        public string CreateBy { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<string> ids { get; set; }
    }
}
