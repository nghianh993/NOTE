﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class SelectCommonModel
    {
        public string label { get; set; }
        public string value { get; set; }
    }
    public class SelectIntCommonModel
    {
        public string label { get; set; }
        public int value { get; set; }
    }

    public class TreeModel
    {
        public string key { get; set; }
        public string title { get; set; }
        public List<TreeModel> children { get; set; }
    }

    public class Tree
    {
        public Tree()
        {
            treeData = new List<TreeModel>();
        }
        public List<TreeModel> treeData { get; set; }
        public List<string> treeSelected { get; set; }
    }
}
