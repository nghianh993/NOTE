﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class AnswerModel
    {
        public int AnswerId { get; set; }
        public string AnswerName { get; set; }
        public string AnswerType { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string UserCreate { get; set; }
        public int? Status { get; set; }
        public bool? IsRightAnswer { get; set; }
        public int QuestionId { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<int> ids { get; set; }

    }
}
