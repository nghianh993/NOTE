﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class TeacherClassModel
    {
        public string Username { get; set; }
        public string ClassCode { get; set; }
        public bool? IsTeacher { get; set; }
        public DateTime? DateCreate { get; set; }
        public string UserCreate { get; set; }
    }
}
