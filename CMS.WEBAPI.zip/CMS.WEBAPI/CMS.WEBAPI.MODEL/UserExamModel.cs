﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class UserExamModel
    {
        public string UserName { get; set; }
        public int ExamId { get; set; }
    }
    public class ClassExamModel
    {
        public string ClassCode { get; set; }
        public int ExamId { get; set; }
    }
}
