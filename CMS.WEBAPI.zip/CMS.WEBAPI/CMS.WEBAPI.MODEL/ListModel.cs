﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class ListModel
    {
        public int Id { get; set; }
        public string ListCode { get; set; }
        public string ListName { get; set; }
        public string ListType { get; set; }
        public bool? Status { get; set; }
        public string Description { get; set; }
        public string UserCreate { get; set; }
        public DateTime? DateCreate { get; set; }
    }
}
