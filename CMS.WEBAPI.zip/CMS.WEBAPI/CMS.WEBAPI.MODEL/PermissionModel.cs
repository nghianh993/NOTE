﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CMS.WEBAPI.MODEL
{
    public class PermissionModel
    {
        public PermissionModel()
        {
            Children = new List<PermissionModel>();
        }
        public string PermistionId { get; set; }
        [JsonIgnore]
        public string Description { get; set; }
        public string Method { get; set; }
        public string Url { get; set; }
        [JsonIgnore]
        public int Status { get; set; }
        [JsonIgnore]
        public DateTime CreateDate { get; set; }
        [JsonIgnore]
        public string ParentId { get; set; }
        [JsonIgnore]
        public bool? IsMenu { get; set; }
        [JsonIgnore]
        public int? Position { get; set; }
        [JsonIgnore]
        public string Icon { get; set; }
        [JsonIgnore]
        public bool IsCheck { get; set; }
        [JsonIgnore]
        public List<PermissionModel> Children { get; set; }
    }
}
