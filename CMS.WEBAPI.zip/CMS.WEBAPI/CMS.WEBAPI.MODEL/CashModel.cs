﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class CashModel
    {
        public string currentUser { get; set; }
        public string userCash { get; set; }
        public string note { get; set; }
        public decimal amount { get; set; }
    }
}
