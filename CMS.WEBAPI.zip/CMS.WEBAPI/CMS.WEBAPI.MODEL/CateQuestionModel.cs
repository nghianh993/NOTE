﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class CateQuestionModel
    {
        public CateQuestionModel()
        {
            Child = new List<CateQuestionModel>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserCreated { get; set; }
        public DateTime? ModifyDate { get; set; }
        public int? Status { get; set; }
        public int? ParentId { get; set; }
        public List<CateQuestionModel> Child { get; set; }

        public int pageSize { get; set; }
        public int current { get; set; }
        public string sorter { get; set; }

        public List<int> ids { get; set; }
    }
}
