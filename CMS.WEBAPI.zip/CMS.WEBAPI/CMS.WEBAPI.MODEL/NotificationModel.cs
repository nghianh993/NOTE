﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.MODEL
{
    public class NoticeModel
    {
        public int MessageId { get; set; }
        public string Message { get; set; }
        public string UserReceived { get; set; }
        public DateTime? DateCreate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string Status { get; set; }
        public int pageSize { get; set; }
        public int current { get; set; }
    }

    public class NotificationModel
    {
        public NotificationModel()
        {
            contents = new NotificationContent();
            filters = new List<NotificationFilters>();
        }
        public string app_id { get; set; }
        public NotificationContent contents { get; set; }
        public List<NotificationFilters> filters { get; set; }
    }

    public class NotificationContent
    {
        public string en { get; set; }
    }
     
    public class NotificationFilters
    {
        public string field { get; set; }
        public string key { get; set; }
        public string value { get; set; }
        public string relation { get; set; }
    }

    public class MessageModel
    {
        public string Message { get; set; }
        public string UserSend { get; set; }
        public string UserReceived { get; set; }
        public string Segment { get; set; }
    }
}
