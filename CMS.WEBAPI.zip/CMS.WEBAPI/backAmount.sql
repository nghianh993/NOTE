ALTER PROC PROC_BackAmount(
	@p_username NVARCHAR(50)
)
AS
BEGIN
	IF OBJECT_ID('tempdb..#DATA_BACKAMOUNT') IS NOT NULL DROP TABLE #DATA_BACKAMOUNT
	;WITH userdata AS 
	(
	   SELECT Username, CreateBy FROM [User] u 
	   WHERE u.Username = @p_username
	   UNION ALL
	   SELECT p.Username, p.CreateBy FROM [User] p 
	   JOIN userdata b ON p.Username = b.CreateBy
	) 
	SELECT dt.Username INTO #DATA_BACKAMOUNT FROM userdata dt 
	WHERE dt.Username <> @p_username

	SELECT * FROM #DATA_BACKAMOUNT
END