USE [CRMAPIDB]
GO
/****** Object:  Table [dbo].[Answer]    Script Date: 03/16/2021 11:08:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Answer](
	[AnswerId] [int] IDENTITY(1,1) NOT NULL,
	[AnswerName] [nvarchar](500) NOT NULL,
	[AnswerType] [nvarchar](50) NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[Status] [int] NULL,
	[IsRightAnswer] [bit] NULL,
	[QuestionId] [int] NOT NULL,
 CONSTRAINT [PK_Answer] PRIMARY KEY CLUSTERED 
(
	[AnswerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AnswerType]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AnswerType](
	[Type] [nvarchar](50) NOT NULL,
	[TypeName] [nvarchar](150) NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_AnswerType] PRIMARY KEY CLUSTERED 
(
	[Type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BackAmount]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BackAmount](
	[Code] [nvarchar](50) NOT NULL,
	[BackAmount] [decimal](18, 0) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateBy] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_BackAmount] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BackAmountHistory]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BackAmountHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](50) NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[UserCreate] [nvarchar](50) NOT NULL,
	[CurrentAmount] [decimal](18, 2) NOT NULL,
	[NewAmount] [decimal](18, 2) NULL,
	[BalanceId] [int] NOT NULL,
	[Note] [nvarchar](max) NULL,
 CONSTRAINT [PK_BackAmountHistory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BalanceHistory]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BalanceHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Username] [nvarchar](50) NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[Type] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[Note] [nvarchar](500) NULL,
	[ApproveDate] [datetime] NULL,
 CONSTRAINT [PK_BalanceHistory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Class]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Class](
	[ClassCode] [nvarchar](50) NOT NULL,
	[ClassName] [nvarchar](250) NULL,
	[Avatar] [nvarchar](500) NULL,
	[Status] [int] NULL,
	[BeginDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[MaxTotalStudent] [int] NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[CourseId] [int] NOT NULL,
	[TimeTable] [nvarchar](max) NULL,
	[MaxDayOff] [int] NULL,
	[Services] [nvarchar](max) NOT NULL,
	[NumberLesson] [int] NULL,
	[TotalCurrentStudent] [int] NULL,
	[TotalHaveLearnt] [int] NULL,
 CONSTRAINT [PK_Class] PRIMARY KEY CLUSTERED 
(
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Course]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Course](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](max) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[Status] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[Branch] [nvarchar](10) NULL,
 CONSTRAINT [PK_Course] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Exam]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Exam](
	[ExamId] [int] IDENTITY(1,1) NOT NULL,
	[ExamName] [nvarchar](250) NULL,
	[PassPoint] [int] NOT NULL,
	[Status] [int] NULL,
	[CreateDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[QuestionCateId] [int] NULL,
	[TestTime] [int] NULL,
 CONSTRAINT [PK_Exam] PRIMARY KEY CLUSTERED 
(
	[ExamId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ExamHistory]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ExamHistory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ExamId] [int] NOT NULL,
	[UserId] [nvarchar](50) NOT NULL,
	[TotalCore] [int] NOT NULL,
	[PassOrNotPass] [bit] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[UserAnswerKey] [nvarchar](max) NULL,
 CONSTRAINT [PK_ExamHistory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ExamLevelMapping]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ExamLevelMapping](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ExamId] [int] NOT NULL,
	[LevelCode] [nvarchar](50) NOT NULL,
	[NumOfQuestions] [int] NULL,
 CONSTRAINT [PK_ExamLevelMapping] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ExamQuestionMapping]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ExamQuestionMapping](
	[ExamId] [int] NOT NULL,
	[QuestionId] [int] NOT NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_ExamQuestionMapping] PRIMARY KEY CLUSTERED 
(
	[ExamId] ASC,
	[QuestionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Level]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Level](
	[LevelCode] [nvarchar](50) NOT NULL,
	[LevelName] [nvarchar](200) NULL,
 CONSTRAINT [PK_Level] PRIMARY KEY CLUSTERED 
(
	[LevelCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[List]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[List](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ListCode] [nvarchar](50) NULL,
	[ListName] [nvarchar](250) NULL,
	[ListType] [nvarchar](50) NULL,
	[Status] [bit] NULL,
	[Description] [nvarchar](250) NULL,
	[UserCreate] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL,
 CONSTRAINT [PK_List] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LoginHistory]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginHistory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Username] [nvarchar](50) NULL,
	[Uid] [varchar](100) NULL,
	[LoginTime] [datetime] NULL,
	[LoginStatus] [int] NULL,
	[Token] [nvarchar](1000) NULL,
	[Retoken] [nvarchar](1000) NULL,
 CONSTRAINT [PK_LoginHistory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Notification]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Notification](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[Message] [nvarchar](500) NULL,
	[Usercreate] [nvarchar](50) NOT NULL,
	[UserReceived] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[Type] [int] NOT NULL,
 CONSTRAINT [PK_Notification] PRIMARY KEY CLUSTERED 
(
	[MessageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Permission]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Permission](
	[PermistionId] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[Method] [varchar](10) NOT NULL,
	[Url] [nvarchar](500) NOT NULL,
	[Status] [int] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[ParentId] [nvarchar](50) NULL,
	[IsMenu] [bit] NULL,
	[Position] [int] NULL,
	[Icon] [nvarchar](50) NULL,
 CONSTRAINT [PK_Permission] PRIMARY KEY CLUSTERED 
(
	[PermistionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Question]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Question](
	[QuestionId] [int] IDENTITY(1,1) NOT NULL,
	[QuestionName] [nvarchar](50) NULL,
	[Level] [nvarchar](50) NULL,
	[CreateDate] [datetime] NULL,
	[ModifyDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[Status] [int] NULL,
	[CateId] [int] NULL,
 CONSTRAINT [PK_Question] PRIMARY KEY CLUSTERED 
(
	[QuestionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QuestionCate]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QuestionCate](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[DateCreated] [datetime] NOT NULL,
	[Status] [int] NULL,
	[UserCreated] [nvarchar](10) NULL,
	[ModifyDate] [datetime] NULL,
	[ParentId] [int] NULL,
 CONSTRAINT [PK_QuestionCate] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Role](
	[RoleId] [varchar](50) NOT NULL,
	[RoleName] [nvarchar](100) NULL,
	[Description] [nvarchar](250) NULL,
	[CreatedDate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
	[Status] [int] NOT NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RolePermissionMapping]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RolePermissionMapping](
	[RoleId] [nvarchar](50) NOT NULL,
	[PermissionId] [nvarchar](50) NOT NULL,
	[Usercreate] [nvarchar](50) NULL,
	[DateCreate] [datetime] NULL,
 CONSTRAINT [PK_RolePermissionMapping] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC,
	[PermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Services]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Services](
	[ServiceCode] [nvarchar](50) NOT NULL,
	[ServiceName] [nvarchar](200) NOT NULL,
	[Type] [int] NULL,
	[CreateDate] [datetime] NULL,
	[UserCreated] [nvarchar](50) NULL,
	[Price] [decimal](18, 0) NOT NULL,
	[Status] [int] NOT NULL,
	[Training] [nvarchar](500) NULL,
 CONSTRAINT [PK_Services] PRIMARY KEY CLUSTERED 
(
	[ServiceCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[StudentClass]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StudentClass](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StudentId] [nvarchar](50) NOT NULL,
	[ClassId] [nvarchar](50) NOT NULL,
	[Checkin] [nvarchar](2000) NOT NULL,
	[Status] [int] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[UserCreate] [nvarchar](50) NOT NULL,
	[TotalLeave] [int] NULL,
 CONSTRAINT [PK_StudentClass] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TeacherClass]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TeacherClass](
	[Username] [nvarchar](50) NOT NULL,
	[ClassCode] [nvarchar](50) NOT NULL,
	[IsTeacher] [bit] NULL,
	[DateCreate] [datetime] NULL,
	[UserCreate] [nvarchar](50) NULL,
 CONSTRAINT [PK_TeacherClass] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Transaction]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Transaction](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](50) NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateBy] [nvarchar](50) NOT NULL,
	[Note] [nvarchar](max) NULL,
 CONSTRAINT [PK_Transaction] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[Username] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](500) NOT NULL,
	[Fullname] [nvarchar](100) NOT NULL,
	[Gender] [char](1) NULL,
	[Birthday] [date] NULL,
	[Avatar] [nvarchar](250) NULL,
	[School] [nvarchar](100) NULL,
	[Address] [nvarchar](50) NULL,
	[Status] [int] NOT NULL,
	[IsParents] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifyDate] [datetime] NULL,
	[LastLogin] [datetime] NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[Type] [int] NOT NULL,
	[ChildrenAccount] [nvarchar](50) NULL,
	[Title] [nvarchar](100) NULL,
	[Email] [nvarchar](150) NULL,
	[Phone] [nvarchar](50) NULL,
	[CreateBy] [nvarchar](50) NULL,
	[Services] [int] NULL,
	[UserServices] [nvarchar](max) NULL,
	[IdentityCard] [nvarchar](50) NULL,
	[BackAmount] [decimal](18, 2) NULL,
	[TotalPay] [decimal](18, 2) NULL,
	[Branch] [nvarchar](10) NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserExam]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserExam](
	[Username] [nvarchar](50) NOT NULL,
	[ExamId] [int] NOT NULL,
	[Score] [int] NULL,
	[IsPass] [bit] NULL,
	[CreateDate] [datetime] NULL,
 CONSTRAINT [PK_UserExam] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[ExamId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserRoleMapping]    Script Date: 03/16/2021 11:08:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserRoleMapping](
	[Username] [nvarchar](50) NOT NULL,
	[RoleId] [varchar](50) NOT NULL,
	[Usercreated] [nvarchar](50) NOT NULL,
	[DateCreate] [datetime] NOT NULL,
 CONSTRAINT [PK_UserRoleMapping] PRIMARY KEY CLUSTERED 
(
	[Username] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Answer] ON 
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1, N'1', N'2', CAST(N'2020-12-18T00:00:00.000' AS DateTime), NULL, N'admin', 1, 0, 1)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (2, N'2', N'2', CAST(N'2020-12-18T00:00:00.000' AS DateTime), NULL, N'admin', 1, 1, 1)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (3, N'3', N'2', CAST(N'2020-12-22T13:21:04.557' AS DateTime), CAST(N'2020-12-22T23:13:04.377' AS DateTime), NULL, 1, 0, 1)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (5, N'4', N'2', CAST(N'2020-12-22T23:14:24.693' AS DateTime), CAST(N'2020-12-22T23:19:13.577' AS DateTime), NULL, 1, 0, 1)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1003, N'test', N'2', CAST(N'2021-02-02T06:37:25.287' AS DateTime), NULL, NULL, 1, 0, 1005)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1004, N'test2', N'2', CAST(N'2021-02-02T06:37:38.837' AS DateTime), NULL, NULL, 1, 1, 1005)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1005, N'test3', N'2', CAST(N'2021-02-02T06:37:50.290' AS DateTime), NULL, NULL, 1, 0, 1005)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1006, N'test4', N'2', CAST(N'2021-02-02T06:38:09.347' AS DateTime), NULL, NULL, 1, 0, 1005)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1007, N'c1', N'2', CAST(N'2021-02-03T08:09:22.737' AS DateTime), NULL, NULL, 1, 0, 1016)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1008, N'c2', N'2', CAST(N'2021-02-03T08:09:31.243' AS DateTime), NULL, NULL, 1, 1, 1016)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1009, N'c3', N'2', CAST(N'2021-02-03T08:09:40.697' AS DateTime), NULL, NULL, 1, 0, 1016)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1010, N'cq', N'2', CAST(N'2021-02-03T08:11:06.057' AS DateTime), NULL, NULL, 1, 1, 1015)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1011, N'c2', N'2', CAST(N'2021-02-03T08:11:20.207' AS DateTime), NULL, NULL, 1, 0, 1015)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1012, N'c3', N'2', CAST(N'2021-02-03T08:11:29.497' AS DateTime), NULL, NULL, 1, 0, 1015)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1013, N'c1', N'2', CAST(N'2021-02-03T08:11:43.930' AS DateTime), NULL, NULL, 1, 0, 1014)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1014, N'c2', N'2', CAST(N'2021-02-03T08:11:51.177' AS DateTime), NULL, NULL, 1, 0, 1014)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1015, N'c3', N'2', CAST(N'2021-02-03T08:11:59.837' AS DateTime), NULL, NULL, 1, 0, 1014)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1016, N'c4', N'2', CAST(N'2021-02-03T08:12:10.740' AS DateTime), NULL, NULL, 1, 1, 1014)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1017, N'c1', N'2', CAST(N'2021-02-03T08:12:30.390' AS DateTime), NULL, NULL, 1, 1, 1013)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1018, N'a2', N'2', CAST(N'2021-02-03T08:12:38.763' AS DateTime), NULL, NULL, 1, 0, 1013)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1019, N'a1', N'2', CAST(N'2021-02-03T08:12:50.743' AS DateTime), NULL, NULL, 1, 0, 1012)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1020, N'a2', N'2', CAST(N'2021-02-03T08:13:00.357' AS DateTime), NULL, NULL, 1, 1, 1012)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1021, N'a1', N'2', CAST(N'2021-02-03T08:13:28.227' AS DateTime), NULL, NULL, 1, 0, 1011)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1022, N'a2', N'2', CAST(N'2021-02-03T08:13:35.483' AS DateTime), NULL, NULL, 1, 1, 1011)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1023, N'a1', N'2', CAST(N'2021-02-03T08:13:49.510' AS DateTime), NULL, NULL, 1, 1, 1010)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1024, N'a2', N'2', CAST(N'2021-02-03T08:13:56.277' AS DateTime), NULL, NULL, 1, 0, 1010)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1025, N'a1', N'2', CAST(N'2021-02-03T08:14:08.697' AS DateTime), NULL, NULL, 1, 0, 1009)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1026, N'a2', N'2', CAST(N'2021-02-03T08:14:15.043' AS DateTime), NULL, NULL, 1, 0, 1009)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1027, N'a3', N'2', CAST(N'2021-02-03T08:14:22.620' AS DateTime), NULL, NULL, 1, 1, 1009)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1028, N'a1', N'2', CAST(N'2021-02-03T08:14:34.917' AS DateTime), NULL, NULL, 1, 1, 1008)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1029, N'a2', N'2', CAST(N'2021-02-03T08:14:42.083' AS DateTime), NULL, NULL, 1, 1, 1008)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1030, N'a1', N'2', CAST(N'2021-02-03T08:15:17.217' AS DateTime), NULL, NULL, 1, 0, 1007)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1031, N'a2', N'2', CAST(N'2021-02-03T08:15:26.097' AS DateTime), NULL, NULL, 1, 1, 1007)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1032, N'a1', N'2', CAST(N'2021-02-03T08:16:33.200' AS DateTime), NULL, NULL, 1, 0, 1006)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1033, N'a2', N'2', CAST(N'2021-02-03T08:16:41.437' AS DateTime), NULL, NULL, 1, 1, 1006)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1034, N'1', N'2', CAST(N'2021-02-04T00:25:50.010' AS DateTime), NULL, NULL, 1, 0, 1017)
GO
INSERT [dbo].[Answer] ([AnswerId], [AnswerName], [AnswerType], [CreateDate], [ModifyDate], [UserCreate], [Status], [IsRightAnswer], [QuestionId]) VALUES (1035, N'2', N'2', CAST(N'2021-02-04T00:39:56.670' AS DateTime), NULL, NULL, 1, 0, 1017)
GO
SET IDENTITY_INSERT [dbo].[Answer] OFF
GO
INSERT [dbo].[AnswerType] ([Type], [TypeName], [CreateDate]) VALUES (N'1', N'Checkbox', CAST(N'2020-12-16T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[AnswerType] ([Type], [TypeName], [CreateDate]) VALUES (N'2', N'Radio', CAST(N'2020-12-16T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[BackAmount] ([Code], [BackAmount], [CreateDate], [CreateBy]) VALUES (N'CAP_1', CAST(1000000 AS Decimal(18, 0)), CAST(N'2020-12-25T13:35:14.853' AS DateTime), N'admin')
GO
INSERT [dbo].[BackAmount] ([Code], [BackAmount], [CreateDate], [CreateBy]) VALUES (N'CAP_2', CAST(500000 AS Decimal(18, 0)), CAST(N'2020-12-25T13:49:13.603' AS DateTime), N'admin')
GO
INSERT [dbo].[BackAmount] ([Code], [BackAmount], [CreateDate], [CreateBy]) VALUES (N'CAP_3', CAST(200000 AS Decimal(18, 0)), CAST(N'2020-12-25T23:55:59.900' AS DateTime), N'admin')
GO
SET IDENTITY_INSERT [dbo].[BackAmountHistory] ON 
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (1, N'0336533503', CAST(166667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:41.047' AS DateTime), N'admin', CAST(0.00 AS Decimal(18, 2)), CAST(166667.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (2, N'0336533501', CAST(833333.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:42.627' AS DateTime), N'admin', CAST(0.00 AS Decimal(18, 2)), CAST(833333.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (3, N'0336533500', CAST(566667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:43.433' AS DateTime), N'admin', CAST(0.00 AS Decimal(18, 2)), CAST(566667.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (4, N'admin', CAST(100000.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:44.323' AS DateTime), N'admin', CAST(0.00 AS Decimal(18, 2)), CAST(100000.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (5, N'0336533503', CAST(166667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:48.000' AS DateTime), N'admin', CAST(166667.00 AS Decimal(18, 2)), CAST(333334.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (6, N'0336533501', CAST(833333.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:48.837' AS DateTime), N'admin', CAST(833333.00 AS Decimal(18, 2)), CAST(1666666.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (7, N'0336533500', CAST(566667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:49.627' AS DateTime), N'admin', CAST(566667.00 AS Decimal(18, 2)), CAST(1133334.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (8, N'admin', CAST(100000.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:50.437' AS DateTime), N'admin', CAST(100000.00 AS Decimal(18, 2)), CAST(200000.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (9, N'0336533503', CAST(166667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:54.387' AS DateTime), N'admin', CAST(333334.00 AS Decimal(18, 2)), CAST(500001.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (10, N'0336533501', CAST(833333.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:55.627' AS DateTime), N'admin', CAST(1666666.00 AS Decimal(18, 2)), CAST(2499999.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (11, N'0336533500', CAST(566667.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:56.547' AS DateTime), N'admin', CAST(1133334.00 AS Decimal(18, 2)), CAST(1700001.00 AS Decimal(18, 2)), 0, NULL)
GO
INSERT [dbo].[BackAmountHistory] ([ID], [UserId], [Amount], [CreateDate], [UserCreate], [CurrentAmount], [NewAmount], [BalanceId], [Note]) VALUES (12, N'admin', CAST(100000.00 AS Decimal(18, 2)), CAST(N'2021-03-16T13:14:57.427' AS DateTime), N'admin', CAST(200000.00 AS Decimal(18, 2)), CAST(300000.00 AS Decimal(18, 2)), 0, NULL)
GO
SET IDENTITY_INSERT [dbo].[BackAmountHistory] OFF
GO
SET IDENTITY_INSERT [dbo].[BalanceHistory] ON 
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (1, N'anhdv', CAST(20000000.00 AS Decimal(18, 2)), 1, 1, CAST(N'2020-12-23T00:27:02.640' AS DateTime), N'nghianh', N'User đã chyển tiền', CAST(N'2020-12-26T17:51:42.270' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (2, N'anhdv', CAST(20000000.00 AS Decimal(18, 2)), 1, 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'nghianh', N'User chuyển tiền đợt 2', CAST(N'2020-12-26T17:51:37.150' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (3, N'0111111111', CAST(30000.00 AS Decimal(18, 2)), 1, 2, CAST(N'2021-03-15T21:47:34.277' AS DateTime), N'admin', N'chung bei', NULL)
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (4, N'0111111111', CAST(30000.00 AS Decimal(18, 2)), 1, 2, CAST(N'2021-03-15T21:55:39.753' AS DateTime), N'admin', N'chung bei', NULL)
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (5, N'0111111111', CAST(30000.00 AS Decimal(18, 2)), 1, 2, CAST(N'2021-03-15T21:55:55.047' AS DateTime), N'admin', N'chung bei', NULL)
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (6, N'0111111111', CAST(3000.00 AS Decimal(18, 2)), 1, 1, CAST(N'2021-03-15T21:58:26.057' AS DateTime), N'admin', N'nộp tiền học', CAST(N'2021-03-16T00:32:07.253' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (7, N'0336533600', CAST(3000000.00 AS Decimal(18, 2)), 2, 1, CAST(N'2021-03-16T10:11:59.163' AS DateTime), N'0336533503', N'chung nộp tiền
', CAST(N'2021-03-16T10:51:43.593' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (8, N'0336533601', CAST(10000000.00 AS Decimal(18, 2)), 2, 1, CAST(N'2021-03-16T11:51:49.447' AS DateTime), N'admin', N'lần 1', CAST(N'2021-03-16T13:14:45.093' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (9, N'0336533601', CAST(10000000.00 AS Decimal(18, 2)), 2, 1, CAST(N'2021-03-16T11:52:16.730' AS DateTime), N'admin', N'lần 2', CAST(N'2021-03-16T13:14:51.257' AS DateTime))
GO
INSERT [dbo].[BalanceHistory] ([ID], [Username], [Amount], [Type], [Status], [CreatedDate], [CreatedUser], [Note], [ApproveDate]) VALUES (10, N'0336533601', CAST(10000000.00 AS Decimal(18, 2)), 2, 1, CAST(N'2021-03-16T11:52:41.590' AS DateTime), N'admin', N'lần 3', CAST(N'2021-03-16T13:14:58.203' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[BalanceHistory] OFF
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'AWS', N'Amazon Web Service', NULL, -1, CAST(N'2021-01-04T00:00:00.000' AS DateTime), CAST(N'2021-01-28T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-03T09:49:01.443' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":true,"evn":true,"mor":true},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":true}]}', 3, N'A1,A2,A3,A4,A5', 30, 6, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'C9898', N'Lap Trinh', NULL, 1, CAST(N'2021-02-11T00:00:00.000' AS DateTime), CAST(N'2021-03-19T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-02T00:52:13.253' AS DateTime), CAST(N'2021-03-16T15:06:46.113' AS DateTime), NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 3, N'A1,A2,A3,A4,A5', 0, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'HGF', N'Dev 3', NULL, 1, CAST(N'2021-01-04T00:00:00.000' AS DateTime), CAST(N'2021-03-28T00:00:00.000' AS DateTime), 59, CAST(N'2021-01-03T10:16:44.333' AS DateTime), NULL, NULL, 5, N'["timeNodes": <__NSArrayI 0x600003bc4640>(
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 0;
},
{
    aft = 0;
    evn = 0;
    mor = 0;
}
)
]', 3, N'A1,A2,A3,A4,A5', 59, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'HHHH', N'HTML', NULL, 1, CAST(N'2021-01-02T00:00:00.000' AS DateTime), CAST(N'2021-07-31T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-02T03:25:28.000' AS DateTime), NULL, NULL, 5, N'', 3, N'A1,A2,A3,A4,A5', 30, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'HSN98', N'PHP', NULL, 1, CAST(N'2021-01-02T00:00:00.000' AS DateTime), CAST(N'2021-02-13T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-02T01:51:58.577' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 3, N'A1,A2,A3,A4,A5', 30, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'IUTR', N'Nsfo', NULL, 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), CAST(N'2021-02-15T00:00:00.000' AS DateTime), 52, CAST(N'2020-12-25T08:32:47.403' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":true,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":true},{"aft":true,"evn":true,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 3, N'A2,A4,A5', 59, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'KIMIK', N'Auto Test', NULL, 1, CAST(N'2021-01-04T00:00:00.000' AS DateTime), CAST(N'2021-02-08T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-03T09:45:57.440' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":true,"evn":true,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":false}]}', 3, N'A1,A2,A3,A4,A5', 30, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'LEAK', N'Hack', NULL, 1, CAST(N'2020-12-26T00:00:00.000' AS DateTime), CAST(N'2021-01-31T00:00:00.000' AS DateTime), 25, CAST(N'2020-12-25T09:24:02.560' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 6, N'A1,A2,A3,A4', 36, 3, 5)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'LOPH', N'Ghê Quá', NULL, -1, NULL, NULL, 63, CAST(N'2020-12-25T08:18:30.230' AS DateTime), NULL, NULL, 0, NULL, 6, N'A1,A2', 36, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'LOPHOC1', N'lớp học', NULL, -1, NULL, NULL, 10, CAST(N'2020-12-20T00:00:00.000' AS DateTime), NULL, NULL, 1, NULL, 1, N'A1,A2', NULL, NULL, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'LOPHOC2', N'lớp học', NULL, -1, NULL, NULL, 10, CAST(N'2020-12-23T22:58:47.907' AS DateTime), NULL, NULL, 1, NULL, 1, N'A1,A2', NULL, NULL, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'LOPHOC3', N'lớp học', NULL, 1, NULL, NULL, 10, CAST(N'2020-12-23T22:59:00.647' AS DateTime), NULL, NULL, 1, NULL, 1, N'A1,A3', NULL, NULL, 1)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'MD1', N'Lớp Mầm Non Tiếng Đức', NULL, 1, CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-05-02T00:00:00.000' AS DateTime), 60, CAST(N'2021-03-16T14:46:07.270' AS DateTime), NULL, NULL, 1015, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":true,"evn":true,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":true,"evn":true,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":true,"evn":true,"mor":true},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 5, N'A1', 60, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'MD2', N'Lop Demo', NULL, 1, CAST(N'2021-03-25T00:00:00.000' AS DateTime), CAST(N'2021-06-21T00:00:00.000' AS DateTime), 60, CAST(N'2021-03-16T16:43:18.743' AS DateTime), NULL, NULL, 1015, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 5, N'A1,A2,A3,A4,A5', 50, 1, 1)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'RHRHRJJR', N'Rhrhrjtj', NULL, -1, NULL, NULL, 58, CAST(N'2020-12-25T08:29:14.447' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 5, N'A1,A3,A4,A5', 63, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'TEK', N'Tecko', NULL, 1, CAST(N'2021-03-26T00:00:00.000' AS DateTime), CAST(N'2021-05-15T00:00:00.000' AS DateTime), 60, CAST(N'2021-03-16T13:28:37.157' AS DateTime), NULL, NULL, 1011, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":true,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":true},{"aft":true,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":false,"mor":true}]}', 3, N'A1', 50, 1, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'TFT', N'Dev2', NULL, 1, CAST(N'2021-01-04T00:00:00.000' AS DateTime), CAST(N'2021-02-15T00:00:00.000' AS DateTime), 230, CAST(N'2021-01-03T10:14:43.353' AS DateTime), NULL, NULL, 5, N'[:]', 3, N'A1,A2,A3,A4,A5', 30, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'TGT', N'Dev 1', NULL, -1, CAST(N'2021-01-04T00:00:00.000' AS DateTime), CAST(N'2021-01-31T00:00:00.000' AS DateTime), 30, CAST(N'2021-01-03T10:12:31.757' AS DateTime), NULL, NULL, 5, N'["timeNodes": <__NSArrayI 0x600002720280>(
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 1;
    evn = 0;
    mor = 0;
},
{
    aft = 0;
    evn = 1;
    mor = 0;
},
{
    aft = 1;
    evn = 0;
    mor = 0;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 0;
    evn = 0;
    mor = 1;
},
{
    aft = 1;
    evn = 1;
    mor = 0;
}
)
]', 3, N'A1,A2,A3,A4,A5', 30, 0, NULL)
GO
INSERT [dbo].[Class] ([ClassCode], [ClassName], [Avatar], [Status], [BeginDate], [EndDate], [MaxTotalStudent], [CreateDate], [ModifyDate], [UserCreate], [CourseId], [TimeTable], [MaxDayOff], [Services], [NumberLesson], [TotalCurrentStudent], [TotalHaveLearnt]) VALUES (N'UHHTYG', N'Hiu Uiu', NULL, -1, NULL, NULL, 58, CAST(N'2020-12-25T08:28:05.320' AS DateTime), NULL, NULL, 5, N'{"number":0,"serviceTitle":"","timeNodes":[{"aft":false,"evn":false,"mor":false},{"aft":true,"evn":false,"mor":false},{"aft":false,"evn":true,"mor":false},{"aft":false,"evn":true,"mor":false},{"aft":true,"evn":false,"mor":true},{"aft":false,"evn":true,"mor":false},{"aft":false,"evn":false,"mor":false}]}', 3, N'A2,A3,A5', 63, 0, NULL)
GO
SET IDENTITY_INSERT [dbo].[Course] ON 
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1, N'COURSE1', N'test tạo khóa học 2', CAST(N'2020-12-20T00:00:00.000' AS DateTime), CAST(N'2020-12-31T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-20T12:57:34.470' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (2, N'Course 1', N'test', CAST(N'2020-12-09T00:00:00.000' AS DateTime), CAST(N'2020-12-25T00:00:00.000' AS DateTime), -1, CAST(N'2020-12-20T13:02:51.733' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (3, N'test', N'test', CAST(N'2020-12-22T00:00:00.000' AS DateTime), CAST(N'2020-12-26T00:00:00.000' AS DateTime), -1, CAST(N'2020-12-20T13:37:36.183' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (4, N'Khóa 56', N'Lêu lêu', CAST(N'2020-12-11T00:00:00.000' AS DateTime), CAST(N'2020-12-19T00:00:00.000' AS DateTime), -1, CAST(N'2020-12-21T07:12:47.430' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (5, N'COURSE 2', N'test', CAST(N'2020-12-01T00:00:00.000' AS DateTime), CAST(N'2020-12-25T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-21T22:55:21.480' AS DateTime), N'admin', N'KG')
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (6, N'K56', N'Khóa này để test', CAST(N'2020-12-24T00:00:00.000' AS DateTime), CAST(N'2020-12-31T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-22T07:12:11.663' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (7, N'K53', N'Khóa Thể Chất', CAST(N'2020-12-24T00:00:00.000' AS DateTime), CAST(N'2021-01-15T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-22T08:17:52.503' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (8, N'Khóa 76', N'Hụdkdj
Jdjdjdjd
Uuhehe', CAST(N'2020-12-25T00:00:00.000' AS DateTime), CAST(N'2021-01-08T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-22T08:19:55.810' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (9, N'Khóa Quay Đầu', NULL, CAST(N'2021-01-01T00:00:00.000' AS DateTime), CAST(N'2021-01-08T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-22T08:33:33.997' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1006, N'CSDL', N'Co So Du Lieu', CAST(N'2020-12-27T00:00:00.000' AS DateTime), CAST(N'2021-03-27T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-27T06:40:19.557' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1007, N'CTDLGT', N'Cau Truc Du Lieu Gai Thuat', CAST(N'2020-12-27T00:00:00.000' AS DateTime), CAST(N'2021-03-27T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-27T08:06:33.290' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1008, N'YK', NULL, CAST(N'2020-12-27T00:00:00.000' AS DateTime), CAST(N'2021-03-27T00:00:00.000' AS DateTime), 1, CAST(N'2020-12-27T08:07:04.570' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1009, N'test123', N'', CAST(N'2021-03-02T00:00:00.000' AS DateTime), CAST(N'2021-03-27T00:00:00.000' AS DateTime), -1, CAST(N'2021-03-12T17:12:59.780' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1010, N'course Test', N'12312312', CAST(N'2021-03-02T00:00:00.000' AS DateTime), CAST(N'2021-03-12T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-15T00:34:37.707' AS DateTime), N'admin', N'MD')
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1011, N'Khóa Mỹ Đình 2021', N'Khóa Mới', CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-05-21T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T13:20:25.297' AS DateTime), N'0336533800', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1012, N'Khóa Test', N'Leu', CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-04-23T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T13:22:24.280' AS DateTime), N'0336533800', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1013, N'Khóa Mỹ Đình Mới', N'Niawx ', CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-06-16T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T14:32:27.227' AS DateTime), N'0336533800', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1014, N'Mỹ Đình Lần Nữa', N'Shhshshshs', CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-06-16T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T14:33:45.617' AS DateTime), N'0336533800', NULL)
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1015, N'Mỹ Đình 2021', N'Khóa Test', CAST(N'2021-04-01T00:00:00.000' AS DateTime), CAST(N'2021-05-20T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T14:37:48.820' AS DateTime), N'0336533800', N'MD')
GO
INSERT [dbo].[Course] ([Id], [Name], [Description], [StartDate], [EndDate], [Status], [CreatedDate], [CreatedBy], [Branch]) VALUES (1016, N'K58', N'Khos Frm', CAST(N'2021-03-16T00:00:00.000' AS DateTime), CAST(N'2021-06-16T00:00:00.000' AS DateTime), 1, CAST(N'2021-03-16T17:48:35.430' AS DateTime), N'admin', NULL)
GO
SET IDENTITY_INSERT [dbo].[Course] OFF
GO
SET IDENTITY_INSERT [dbo].[Exam] ON 
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (2, N'test kiểm tra tốc độ', 80, 0, CAST(N'2020-11-12T15:38:11.657' AS DateTime), N'string', NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (3, N'kiểm tra tiếng anh ', 100, -1, CAST(N'2020-12-16T15:47:24.007' AS DateTime), N'admin', NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (4, N'test tiếng anh 3', 100, 1, CAST(N'2020-12-16T15:48:42.457' AS DateTime), N'admin', NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (5, N'test 2', 111, 1, CAST(N'2020-12-16T15:49:31.317' AS DateTime), N'admin', NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (6, NULL, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (7, N'Exam1', 100, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (8, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:41:13.550' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (9, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:44:16.503' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (10, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:46:23.837' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (11, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:47:15.337' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (14, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:49:17.117' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (15, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:51:36.950' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (16, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-02T21:57:03.173' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (17, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-03T21:55:16.573' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (18, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-03T21:59:50.100' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (19, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-03T22:01:41.257' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (20, N'Test tạo bài kiểm tra', 7, 1, CAST(N'2021-02-03T22:05:17.857' AS DateTime), N'admin', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (21, N'Jdhdjd Jdjdjd', 25, 1, CAST(N'2021-02-27T06:33:13.417' AS DateTime), N'admin', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (22, N'Jhdhdh Hdhdhd', 25, 1, CAST(N'2021-02-27T06:38:27.537' AS DateTime), N'admin', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (23, N'Iihgivhivhi', 25, 1, CAST(N'2021-02-27T06:49:35.250' AS DateTime), N'admin', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (24, N'Quất', 25, 1, CAST(N'2021-02-27T06:54:49.013' AS DateTime), N'admin', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (25, N'Quất Nữa', 25, 1, CAST(N'2021-02-27T07:07:00.647' AS DateTime), N'admin', 1, 25)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (26, N'Test tạo bài kiểm tra 2', 7, 1, CAST(N'2021-03-03T22:25:58.250' AS DateTime), N'', 1, 30)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (27, N'Test Dub', 25, 1, CAST(N'2021-03-03T07:30:20.420' AS DateTime), N'admin', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (28, N'Bài Kiểm Tra Tử Tế', 15, 1, CAST(N'2021-03-14T16:50:58.933' AS DateTime), N'', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (29, N'Bài Kiểm Tra Tử Tế', 15, 1, CAST(N'2021-03-14T16:50:59.370' AS DateTime), N'', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (30, N'Kiểm Tra 1 Tiết', 25, 1, CAST(N'2021-03-16T12:41:53.787' AS DateTime), N'', 1, 60)
GO
INSERT [dbo].[Exam] ([ExamId], [ExamName], [PassPoint], [Status], [CreateDate], [UserCreate], [QuestionCateId], [TestTime]) VALUES (31, N'Test Demo', 9, 1, CAST(N'2021-03-16T17:31:45.853' AS DateTime), N'', 1, 45)
GO
SET IDENTITY_INSERT [dbo].[Exam] OFF
GO
SET IDENTITY_INSERT [dbo].[ExamHistory] ON 
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (1, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T15:54:13.240' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (2, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T16:02:33.587' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (3, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T16:40:16.503' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (4, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T16:40:21.910' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (5, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T16:40:27.753' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (6, 24, N'0111111111', 12, 0, CAST(N'2021-03-14T16:42:05.520' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (7, 26, N'0111111111', 6, 0, CAST(N'2021-03-14T16:42:11.473' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (8, 24, N'0111111111', 13, 0, CAST(N'2021-03-14T16:44:23.553' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (9, 26, N'0111111111', 6, 0, CAST(N'2021-03-14T16:44:28.773' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (10, 25, N'0111111111', 12, 0, CAST(N'2021-03-14T16:45:02.850' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (11, 26, N'0111111111', 6, 0, CAST(N'2021-03-14T16:48:06.323' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (12, 24, N'0111111111', 10, 0, CAST(N'2021-03-14T17:37:41.553' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (13, 27, N'0111111111', 7, 0, CAST(N'2021-03-14T17:37:46.673' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (14, 26, N'0111111111', 7, 1, CAST(N'2021-03-14T17:37:50.610' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (15, 26, N'0111111111', 7, 1, CAST(N'2021-03-14T17:37:54.470' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (16, 28, N'0111111111', 9, 0, CAST(N'2021-03-14T17:38:49.957' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (17, 27, N'0111111111', 7, 0, CAST(N'2021-03-14T17:38:56.563' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (18, 28, N'0111111111', 6, 0, CAST(N'2021-03-14T20:42:40.507' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (19, 28, N'0111111111', 6, 0, CAST(N'2021-03-14T21:13:27.683' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (20, 28, N'0111111111', 6, 0, CAST(N'2021-03-14T21:33:13.477' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (21, 28, N'0111111111', 8, 0, CAST(N'2021-03-14T21:34:17.570' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (22, 28, N'0111111111', 8, 0, CAST(N'2021-03-14T21:36:44.247' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (23, 28, N'0111111111', 0, 0, CAST(N'2021-03-14T21:51:47.187' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (24, 28, N'0111111111', 0, 0, CAST(N'2021-03-14T21:52:22.920' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (25, 28, N'0111111111', 1, 0, CAST(N'2021-03-14T22:01:57.347' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (26, 28, N'0111111111', 1, 0, CAST(N'2021-03-14T22:02:04.503' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (27, 28, N'0111111111', 0, 0, CAST(N'2021-03-14T22:02:14.753' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (28, 28, N'0111111111', 0, 0, CAST(N'2021-03-14T22:02:23.677' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (29, 28, N'0111111111', 1, 0, CAST(N'2021-03-14T22:03:11.990' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (30, 28, N'0111111111', 1, 0, CAST(N'2021-03-14T22:03:55.850' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (31, 28, N'0111111111', 0, 0, CAST(N'2021-03-14T23:09:23.020' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (32, 20, N'admin', 0, 0, CAST(N'2021-03-15T00:24:17.560' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (33, 20, N'admin', 0, 0, CAST(N'2021-03-16T03:12:48.733' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (34, 20, N'admin', 0, 0, CAST(N'2021-03-16T09:08:15.547' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (35, 20, N'admin', 0, 0, CAST(N'2021-03-16T09:49:01.323' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (36, 20, N'admin', 1, 0, CAST(N'2021-03-16T12:11:21.257' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (37, 20, N'admin', 0, 0, CAST(N'2021-03-16T14:28:20.667' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (38, 30, N'admin', 0, 0, CAST(N'2021-03-16T15:02:39.237' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
INSERT [dbo].[ExamHistory] ([Id], [ExamId], [UserId], [TotalCore], [PassOrNotPass], [CreateDate], [UserAnswerKey]) VALUES (39, 31, N'0336533599', 4, 0, CAST(N'2021-03-16T17:32:37.603' AS DateTime), N'System.Collections.Generic.List`1[CMS.WEBAPI.MODEL.AnswerRequestModel]')
GO
SET IDENTITY_INSERT [dbo].[ExamHistory] OFF
GO
SET IDENTITY_INSERT [dbo].[ExamLevelMapping] ON 
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (0, 8, N'E', 2)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (1, 20, N'E', 2)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (2, 20, N'VE', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (3, 20, N'M', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (4, 21, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (5, 21, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (6, 21, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (7, 21, N'M', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (8, 21, N'VE', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (9, 22, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (10, 22, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (11, 22, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (12, 22, N'M', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (13, 22, N'VE', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (14, 23, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (15, 23, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (16, 23, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (17, 23, N'M', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (18, 23, N'VE', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (19, 24, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (20, 24, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (21, 24, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (22, 24, N'M', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (23, 24, N'VE', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (24, 25, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (25, 25, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (26, 25, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (27, 25, N'M', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (28, 25, N'VE', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (29, 26, N'E', 2)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (30, 26, N'VE', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (31, 26, N'M', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (32, 27, N'D', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (33, 27, N'E', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (34, 27, N'ED', 9)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (35, 27, N'M', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (36, 27, N'VE', 0)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (37, 28, N'D', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (38, 28, N'E', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (39, 28, N'ED', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (40, 28, N'M', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (41, 28, N'VE', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (42, 29, N'D', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (43, 29, N'E', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (44, 29, N'ED', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (45, 29, N'M', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (46, 29, N'VE', 3)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (47, 30, N'D', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (48, 30, N'E', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (49, 30, N'ED', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (50, 30, N'M', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (51, 30, N'VE', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (52, 31, N'D', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (53, 31, N'E', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (54, 31, N'ED', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (55, 31, N'M', 5)
GO
INSERT [dbo].[ExamLevelMapping] ([Id], [ExamId], [LevelCode], [NumOfQuestions]) VALUES (56, 31, N'VE', 5)
GO
SET IDENTITY_INSERT [dbo].[ExamLevelMapping] OFF
GO
INSERT [dbo].[Level] ([LevelCode], [LevelName]) VALUES (N'D', N'Khó')
GO
INSERT [dbo].[Level] ([LevelCode], [LevelName]) VALUES (N'E', N'Dễ')
GO
INSERT [dbo].[Level] ([LevelCode], [LevelName]) VALUES (N'ED', N'Cực khó')
GO
INSERT [dbo].[Level] ([LevelCode], [LevelName]) VALUES (N'M', N'Trung bình')
GO
INSERT [dbo].[Level] ([LevelCode], [LevelName]) VALUES (N'VE', N'Cực dễ')
GO
SET IDENTITY_INSERT [dbo].[List] ON 
GO
INSERT [dbo].[List] ([Id], [ListCode], [ListName], [ListType], [Status], [Description], [UserCreate], [DateCreate]) VALUES (2, N'test2', N'test2', N'test2', 1, N'string', N'string', CAST(N'2020-11-13T23:48:08.807' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[List] OFF
GO
SET IDENTITY_INSERT [dbo].[Notification] ON 
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (1, N'Test message', N'nghianh', N'admin', CAST(N'2021-01-05T00:00:00.000' AS DateTime), NULL, 0)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (2, NULL, N'system', N'nghianh', CAST(N'2021-01-08T12:37:30.453' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (3, NULL, N'system', N'nghianh', CAST(N'2021-01-08T13:44:01.987' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (4, NULL, N'system', N'nghianh', CAST(N'2021-01-08T13:49:20.127' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (5, NULL, N'system', N'nghianh', CAST(N'2021-01-08T14:06:46.750' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (6, NULL, N'system', N'nghianh', CAST(N'2021-01-08T14:43:43.257' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (7, NULL, N'system', N'nghianh', CAST(N'2021-01-12T14:38:15.890' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (8, NULL, N'system', N'nghianh', CAST(N'2021-01-12T00:18:00.957' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (9, NULL, N'system', N'nghianh', CAST(N'2021-01-12T00:19:09.633' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (10, NULL, N'system', N'nghianh', CAST(N'2021-01-12T00:23:08.673' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (11, NULL, N'system', N'nghianh', CAST(N'2021-01-12T00:23:34.077' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (12, NULL, N'admin', N'Subscribed Users', CAST(N'2021-02-03T01:20:55.890' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (13, N'Bạn đã được hoàn lại  VNĐ vào tài khoản, tổng số tiền hiện tại là  VNĐ', N'system', N'admin', CAST(N'2021-03-15T22:21:04.717' AS DateTime), NULL, 0)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (14, N'Bạn đã được hoàn lại  VNĐ vào tài khoản, tổng số tiền hiện tại là  VNĐ', N'system', N'admin', CAST(N'2021-03-15T23:39:51.277' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (15, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'admin', CAST(N'2021-03-15T23:44:35.833' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (16, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'admin', CAST(N'2021-03-15T23:53:24.157' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (17, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'admin', CAST(N'2021-03-16T00:26:16.877' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (18, N'Bạn đã được hoàn lại 1,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T00:32:06.660' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (19, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'admin', CAST(N'2021-03-16T10:12:40.943' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (20, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T10:12:41.537' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (21, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T10:12:41.850' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (22, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T10:12:42.180' AS DateTime), NULL, 0)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (23, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'admin', CAST(N'2021-03-16T10:38:02.230' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (24, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T10:38:04.067' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (25, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T10:38:05.010' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (26, N'Bạn đã được hoàn lại 0 VNĐ vào tài khoản, tổng số tiền hiện tại là 0 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T10:38:06.223' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (27, N'Bạn đã được hoàn lại 9,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 10,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T10:47:28.153' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (28, N'Bạn đã được hoàn lại 450,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 450,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T10:47:29.793' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (29, N'Bạn đã được hoàn lại 270,000,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 270,000,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T10:47:31.233' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (30, N'Bạn đã được hoàn lại 360,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 360,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T10:47:32.297' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (31, N'Bạn đã được hoàn lại 9,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 19,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T10:49:48.523' AS DateTime), NULL, 0)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (32, N'Bạn đã được hoàn lại 450,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 900,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T10:51:04.323' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (33, N'Bạn đã được hoàn lại 270,000,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 540,000,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T10:51:40.323' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (34, N'Bạn đã được hoàn lại 360,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 720,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T10:51:42.663' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (35, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 165,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:42:53.327' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (36, N'Bạn đã được hoàn lại 990,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 990,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:42:54.673' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (37, N'Bạn đã được hoàn lại 1,551,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,551,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:42:55.650' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (38, N'Bạn đã được hoàn lại 1,650,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,650,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:42:56.523' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (39, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 165,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:49:06.350' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (40, N'Bạn đã được hoàn lại -990,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -990,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:49:39.647' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (41, N'Bạn đã được hoàn lại -1,551,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -1,551,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:49:43.850' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (42, N'Bạn đã được hoàn lại -1,650,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -1,650,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:49:44.883' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (43, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 165,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:51:56.690' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (44, N'Bạn đã được hoàn lại -825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -825,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:52:09.703' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (45, N'Bạn đã được hoàn lại -396,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -396,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:52:11.603' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (46, N'Bạn đã được hoàn lại 1,056,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,056,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:52:13.143' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (47, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 330,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:53:03.383' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (48, N'Bạn đã được hoàn lại -825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -1,650,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:53:04.573' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (49, N'Bạn đã được hoàn lại -396,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -792,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:53:05.383' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (50, N'Bạn đã được hoàn lại 1,056,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 2,112,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:53:06.210' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (51, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 495,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:53:11.563' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (52, N'Bạn đã được hoàn lại -825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -2,475,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:53:12.373' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (53, N'Bạn đã được hoàn lại -396,000 VNĐ vào tài khoản, tổng số tiền hiện tại là -1,188,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:53:13.190' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (54, N'Bạn đã được hoàn lại 1,056,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 3,168,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:53:14.173' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (55, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 165,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T12:58:16.060' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (56, N'Bạn đã được hoàn lại 825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 825,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T12:58:17.440' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (57, N'Bạn đã được hoàn lại 561,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 561,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T12:58:18.277' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (58, N'Bạn đã được hoàn lại 99,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 99,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T12:58:19.160' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (59, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 330,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:01:00.120' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (60, N'Bạn đã được hoàn lại 825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,650,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:01:01.200' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (61, N'Bạn đã được hoàn lại 561,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,122,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:01:02.000' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (62, N'Bạn đã được hoàn lại 99,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 198,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:01:02.803' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (63, N'Bạn đã được hoàn lại 165,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 495,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:01:06.900' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (64, N'Bạn đã được hoàn lại 825,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 2,475,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:01:07.930' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (65, N'Bạn đã được hoàn lại 561,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,683,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:01:08.817' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (66, N'Bạn đã được hoàn lại 99,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 297,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:01:09.690' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (67, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 166,667 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:08:43.320' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (68, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 833,333 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:08:44.630' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (69, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 566,667 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:08:45.533' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (70, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 100,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:08:46.390' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (71, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 333,333 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:09:21.140' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (72, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,666,667 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:09:22.037' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (73, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,133,333 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:09:22.920' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (74, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 200,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:09:23.827' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (75, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 500,000 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:09:27.780' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (76, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 2,500,000 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:09:28.650' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (77, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,700,000 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:09:29.513' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (78, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 300,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:09:30.340' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (79, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 166,667 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:14:41.320' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (80, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 833,333 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:14:42.770' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (81, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 566,667 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:14:43.647' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (82, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 100,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:14:44.470' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (83, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 333,334 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:14:48.187' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (84, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,666,666 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:14:48.980' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (85, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,133,334 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:14:49.790' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (86, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 200,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:14:50.580' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (87, N'Bạn đã được hoàn lại 166,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 500,001 VNĐ', N'system', N'0336533503', CAST(N'2021-03-16T13:14:54.943' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (88, N'Bạn đã được hoàn lại 833,333 VNĐ vào tài khoản, tổng số tiền hiện tại là 2,499,999 VNĐ', N'system', N'0336533501', CAST(N'2021-03-16T13:14:55.820' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (89, N'Bạn đã được hoàn lại 566,667 VNĐ vào tài khoản, tổng số tiền hiện tại là 1,700,001 VNĐ', N'system', N'0336533500', CAST(N'2021-03-16T13:14:56.703' AS DateTime), NULL, 1)
GO
INSERT [dbo].[Notification] ([MessageId], [Message], [Usercreate], [UserReceived], [DateCreate], [ModifyDate], [Type]) VALUES (90, N'Bạn đã được hoàn lại 100,000 VNĐ vào tài khoản, tổng số tiền hiện tại là 300,000 VNĐ', N'system', N'admin', CAST(N'2021-03-16T13:14:57.587' AS DateTime), NULL, 0)
GO
SET IDENTITY_INSERT [dbo].[Notification] OFF
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_ANSWER', N'Add câu trả lời', N'POST', N'/api/answer/add', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_CLASS', N'thêm lớp học ', N'POST', N'/api/class', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_COURSE', N'Thêm Khóa Học ', N'POST', N'/api/course', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_EXAM', N'Thêm bài kiểm tra', N'POST', N'/api/exam', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_EXAM_QUESTION_MAPPING', N'thêm mapping ', N'POST', N'/api/ExamQuestionMapping', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_QUESTION', N'Thêm mới câu hỏi', N'POST', N'/api/question/add', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_ROLE', N'Thêm mới quyền', N'POST', N'/api/role/add', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_TEACHER_CLASS', N'thêm giáo viên theo lớp học ', N'POST', N'/api/teacherClass', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_TEACHER_TO_CLASS', N'Thêm giáo viên vào lớp học', N'POST', N'/api/user/addTeacherToClass', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ADD_USER_TO_CLASS', N'Thêm học sinh vào lớp', N'POST', N'/api/user/addUserToClass', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'BALANCE', N'Quản lý doanh thu', N'GET', N'/balance', 1, CAST(N'2020-12-22T17:21:43.297' AS DateTime), NULL, 1, 8, N'dola')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'BALANCE_ADD', N'Thêm mới doanh thu', N'POST', N'/api/balance/add', 1, CAST(N'2020-12-22T17:21:43.297' AS DateTime), N'BALANCE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'BALANCE_APPROVE', N'Phê duyệt số tiền', N'PUT', N'/api/balance/approve', 1, CAST(N'2020-12-25T17:50:04.310' AS DateTime), N'BALANCE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'BALANCE_LIST', N'Danh sách doanh thu', N'POST', N'/api/balance', 1, CAST(N'2020-12-22T17:21:43.297' AS DateTime), N'BALANCE', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'BALANCE_REJECT', N'Không phê duyệt số tiền', N'DELETE', N'/api/balance/reject', 1, CAST(N'2020-12-25T17:50:52.060' AS DateTime), N'BALANCE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CALCULATOR_EXAM', N'Tính điểm bài kiểm tra', N'POST', N'/api/exam/calculatorPointExam', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CASH', N'Rút tiền trong tài khoản', N'GET', N'/cash', 1, CAST(N'2021-01-08T09:41:11.590' AS DateTime), NULL, 1, 8, N'cash')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CASH_AMOUNT', N'Rút tiền', N'POST', N'/api/user/cash', 1, CAST(N'2021-01-08T09:41:11.590' AS DateTime), N'CASH', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CASH_LIST', N'Danh sách nhân viên', N'POST', N'/api/user/list_staff', 1, CAST(N'2021-01-08T09:41:11.590' AS DateTime), N'CASH', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE', N'Quản lý danh mục', N'GET', N'/cate', 1, CAST(N'2020-12-16T04:43:49.903' AS DateTime), NULL, 1, 99, N'cate')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_BACKAMOUNT', N'Danh mục hoàn tiền', N'GET', N'/cate/backamount', 0, CAST(N'2020-12-25T05:54:10.840' AS DateTime), N'CATE', 1, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_BACKAMOUNT_ADD', N'Thêm mới danh mục hoàn tiền', N'POST', N'/api/cate/backamount/add', 0, CAST(N'2020-12-25T05:54:10.840' AS DateTime), N'CATE_BACKAMOUNT', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_BACKAMOUNT_DELETE', N'Xóa danh mục hoàn tiền', N'DELETE', N'/api/cate/backamount/delete', 0, CAST(N'2020-12-25T05:54:10.840' AS DateTime), N'CATE_BACKAMOUNT', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_BACKAMOUNT_LIST', N'Hiển thị danh sách hoàn tiền', N'POST', N'/api/cate/backamount', 0, CAST(N'2020-12-25T05:54:10.840' AS DateTime), N'CATE_BACKAMOUNT', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_BACKAMOUNT_UPDATE', N'Cập nhật danh mục hoàn tiền', N'PUT', N'/api/cate/backamount/update', 0, CAST(N'2020-12-25T05:54:10.840' AS DateTime), N'CATE_BACKAMOUNT', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION', N'Quản lý loại câu hỏi', N'GET', N'/cate/question', 1, CAST(N'2020-12-16T04:43:49.903' AS DateTime), N'CATE', 1, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION_ADD', N'Thêm mới loại câu hỏi', N'POST', N'/api/cate/question/add', 1, CAST(N'2020-12-16T04:43:49.920' AS DateTime), N'CATE_QUESTION', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION_LIST', N'Hiển thị danh sách loại câu hỏi', N'POST', N'/api/cate/question', 1, CAST(N'2020-12-16T04:43:49.903' AS DateTime), N'CATE_QUESTION', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION_LIST_PARENT', N'Lấy danh sách mã nhóm', N'GET', N'/api/cate/question/get_parent', 1, CAST(N'2020-12-16T06:33:03.217' AS DateTime), N'CATE_QUESTION', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION_LOCK_UNLOCK', N'Khóa/Mở khóa loại câu hỏi', N'POST', N'/api/cate/question/lock_unlock', 1, CAST(N'2020-12-16T04:43:49.920' AS DateTime), N'CATE_QUESTION', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_QUESTION_UPDATE', N'Cập nhật loại câu hỏi', N'PUT', N'/api/cate/question/update', 1, CAST(N'2020-12-16T04:43:49.920' AS DateTime), N'CATE_QUESTION', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE', N'Quản lý dịch vụ - đào tạo', N'GET', N'/cate/service', 1, CAST(N'2020-12-19T12:07:56.420' AS DateTime), N'CATE', 1, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_ADD', N'Thêm mới dịch vụ - đào tạo', N'POST', N'/api/cate/service/add', 1, CAST(N'2020-12-19T12:07:56.420' AS DateTime), N'CATE_SERVICE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_LIST', N'Hiển thị danh sách dịch vụ - đào tạo', N'POST', N'/api/cate/service', 1, CAST(N'2020-12-19T12:07:56.420' AS DateTime), N'CATE_SERVICE', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_LIST_TYPE', N'Lấy danh sách dịch vụ - đào tạo theo loại', N'GET', N'/api/cate/service/list_by_type', 1, CAST(N'2020-12-19T12:09:16.937' AS DateTime), N'CATE_SERVICE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_LIST_TYPE_V2', N'Lấy danh sách dịch vụ - đào tạo theo loại v2', N'GET', N'/api/cate/service/list_by_type_v2', 1, CAST(N'2020-12-21T16:30:58.657' AS DateTime), N'CATE_SERVICE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_LOCK_UNLOCK', N'Khóa/Mở khóa dịch vụ - đào tạo', N'POST', N'/api/cate/service/lock_unlock', 1, CAST(N'2020-12-19T12:07:56.420' AS DateTime), N'CATE_SERVICE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CATE_SERVICE_UPDATE', N'Cập nhật dịch vụ - đào tạo', N'PUT', N'/api/cate/service/update', 1, CAST(N'2020-12-19T12:07:56.420' AS DateTime), N'CATE_SERVICE', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CHECKIN_USER', N'Điểm danh user', N'POST', N'/api/user/checkinStudent', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'CLASS', N'Quản lý lớp học', N'GET', N'/class', 1, CAST(N'2020-12-11T16:20:53.417' AS DateTime), NULL, 1, 5, N'exam')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'COURSE', N'Quản Lý Khóa Học', N'GET', N'/course', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), NULL, 1, 8, N'exam')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_ANSWER', N'Xóa câu trả lời', N'DELETE', N'/api/answer/delete', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_CLASS', N'xóa lớp học', N'PUT', N'/api/class/delete', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_COURSE', N'Xóa Khóa Học', N'POST', N'/api/course/delete', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_EXAM', N'Xóa bài kiểm tra', N'PUT', N'/api/exam/delete', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_EXAM_QUESTION_MAPPING', N'xóa mapping', N'DELETE', N'/api/ExamQuestionMapping', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_MULTI_COURSE', N'Xóa Nhiều Khóa Học', N'POST', N'/api/course/deleteMultiCourse', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'DELETE_TEACHER_CLASS', N'xóa giáo viên theo lớp học', N'DELETE', N'/api/teacherClass', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_ANSWER', N'Cập nhật câu trả lời', N'PUT', N'/api/answer/update', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_CLASS', N'sửa lớp học', N'PUT', N'/api/class', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_COURSE', N'Cập Nhật Khóa Học', N'PUT', N'/api/course', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_EXAM', N'Sửa bài kiểm tra', N'PUT', N'/api/exam', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_EXAM_QUESTION_MAPPING', N'sửa mapping', N'PUT', N'/api/ExamQuestionMapping', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_QUESTION', N'Sửa câu hỏi', N'PUT', N'/api/question/update', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EDIT_TEACHER_CLASS', N'sửa giáo viên theo lớp học', N'PUT', N'/api/teacherClass', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'EXAM', N'Quản lý bài kiểm tra', N'GET', N'/exam', 1, CAST(N'2020-12-11T16:20:53.400' AS DateTime), NULL, 1, 3, N'exam')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_ALL_QS_LEVEL', N'Lấy thông tin độ khó câu hỏi', N'GET', N'/api/question/get_all_level', 1, CAST(N'2021-02-02T16:53:42.340' AS DateTime), N'QUESTION', 0, 3, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_ALL_ROLE', N'Lấy danh sách nhóm quyền', N'GET', N'/api/user/get_all_role', 1, CAST(N'2020-12-13T11:03:46.010' AS DateTime), N'USER', 0, 4, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_ALL_USER_CHILDREN', N'Lấy danh học sinh', N'GET', N'/api/user/get_children', 1, CAST(N'2020-12-15T15:28:37.903' AS DateTime), N'USER', 0, 6, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_ANSWER', N'Danh sách câu trả lời theo câu hỏi', N'POST', N'/api/answer', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_CLASS', N'danh sách lớp học', N'POST', N'/api/class/getAllClass', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_CLASS_BY_SERVICES', N'Danh sách lớp học theo trình độ', N'POST', N'/api/class/listClassesByUserServices', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_CLASS_NO_TEACHER', N'Danh sách lớp học chưa có hoặc có giáo viên', N'POST', N'/api/class/listClassesNoTeacher', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_COURSE', N'Danh Sách Khóa Học', N'POST', N'/api/course/getAllCourses', 1, CAST(N'2020-12-20T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_EXAM', N'danh sách bài ki?m tra', N'POST', N'/api/exam/getAllExam', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_EXAM_ID', N'danh sách bài ki?m tra theo id', N'GET', N'/api/exam/getExamById', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_EXAM_QUESTION_MAPPING', N'danh sách mapping', N'GET', N'/api/ExamQuestionMapping', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_EXAM_QUESTION_MAPPING_ID', N'danh sách mapping theo id', N'GET', N'/api/ExamQuestionMapping/getExamMappingById', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_MENU', N'Hiển thị danh mục chức năng hệ thống', N'GET', N'/api/role/getmenu', 1, CAST(N'2020-11-28T13:43:41.670' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_NOTIFICATIONS', N'Lấy danh sách thông báo', N'POST', N'/api/notification', 1, CAST(N'2021-02-02T18:19:53.840' AS DateTime), N'NOTIFICATIONS', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_PERMISSION', N'Danh sách quyền hệ thống', N'GET', N'/api/role/permission', 1, CAST(N'2020-11-28T13:43:41.673' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_PERMISSION_BY_ROLE', N'Lấy danh sách quyền theo role', N'GET', N'/api/role/permissions', 1, CAST(N'2020-12-11T16:41:00.730' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_QUESTION', N'Danh sách câu hỏi', N'POST', N'/api/question', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_QUESTION_EXAM', N'Danh sách câu hỏi theo bài kiểm tra', N'POST', N'/api/exam/getQuestionForExam', 1, CAST(N'2021-02-03T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_TEACHER_CLASS', N'danh sách giáo viên theo lớp học', N'GET', N'/api/teacherClass', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_TEACHER_CLASS_ID', N'giáo viên theo lớp học theo id', N'GET', N'/api/teacherClass/getTeacherClassById', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_TEACHER_NO_CLASS', N'Danh sách giáo viên chưa xếp lớp', N'POST', N'/api/user/getTeachersNoClass', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_USER_DETAIL', N'Lấy thông tin người dùng', N'GET', N'/api/user/get_info', 1, CAST(N'2020-12-21T16:30:17.483' AS DateTime), N'USER', 0, 7, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_USER_NO_CLASS', N'Danh sách học sinh chưa xếp lớp', N'POST', N'/api/user/getUsersNoClass', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'GET_USERS_BY_CLASSCODE', N'Danh sách học sinh theo mã lớp học', N'POST', N'/api/user/getUsersByClassCode', 1, CAST(N'2020-12-25T00:00:00.000' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'HOME', N'Trang chủ', N'GET', N'/dashboard', 1, CAST(N'2020-11-28T13:43:41.667' AS DateTime), NULL, 1, 0, N'chart')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'LIST_ROLE', N'Hiển thị danh sách quyền ', N'POST', N'/api/role', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'LOCK_UNLOCK_COURSE', N'Khóa/Mở khóa khóa học', N'POST', N'/api/course/lock_unlock', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'LOCK_UNLOCK_QUESTION', N'Khóa/Mở khóa câu hỏi', N'POST', N'/api/question/lock_unlock', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'QUESTION', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'LOCK_UNLOCK_ROLE', N'Khóa/Mở khóa quyền', N'POST', N'/api/role/lock_unlock', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'NOTIFICATIONS', N'Thông báo', N'GET', N'/notification', 1, CAST(N'2021-02-02T18:19:53.827' AS DateTime), NULL, 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'PUSH_NOTIFICATIONS', N'Đẩy thông báo', N'POST', N'/api/notification/push', 1, CAST(N'2021-02-02T18:19:53.840' AS DateTime), N'NOTIFICATIONS', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'QUESTION', N'Quản lý hệ thống câu hỏi', N'GET', N'/question', 1, CAST(N'2020-12-11T16:20:53.417' AS DateTime), NULL, 1, 2, N'question')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'QUESTION_CATE_TREE', N'Lấy danh sách nhóm câu hỏi', N'GET', N'/api/question/tree', 1, CAST(N'2020-12-16T09:45:01.763' AS DateTime), N'QUESTION', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'READ_NOTIFICATIONS', N'Xem thông báo', N'POST', N'/api/notification/read', 1, CAST(N'2021-03-11T00:17:55.820' AS DateTime), N'NOTIFICATIONS', 0, 3, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'ROLE', N'Quản lý quyền hệ thống', N'GET', N'/system/role', 1, CAST(N'2020-11-28T13:43:41.670' AS DateTime), N'SYSTEM', 1, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'SELECT_COURSE', N'Danh sách chọn khóa học', N'GET', N'/api/class/listCourse', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'SYSTEM', N'Quản lý hệ thống', N'GET', N'/system', 1, CAST(N'2020-11-28T13:43:41.670' AS DateTime), NULL, 1, 100, N'role')
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'UPDATE_PERMISSION_BY_ROLE', N'Cập nhật phân quyền', N'POST', N'/api/role/update_permissions', 1, CAST(N'2020-12-13T05:40:09.610' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'UPDATE_ROLE', N'Cập nhật quyền', N'PUT', N'/api/role/update', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'ROLE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'UPDATE_USER_INFO', N'Cập nhật thông tin người dùng', N'POST', N'/api/user/change_info', 1, CAST(N'2021-03-03T05:01:02.527' AS DateTime), N'USER', 0, 8, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER', N'Quản lý người dùng hệ thống', N'GET', N'/system/user', 1, CAST(N'2020-12-13T10:54:33.833' AS DateTime), N'SYSTEM', 1, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER_ADD', N'Thêm mới người dùng', N'POST', N'/api/user/add', 1, CAST(N'2020-12-13T11:01:46.563' AS DateTime), N'USER', 0, 1, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER_CHECKDUPLICATE', N'Kiểm tra tồn tại người dùng', N'POST', N'/api/user/check_duplicate', 1, CAST(N'2020-12-15T10:40:43.920' AS DateTime), N'USER', 0, 5, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER_LIST', N'Lấy danh sách người dùng', N'POST', N'/api/user', 1, CAST(N'2020-12-13T11:01:46.560' AS DateTime), N'USER', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER_LOCK_UNLOCK', N'Khóa/mở khóa người dùng', N'POST', N'/api/user/lock_unlock', 1, CAST(N'2020-12-13T11:01:46.563' AS DateTime), N'USER', 0, 3, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'USER_UPDATE', N'Cập nhật người dùng', N'PUT', N'/api/user/update', 1, CAST(N'2020-12-13T11:01:46.563' AS DateTime), N'USER', 0, 2, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'VIEW_CLASS', N'danh sách  lớp học theo id', N'GET', N'/api/class/getClassByClassCode', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'CLASS', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'VIEW_COURSE', N'Chi Tiết Khóa Học', N'', N'', 1, CAST(N'2020-12-09T00:00:00.000' AS DateTime), N'COURSE', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'VIEW_EXAM', N'Xem chi tiết bài kiểm tra', N'GET', N'/exam', 1, CAST(N'2020-12-19T00:00:00.000' AS DateTime), N'EXAM', 0, 0, NULL)
GO
INSERT [dbo].[Permission] ([PermistionId], [Description], [Method], [Url], [Status], [CreateDate], [ParentId], [IsMenu], [Position], [Icon]) VALUES (N'VIEW_ROLE', N'Xem chi tiết quyền', N'POST', N'/api/role/view', 1, CAST(N'2020-11-29T00:00:00.000' AS DateTime), N'ROLE', 0, 0, NULL)
GO
SET IDENTITY_INSERT [dbo].[Question] ON 
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1, N'Thực hiện phép tính sau: 
1 + 1 = ?', N'VE', CAST(N'2020-12-09T08:07:53.457' AS DateTime), CAST(N'2020-12-17T12:04:48.703' AS DateTime), N'string', 1, 3)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (2, N'Dòng điện một chiều có mấy cực?', N'M', CAST(N'2020-12-09T08:10:07.117' AS DateTime), CAST(N'2020-12-17T12:05:16.427' AS DateTime), N'string', 1, 4)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (3, N'Tổng số cạnh của hình tam giác là bao nhiêu?', N'E', CAST(N'2020-12-17T12:19:21.463' AS DateTime), NULL, N'admin', 1, 3)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (4, N'test', N'D', CAST(N'2020-12-20T13:48:55.897' AS DateTime), NULL, N'admin', 1, 2)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (5, N'Thực hiện phép tính sau: 
3 + 3 = ?', N'ED', CAST(N'2020-12-22T23:21:49.227' AS DateTime), NULL, N'admin', 1, 3)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1005, N'test1', N'VE', CAST(N'2021-02-02T06:36:57.603' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1006, N'câu hỏi 2', N'VE', CAST(N'2021-02-02T06:38:32.487' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1007, N'câu hỏi 3', N'VE', CAST(N'2021-02-02T06:38:55.347' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1008, N'câu hỏi 4', N'VE', CAST(N'2021-02-02T06:39:25.737' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1009, N'câu hỏi 5', N'E', CAST(N'2021-02-02T06:39:37.643' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1010, N'câu hỏi 6', N'E', CAST(N'2021-02-02T06:39:44.673' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1011, N'câu hỏi 7', N'E', CAST(N'2021-02-02T06:39:52.423' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1012, N'câu hỏi 8', N'E', CAST(N'2021-02-02T06:39:58.847' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1013, N'câu hỏi 9', N'E', CAST(N'2021-02-02T06:40:05.627' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1014, N'câu hỏi 10', N'E', CAST(N'2021-02-02T06:40:12.797' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1015, N'câu hỏi 11', N'ED', CAST(N'2021-02-02T06:40:20.047' AS DateTime), CAST(N'2021-02-03T23:36:17.547' AS DateTime), N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1016, N'câu hỏi 12', N'M', CAST(N'2021-02-02T06:40:26.547' AS DateTime), CAST(N'2021-02-03T08:09:46.313' AS DateTime), N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1017, N'câu hỏi 13', N'Trung bình', CAST(N'2021-02-02T06:40:33.047' AS DateTime), CAST(N'2021-02-04T01:06:05.370' AS DateTime), N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1018, N'Tại sao lại như thế này?', N'M', CAST(N'2021-03-02T08:02:45.510' AS DateTime), NULL, N'admin', 1, 1)
GO
INSERT [dbo].[Question] ([QuestionId], [QuestionName], [Level], [CreateDate], [ModifyDate], [UserCreate], [Status], [CateId]) VALUES (1019, N'1 + 1 =?', N'D', CAST(N'2021-03-16T17:38:45.510' AS DateTime), NULL, N'admin', 1, 7)
GO
SET IDENTITY_INSERT [dbo].[Question] OFF
GO
SET IDENTITY_INSERT [dbo].[QuestionCate] ON 
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (1, N'Khoa học tự nhiên', N'Nhóm câu hỏi khoa học tự nhiên', CAST(N'2020-12-16T13:19:25.687' AS DateTime), 1, N'admin', CAST(N'2020-12-16T13:22:20.833' AS DateTime), 0)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (2, N'Xã hội', N'Nhóm câu hỏi xã hội', CAST(N'2020-12-16T14:05:37.427' AS DateTime), 1, N'admin', NULL, 0)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (3, N'Toán học', N'Nhóm câu hỏi toán học', CAST(N'2020-12-16T15:56:53.893' AS DateTime), 1, N'admin', NULL, 1)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (4, N'Vật lý', N'Nhóm câu hỏi vật lý', CAST(N'2020-12-16T15:57:37.210' AS DateTime), 1, N'admin', NULL, 1)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (5, N'Nhân văn học', N'Nhân văn học', CAST(N'2020-12-16T15:59:25.603' AS DateTime), 1, N'admin', NULL, 2)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (6, N'Đào tạo A1', N'Đào tạo A1', CAST(N'2021-03-16T17:36:38.980' AS DateTime), 1, N'admin', NULL, 0)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (7, N'Bài 1 - Trình độ A1', N'Bài 1 - Trình độ A1', CAST(N'2021-03-16T17:37:46.650' AS DateTime), 1, N'admin', CAST(N'2021-03-16T21:37:58.950' AS DateTime), 6)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (8, N'Bài 2 - Trình độ A1', N'Bài 2 - Trình độ A1', CAST(N'2021-03-16T17:39:33.120' AS DateTime), 1, N'admin', NULL, 6)
GO
INSERT [dbo].[QuestionCate] ([Id], [Name], [Description], [DateCreated], [Status], [UserCreated], [ModifyDate], [ParentId]) VALUES (9, N'Bài 3 - Trình độ A1', N'Bài 3 - Trình độ A1', CAST(N'2021-03-16T21:33:39.003' AS DateTime), 1, N'admin', NULL, 6)
GO
SET IDENTITY_INSERT [dbo].[QuestionCate] OFF
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'ACCOUNTANT', N'Kế toán', N'Kiểm soát doanh thu. Duyệt tiền', CAST(N'2021-03-16T00:09:23.790' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'ADMIN', N'ADMIN', N'Admin hệ thống', CAST(N'2020-11-14T00:00:00.000' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'EDUCATION', N'Quản lý đào tạo', N'Quản lý lớp khóa học', CAST(N'2021-03-16T13:02:41.940' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'EMPLOYEE', N'Nhân viên', N'Nhân viên công ty', CAST(N'2021-03-16T08:56:18.233' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'HR', N'Duyệt hồ sơ', N'', CAST(N'2020-12-20T22:45:18.247' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'STUDENT', N'Học sinh', N'', CAST(N'2020-12-19T14:26:41.507' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'TEACHER', N'Giáo Viên', N'Nhóm quyền dành cho giáo viên', CAST(N'2021-03-16T00:03:23.840' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'TEST', N'TEST', N'test thêm nhóm quyền', CAST(N'2020-12-14T17:09:03.597' AS DateTime), N'admin', 0)
GO
INSERT [dbo].[Role] ([RoleId], [RoleName], [Description], [CreatedDate], [UserCreate], [Status]) VALUES (N'USER', N'USER', N'Nhóm quyền mặc định của học sinh', CAST(N'2020-12-11T00:00:00.000' AS DateTime), N'admin', 0)
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'BALANCE', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'BALANCE_ADD', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'BALANCE_APPROVE', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'BALANCE_LIST', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'BALANCE_REJECT', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'GET_EXAM', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'USER_ADD', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'USER_UPDATE', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ACCOUNTANT', N'VIEW_EXAM', N'admin', CAST(N'2021-03-16T00:10:48.960' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_ANSWER', N'admin', CAST(N'2021-03-03T12:02:25.743' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.833' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.840' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.840' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-03T12:02:25.840' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.840' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.840' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_TEACHER_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_TEACHER_TO_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ADD_USER_TO_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'BALANCE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'BALANCE_ADD', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'BALANCE_APPROVE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'BALANCE_LIST', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'BALANCE_REJECT', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CASH', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CASH_AMOUNT', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CASH_LIST', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_BACKAMOUNT', N'admin', CAST(N'2021-03-03T12:02:25.863' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_BACKAMOUNT_ADD', N'admin', CAST(N'2021-03-03T12:02:25.863' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_BACKAMOUNT_DELETE', N'admin', CAST(N'2021-03-03T12:02:25.863' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_BACKAMOUNT_LIST', N'admin', CAST(N'2021-03-03T12:02:25.863' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_BACKAMOUNT_UPDATE', N'admin', CAST(N'2021-03-03T12:02:25.867' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION_ADD', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION_LIST', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION_LIST_PARENT', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION_LOCK_UNLOCK', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_QUESTION_UPDATE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_ADD', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_LIST', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_LIST_TYPE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_LIST_TYPE_V2', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_LOCK_UNLOCK', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CATE_SERVICE_UPDATE', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CHECKIN_USER', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'CLASS', N'admin', CAST(N'2021-03-03T12:02:25.843' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'COURSE', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_ANSWER', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_MULTI_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'DELETE_TEACHER_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_ANSWER', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.847' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EDIT_TEACHER_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'EXAM', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_ALL_QS_LEVEL', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_ALL_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_ALL_USER_CHILDREN', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_ANSWER', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_CLASS_BY_SERVICES', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_CLASS_NO_TEACHER', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_MENU', N'admin', CAST(N'2021-03-03T12:02:25.850' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_NOTIFICATIONS', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_PERMISSION', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_PERMISSION_BY_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_TEACHER_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_TEACHER_CLASS_ID', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_TEACHER_NO_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_USER_DETAIL', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_USER_NO_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.853' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'GET_USERS_BY_CLASSCODE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'HOME', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'LIST_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'LOCK_UNLOCK_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'LOCK_UNLOCK_QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'LOCK_UNLOCK_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'NOTIFICATIONS', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'PUSH_NOTIFICATIONS', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'QUESTION', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'QUESTION_CATE_TREE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'ROLE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'SELECT_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'SYSTEM', N'admin', CAST(N'2021-03-03T12:02:25.867' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'UPDATE_PERMISSION_BY_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'UPDATE_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'UPDATE_USER_INFO', N'admin', CAST(N'2021-03-03T12:02:25.867' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER', N'admin', CAST(N'2021-03-03T12:02:25.867' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER_ADD', N'admin', CAST(N'2021-03-03T12:02:25.857' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER_CHECKDUPLICATE', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER_LIST', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER_LOCK_UNLOCK', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'USER_UPDATE', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'VIEW_CLASS', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'VIEW_COURSE', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'VIEW_EXAM', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'ADMIN', N'VIEW_ROLE', N'admin', CAST(N'2021-03-03T12:02:25.860' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_ANSWER', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_TEACHER_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_TEACHER_TO_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'ADD_USER_TO_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION_ADD', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION_LIST', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION_LIST_PARENT', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION_LOCK_UNLOCK', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_QUESTION_UPDATE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_ADD', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_LIST', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_LIST_TYPE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_LIST_TYPE_V2', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_LOCK_UNLOCK', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CATE_SERVICE_UPDATE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_ANSWER', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_MULTI_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'DELETE_TEACHER_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_ANSWER', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EDIT_TEACHER_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_ALL_QS_LEVEL', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_ALL_USER_CHILDREN', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_ANSWER', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_CLASS_BY_SERVICES', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_CLASS_NO_TEACHER', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_TEACHER_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_TEACHER_CLASS_ID', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_TEACHER_NO_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_USER_DETAIL', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_USER_NO_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'GET_USERS_BY_CLASSCODE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'LOCK_UNLOCK_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'LOCK_UNLOCK_QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'QUESTION', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'QUESTION_CATE_TREE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'SELECT_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'USER_ADD', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'USER_LIST', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'VIEW_CLASS', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'VIEW_COURSE', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EDUCATION', N'VIEW_EXAM', N'admin', CAST(N'2021-03-16T13:09:30.393' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'BALANCE_ADD', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'CATE_SERVICE_LIST', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'CATE_SERVICE_LIST_TYPE', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'CATE_SERVICE_LIST_TYPE_V2', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'GET_EXAM', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'USER_ADD', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'USER_LIST', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'EMPLOYEE', N'VIEW_EXAM', N'admin', CAST(N'2021-03-16T10:10:44.397' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'HR', N'USER_LOCK_UNLOCK', N'admin', CAST(N'2020-12-20T22:46:36.883' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'HR', N'USER_UPDATE', N'admin', CAST(N'2020-12-20T22:46:36.883' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_ALL_ROLE', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_EXAM', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_NOTIFICATIONS', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'GET_USER_DETAIL', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'READ_NOTIFICATIONS', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'STUDENT', N'VIEW_EXAM', N'admin', CAST(N'2021-03-16T00:02:33.713' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'ADD_EXAM', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'ADD_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CATE_QUESTION_LIST', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CATE_QUESTION_LIST_PARENT', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CATE_SERVICE_LIST', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CATE_SERVICE_LIST_TYPE', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CATE_SERVICE_LIST_TYPE_V2', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'CHECKIN_USER', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_ALL_QS_LEVEL', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_ALL_USER_CHILDREN', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_CLASS', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_CLASS_BY_SERVICES', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_CLASS_NO_TEACHER', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_EXAM', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_EXAM_ID', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_QUESTION_EXAM', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_USER_DETAIL', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'GET_USERS_BY_CLASSCODE', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'QUESTION_CATE_TREE', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'USER_ADD', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'USER_LIST', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'VIEW_CLASS', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'TEACHER', N'VIEW_EXAM', N'admin', CAST(N'2021-03-16T13:09:56.000' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_ANSWER', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_TEACHER_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_TEACHER_TO_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ADD_USER_TO_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'BALANCE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'BALANCE_ADD', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'BALANCE_APPROVE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'BALANCE_LIST', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'BALANCE_REJECT', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CALCULATOR_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_BACKAMOUNT', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_BACKAMOUNT_ADD', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_BACKAMOUNT_DELETE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_BACKAMOUNT_LIST', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_BACKAMOUNT_UPDATE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION_ADD', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION_LIST', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION_LIST_PARENT', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION_LOCK_UNLOCK', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_QUESTION_UPDATE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_ADD', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_LIST', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_LIST_TYPE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_LIST_TYPE_V2', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_LOCK_UNLOCK', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CATE_SERVICE_UPDATE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CHECKIN_USER', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_ANSWER', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_MULTI_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'DELETE_TEACHER_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_ANSWER', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EDIT_TEACHER_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_ALL_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_ALL_USER_CHILDREN', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_ANSWER', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_CLASS_BY_SERVICES', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_CLASS_NO_TEACHER', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_EXAM_ID', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_EXAM_QUESTION_MAPPING', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_EXAM_QUESTION_MAPPING_ID', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_MENU', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_PERMISSION', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_PERMISSION_BY_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_TEACHER_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_TEACHER_CLASS_ID', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_TEACHER_NO_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_USER_DETAIL', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_USER_NO_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'GET_USERS_BY_CLASSCODE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'HOME', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'LIST_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'LOCK_UNLOCK_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'LOCK_UNLOCK_QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'LOCK_UNLOCK_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'QUESTION', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'QUESTION_CATE_TREE', N'admin', CAST(N'2021-01-08T13:29:43.420' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'SELECT_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'SYSTEM', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'UPDATE_PERMISSION_BY_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'UPDATE_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER_ADD', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER_CHECKDUPLICATE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER_LIST', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER_LOCK_UNLOCK', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'USER_UPDATE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'VIEW_CLASS', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'VIEW_COURSE', N'admin', CAST(N'2021-01-08T13:29:43.413' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'VIEW_EXAM', N'admin', CAST(N'2021-01-08T13:29:43.417' AS DateTime))
GO
INSERT [dbo].[RolePermissionMapping] ([RoleId], [PermissionId], [Usercreate], [DateCreate]) VALUES (N'USER', N'VIEW_ROLE', N'admin', CAST(N'2021-01-08T13:29:43.410' AS DateTime))
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'A1', N'Trình độ đào tạo A1', 2, CAST(N'2020-12-20T22:35:42.787' AS DateTime), N'admin', CAST(3000000 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'A2', N'Trình độ đào tạo A2', 2, CAST(N'2020-12-20T22:35:51.797' AS DateTime), N'admin', CAST(0 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'A3', N'Trình độ đào tạo A3', 2, CAST(N'2020-12-20T22:35:59.627' AS DateTime), N'admin', CAST(0 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'A4', N'Trình độ đào tạo A4', 2, CAST(N'2020-12-20T22:36:14.167' AS DateTime), N'admin', CAST(0 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'A5', N'Trình độ đào tạo A5', 2, CAST(N'2020-12-20T22:36:36.430' AS DateTime), N'admin', CAST(0 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'DICH_VU_DAOTAO', N'Dịch vụ đào tạo trọn gói', 1, CAST(N'2020-12-20T18:11:11.047' AS DateTime), N'admin', CAST(30000000 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'DICH_VU_DAOTAO_A1_A2', N'Dịch vụ đào tạo trọn gói A1, A2', 1, CAST(N'2021-03-02T23:11:37.323' AS DateTime), N'admin', CAST(3000000 AS Decimal(18, 0)), 1, NULL)
GO
INSERT [dbo].[Services] ([ServiceCode], [ServiceName], [Type], [CreateDate], [UserCreated], [Price], [Status], [Training]) VALUES (N'TRON_GOI_DONG_TAU', N'Dịch vụ đào tạo trọn gói ngành đóng tàu', 3, CAST(N'2021-03-16T22:41:36.713' AS DateTime), N'admin', CAST(300000000 AS Decimal(18, 0)), 1, NULL)
GO
SET IDENTITY_INSERT [dbo].[StudentClass] ON 
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (1, N'admin', N'LEAK', N'[
  {
    "StudentId": "admin",
    "Status": 0,
    "Note": "diem danh lan 1",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:30:01.1319061+07:00"
  },
  {
    "StudentId": "admin",
    "Status": 0,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:31:45.8222076+07:00"
  },
  {
    "StudentId": "admin",
    "Status": 1,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:32:49.6497943+07:00"
  }
]', 1, CAST(N'2020-12-26T00:49:45.737' AS DateTime), N'admin', 2)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (2, N'03365335666', N'LEAK', N'[
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 1",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:30:23.6079058+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:31:48.7663084+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 2,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:32:49.7026512+07:00"
  }
]', 1, CAST(N'2020-12-27T17:26:14.843' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (6, N'admin', N'C9898', N'[
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 1",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:30:23.6079058+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:31:48.7663084+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 2,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:32:49.7026512+07:00"
  }
]', 1, CAST(N'2021-01-02T00:00:00.000' AS DateTime), N'admin', 0)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (12, N'03365335666', N'C9898', N'[
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 1",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:30:23.6079058+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 1,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:31:48.7663084+07:00"
  },
  {
    "StudentId": "03365335666",
    "Status": 2,
    "Note": "diem danh lan 2",
    "TeacherId": "admin",
    "DateCheckIn": "2020-12-27T17:32:49.7026512+07:00"
  }
]', 1, CAST(N'2021-01-02T00:00:00.000' AS DateTime), N'admin', 1)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (13, N'0336533533', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-26T20:14:05.147' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (14, N'0344355127', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-26T20:17:29.727' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (15, N'09659565656', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-26T20:21:20.930' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (16, N'0111111111', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-27T06:53:47.567' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (17, N'0222222222', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-27T06:53:56.760' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (18, N'0344355120', N'LEAK', N'', 1, CAST(N'2021-02-28T19:24:05.647' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (19, N'0344355121', N'AWS', N'2021-01-04T00:00:00', 1, CAST(N'2021-02-28T04:34:25.437' AS DateTime), N'admin', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (20, N'0336533600', N'TEK', N'2021-03-26T00:00:00', 1, CAST(N'2021-03-16T14:24:35.243' AS DateTime), N'0336533800', NULL)
GO
INSERT [dbo].[StudentClass] ([Id], [StudentId], [ClassId], [Checkin], [Status], [CreateDate], [UserCreate], [TotalLeave]) VALUES (21, N'0336533599', N'MD2', N'2021-03-25T00:00:00', 1, CAST(N'2021-03-16T16:43:36.617' AS DateTime), N'0336533800', NULL)
GO
SET IDENTITY_INSERT [dbo].[StudentClass] OFF
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'03365335666', N'LEAK', NULL, CAST(N'2020-12-27T17:24:15.270' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'HSN98', 1, CAST(N'2021-03-15T23:49:58.137' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'IUTR', 1, CAST(N'2021-03-15T23:50:33.290' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'KIMIK', 1, CAST(N'2021-03-15T23:50:23.337' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'LOPHOC3', 1, CAST(N'2021-03-16T13:17:58.203' AS DateTime), N'0336533800')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'MD2', 1, CAST(N'2021-03-16T16:43:50.913' AS DateTime), N'0336533800')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'TEK', 1, CAST(N'2021-03-16T13:31:55.907' AS DateTime), N'0336533800')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'0977910500', N'TFT', 1, CAST(N'2021-03-15T23:50:28.667' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'Ha.vu', N'AWS', 1, CAST(N'2021-02-26T20:31:43.493' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'Ha.vu', N'HGF', 1, CAST(N'2021-03-03T09:39:19.220' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'Ha.vu', N'HHHH', 1, CAST(N'2021-03-03T09:39:31.190' AS DateTime), N'admin')
GO
INSERT [dbo].[TeacherClass] ([Username], [ClassCode], [IsTeacher], [DateCreate], [UserCreate]) VALUES (N'hoangnh', N'C9898', 1, CAST(N'2021-02-28T04:33:50.690' AS DateTime), N'admin')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0111111111', N'$2a$11$x/6xlz5uzI8oSs/2cB0j7.91sWPa2Bku/arv1ACXpmL5HxkV6Z1cG', N'Học Sinh Hư 1', NULL, NULL, NULL, NULL, N'Han', 1, 0, CAST(N'2021-02-27T06:52:08.670' AS DateTime), CAST(N'2021-03-16T08:55:15.657' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'hdhdhd@dh.com', N'0111111111', N'admin', 2, N'A1,A2,A3,A4', N'7u3hhe7e7u3', CAST(10000.00 AS Decimal(18, 2)), CAST(300000.00 AS Decimal(18, 2)), N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0222222222', N'$2a$11$caJySP//CRyaN2J3HMoIvuhBiwlJdEyF7EVSK7nxGTUFIeNetf.Gm', N'Học Sinh Hư 2', NULL, NULL, NULL, NULL, N'Tha', 1, 0, CAST(N'2021-02-27T06:52:50.497' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'hshsheueh@dee.com', N'0222222222', N'admin', 2, N'A1,A2,A3,A4,A5', N'Ueyeg77373h', CAST(900.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533400', N'$2a$11$f0pkkLVPNsCjqDXB0EZWQuEusqq3nifIj4oIQArwieKuFQMABjCEq', N'Hdhdhdheue Dh', NULL, NULL, NULL, NULL, N'Dbhdhdgd', 1, 0, CAST(N'2021-03-16T09:54:12.790' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'dhhdheyd@hejd.com', N'0336533400', N'0336533500', NULL, NULL, N'Hdhdhdg', CAST(30000000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533500', N'$2a$11$nlIZZ.PKihqigOKR1smhy.OnXuXBWqmmG4I5.BuB6V9izJ1THBeY6', N'Lê Giám Đốc', NULL, NULL, NULL, NULL, N'Hà nội', 1, 0, CAST(N'2021-03-16T09:03:49.483' AS DateTime), NULL, NULL, CAST(1700001.00 AS Decimal(18, 2)), 4, NULL, N'Trưởng vùng', N'jdudueueue@dnjdue.com', N'0336533500', N'admin', NULL, NULL, N'7272626363', CAST(4700000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533501', N'$2a$11$1WImSXSZyvXFv2yibNwPtOARmxZleK286gp070id4YxV3Pzwoe2Ue', N'Lê Nhân Viên', NULL, NULL, NULL, NULL, N'Jdjdjdjdjdjdj', 1, 0, CAST(N'2021-03-16T09:52:19.790' AS DateTime), NULL, NULL, CAST(2499999.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'hdhdudue@eurh.com', N'0336533501', N'0336533500', NULL, NULL, N'Hshshshdy', CAST(3000000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533502', N'$2a$11$JrAd9MjoJEnyTF7N2aNLEe9DTlfzvbZf5I7AuE03s.8Pjg80PISp2', N'Lê Nhân Viên 2', NULL, NULL, NULL, NULL, N'Jdjdjejejej', 1, 0, CAST(N'2021-03-16T09:55:51.180' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'hdrhjehrhe@ehrhhe.com', N'0336533502', N'0336533500', NULL, NULL, N'Hehehehehe', CAST(4500000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533503', N'$2a$11$tNSBo1hbrVPJc27cf1/XX.peoOJ83ITlk7wud9.R1kFz5NWSM6iJe', N'Lê Cộng Tác Viên', NULL, NULL, NULL, NULL, N'Jdhdhdhdhdhd', 1, 0, CAST(N'2021-03-16T10:07:12.493' AS DateTime), NULL, NULL, CAST(500001.00 AS Decimal(18, 2)), 4, NULL, N'Cộng tác viên', N'bddhhdhddhhd', N'0336533503', N'0336533501', NULL, NULL, N'Hshehehshs', CAST(500000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533533', N'$2a$11$4xD56dVehQV4IM1RJY8cRuLI0VvEj.bIjHH8.GBG/DVmdiEdU4l6i', N'Chung Le', N'1', CAST(N'1990-12-22' AS Date), NULL, N'Đại học công nghiệp Hà Nội', N'Ga ha noi', 1, 0, CAST(N'2020-12-20T07:44:38.730' AS DateTime), CAST(N'2021-03-01T08:01:29.297' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, NULL, N'test01@gmail.com', N'0336533533', N'admin', 2, N'A1', N'0609165658', CAST(0.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533566', N'$2a$11$0VPbVIzLGu8Us7HmkvpjzuhNVwOxeEjXaeIRTGGjeE4g5u9HW7dRu', N'Lê Đức Chung', NULL, NULL, NULL, NULL, N'Hà nội', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, NULL, N'shootmail@huji.com', N'0336533566', N'admin', NULL, NULL, N'173844361', CAST(0.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'03365335666', N'$2a$11$88xOqGXdeXBO7wNsnaesMeA6kGJdR6xN67wEvb5XeS1K9DiZiLnrG', N'Lê Đức Chung', NULL, NULL, NULL, NULL, N'Hà Nội', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'chungmail@mail.com', N'03365335666', N'admin', 3, N'A2,A3,A4', N'1565442789', CAST(0.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533568', N'$2a$11$I8dhKJ1IgvR5LqqnYeR10O54buoukAtiQR45pc32z7CjdMpLMOOT.', N'Chung béo', N'1', CAST(N'1994-03-04' AS Date), NULL, NULL, N'Kim Mã - Ba Đình', 1, 0, CAST(N'2021-03-14T18:44:33.813' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 3, N'03365335666', NULL, N'shootingstar.ldc@gmail.com', N'0336533568', N'admin', 1, N'DICH_VU_DAOTAO_A1_A2', NULL, CAST(69969.00 AS Decimal(18, 2)), CAST(270000000.00 AS Decimal(18, 2)), N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533599', N'$2a$11$ead1qMYIG2WfLcj1vMuqI.qT/K1Ty3i/7eA1l85scKe2W36zhFO8a', N'Le Hoc Sinh', NULL, NULL, NULL, NULL, N'Sdjhfgskdhfgskdhfgskdf', 1, 0, CAST(N'2021-03-16T16:38:54.010' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'shdjfgskdjhfgsdf@gmail.com', N'0336533599', N'0336533500', 3, N'A2,A3,A4,DICH_VU_DAOTAO', N'Fhgsdkfsjdhfgskddsfd', CAST(2000.00 AS Decimal(18, 2)), CAST(30000000.00 AS Decimal(18, 2)), N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533600', N'$2a$11$tk52UBZjLfqqDT.kFy7XZ.BxTXoRkjxqJRduh7jgbZ4DleCvzInRO', N'Lê Học Sinh', NULL, NULL, NULL, NULL, N'Sjdjjdhdhdhd', 1, 0, CAST(N'2021-03-16T10:09:09.133' AS DateTime), CAST(N'2021-03-16T11:48:38.893' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'jdjdjdjdjdjd@ddd.com', N'0336533600', N'0336533503', 3, N'A1,DICH_VU_DAOTAO', N'Hshehehehehe', CAST(0.00 AS Decimal(18, 2)), CAST(30000000.00 AS Decimal(18, 2)), N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533601', N'$2a$11$ZV2VeNSALKN.kElDKbeAFupVnVbfsV4HTFAAxdqSFZwip1j7OZorW', N'Học Sinh Giàu', NULL, NULL, NULL, NULL, N'Sbsbhshshshs', 1, 0, CAST(N'2021-03-16T11:50:00.590' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'hshshdhdhshd@hshe.com', N'0336533601', N'0336533503', 1, N'DICH_VU_DAOTAO', N'Hshshshe', CAST(500000.00 AS Decimal(18, 2)), CAST(30000000.00 AS Decimal(18, 2)), N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533700', N'$2a$11$UtLFqEQ4rH0a8qi/qo1FQeqaU.Fd4cn9zVDZW2WqY6H9DzSI4QPLO', N'HR XYNH ĐẸP', NULL, NULL, NULL, NULL, N'Djdjdjdjjd', 1, 0, CAST(N'2021-03-16T12:31:01.803' AS DateTime), CAST(N'2021-03-16T12:31:51.287' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'jdjdjdjdjd', N'0336533700', N'0336533500', NULL, NULL, N'Jdudheheheh', CAST(100000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533701', N'$2a$11$7Qb4DA5wpOoz.iiIZ.8/TOtgNy1AdVMJP8xkl0BhHd7jjC9U4j2aG', N'Kế Toán Đầu Gấu', NULL, NULL, NULL, NULL, N'Hdhdhdhdhdhd', 1, 0, CAST(N'2021-03-16T12:33:30.867' AS DateTime), CAST(N'2021-03-16T12:34:14.130' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'jejejehehdue@hdhd.com', N'0336533701', N'0336533700', NULL, NULL, N'Hdhdhsheheheheh', CAST(5000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0336533800', N'$2a$11$Jne3xgMt7IIW2dbEqNi7luo85m3uHZC5zESb1azPcP1XZJEkJK99C', N'Táo Giáo Dục', NULL, NULL, NULL, NULL, N'Hdhdhduđ', 1, 0, CAST(N'2021-03-16T13:12:23.643' AS DateTime), CAST(N'2021-03-16T13:13:18.360' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'jejeueueue@dhdhd.com', N'0336533800', N'0977910500', NULL, NULL, N'Hshshshshshehheheh', CAST(10000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355120', N'$2a$11$afj5K5GsW1iKLeZ0T2paAuAIEmA7S6BmN7.lIrnr9btGd4HlywKnW', N'Test1', NULL, NULL, NULL, NULL, N'36 Hoang Cau`', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'a@a.vn', N'0344355120', N'admin', 2, N'A2,A3,A4', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355121', N'$2a$11$hWVko4tGZ3LgTmkIuWB/Y.qY.ax1anEgsLLziy2D3otWk9u9F8eeG', N'Test2', NULL, NULL, NULL, NULL, N'36 Hoàng Cầu', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'havditbk1@gmail.com', N'0344355121', N'admin', 2, N'A2,A3', N'017144127', NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355125', N'$2a$11$0VJTNPEPnJ9RUB9kUIrV/eTyBrrGXDFqf56f8xbmN5FmYeRu7ZPHe', N'Test5', NULL, NULL, NULL, NULL, N'36 Hoàng Cầu', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'havditbk5@gmail.com', N'0344355125', N'admin', 1, N'DICH_VU_DAOTAO', N'017144125', NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355126', N'$2a$11$vutzAhEc8bOQbKGIMMXQ5.sr.zLD/UIb/m84YDdjRDvjq5ZH5y.Li', N'Test6', NULL, NULL, NULL, NULL, N'36 Hoàng Cầu', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'havditbk6@gmail.com', N'0344355126', N'admin', 1, N'DICH_VU_DAOTAO', N'017144126', NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355127', N'$2a$11$cWO9atJ.7elCDR5ZovuZJeuvlaMrxYQLqerT.VFRDQSNHHED7ii5i', N'Ha Vu', NULL, NULL, NULL, NULL, N'36 Hoang Cau', 1, 0, CAST(N'2020-12-25T08:16:10.360' AS DateTime), CAST(N'2021-02-01T07:03:10.393' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Giáo viên', N'havd.it@tripi.vn', N'0344355127', N'admin', 2, N'A1', NULL, CAST(1000000.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0344355128', N'$2a$11$NM7ydIEvA2Zf1GXYoVsAKOzrZKEEsTNY5kRcyaWspwpaY5gWrmNwS', N'Test8', NULL, NULL, NULL, NULL, N'36 Hoang Cau', 1, 0, CAST(N'2021-03-16T00:22:10.370' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'havditbk8@gmail.com', N'0344355128', N'admin', 2, N'A3,A4,A5', N'017144128', NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0366956536', N'$2a$11$zXzyUja8Zx7uMzRdaSTQ1ucYTgjUMkyFmPvTVQj85DxiQ8X.8MGk2', N'CHUNG', NULL, NULL, NULL, NULL, N'Heyehhey dhdhhh', 1, 0, CAST(N'2020-12-20T21:25:40.640' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'hdudgehd@ddd.com', N'0366956536', N'admin', 3, N'0,0,0,0,0,0', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'09565656333', N'$2a$11$ZdQRZaytI4L/JAB2CKS6DOnkI6NIglvM8SycJ0vBke.pOXtp7x.8e', N'Bdjdjd Hdhdhrh', NULL, NULL, NULL, NULL, N'Địa chỉ', 0, 0, CAST(N'2020-12-19T14:21:54.627' AS DateTime), CAST(N'2020-12-19T14:29:11.917' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, NULL, NULL, NULL, N'admin', NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'09565656656', N'$2a$11$Y8aLgkc3KIlGUnSwH5Cab.hNBPHvWXHh7QXbax3JUYIrKroje0wv.', N'Bdjdjd Hdhdhrh', NULL, NULL, NULL, NULL, N'Địa chỉ', 1, 0, CAST(N'2020-12-19T14:18:29.187' AS DateTime), CAST(N'2020-12-22T00:38:22.267' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, NULL, N'sdfdsf', NULL, N'admin', 2, N'A1', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'09659565656', N'$2a$11$MZZ1.pIIHTYAvlk/mbRKe.EvpLMz8rP/fADyomykltE4j2C3padxG', N'Tài Khoản A1', NULL, NULL, NULL, NULL, N'Vzhdbd vic', 1, 0, CAST(N'2021-02-26T20:19:55.587' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'gshshshs@hdhe.com', N'09659565656', N'admin', 2, N'A1,A2,A3,A4', N'1546228652', CAST(369.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'0977910500', N'$2a$11$WlQ/zwmxcB3JaeTyT3G7l.0rAyia1LM8bkXQBHJp.MD0CCCZJvaDK', N'Hồ Hoài', NULL, NULL, NULL, NULL, N'Hà nội', 1, 0, CAST(N'2021-03-15T23:46:41.793' AS DateTime), CAST(N'2021-03-16T05:17:51.230' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 2, NULL, N'Giáo viên', N'hdududh@dh.com', N'0977910500', N'admin', NULL, NULL, N'2666yyyeeu37', CAST(20000.00 AS Decimal(18, 2)), NULL, N'MD')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'56565631826', N'$2a$11$eD65pwJFaju000pIhL1oVevgeuK1rFHyyZr5G7wHX4iQIOMsxeqcy', N'Jdhdjej Ueuehe', NULL, NULL, NULL, NULL, N'Jehehehehehe rhe r r r r r r', 1, 0, CAST(N'2020-12-18T23:14:30.310' AS DateTime), CAST(N'2020-12-21T02:43:33.250' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, NULL, NULL, NULL, N'admin', 1, N'DICH_VU_DAOTAO', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'6999999999', N'$2a$11$UfsCzYf2zheSidTkcvU2quDFXO70C.AArEI2H9.anYV3W.kYrouvS', N'Lê Vùng 1', NULL, NULL, NULL, NULL, N'Jdjđjjd', 2, 0, CAST(N'2021-03-16T09:06:57.327' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Trưởng vùng', N'hehdheh@he.com', N'6999999999', N'admin', NULL, NULL, N'82727373djjddnd', CAST(5000000.00 AS Decimal(18, 2)), NULL, N'TC')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'86316164656', N'$2a$11$lANKkWXy2T48mHvn1OV2TuwGiaxvBvmifUnVR.FnPxMxjVolUaEJq', N'Hdmkhdd', NULL, NULL, NULL, NULL, N'Hshduryeu@heyr.com', 1, 0, CAST(N'2020-12-20T21:28:01.280' AS DateTime), CAST(N'2020-12-22T19:10:53.503' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'heydueuee@djdjd.com', N'86316164656', N'admin', 3, N'0,0,0,0,0,0', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'89693850500', N'$2a$11$kwqFSFCYUBZKdLNkRJ1D9udl4HOnOMjttnKL8r3hmwekI4PbgCXai', N'Uhuuhyhhu Hygyyb', NULL, NULL, NULL, NULL, N'Ubububu ubuhuh', 1, 0, CAST(N'2020-12-20T21:30:40.390' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, N'Học sinh', N'uhuhyhgygtft@inji.com', N'89693850500', N'admin', 2, N'A1,A2,A4', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'96968699696', N'$2a$11$ZbUEkbieWTZLqqV8FJffA.UjDmvdR26iAPefJScCHXsyTFH83qB6S', N'Minin', NULL, NULL, NULL, NULL, N'9866ybuhyh', 1, 0, CAST(N'2020-12-20T22:42:32.817' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 3, NULL, N'Phụ huynh', N'yhuhhybu@ubuh.com', N'96968699696', N'admin', NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'98665656566', N'$2a$11$lF8xl8hRN5t0YnWmz96DyOaST2PLYuL//924gun8UJ9pQ0uO0HxMi', N'Hrhrhrhr', NULL, NULL, NULL, NULL, N'Hdhdyehudue heheheh', 1, 0, CAST(N'2020-12-19T14:43:09.440' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, NULL, NULL, NULL, N'admin', NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'admin', N'$2a$11$dgjoQyNa2sVe2hcMbw996ej9RF1fhVA8Uic09URU8G7ycW8.bVhSa', N'Admin', N'1', CAST(N'1993-06-17' AS Date), N'http://103.145.63.73:8080/Uploads/admin_Screenshot (1).png', N'Đại học công nghiệp Hà Nội', N'Hà Nội', 1, 0, CAST(N'2020-11-10T00:00:00.000' AS DateTime), CAST(N'2021-03-15T23:01:20.357' AS DateTime), NULL, CAST(300000.00 AS Decimal(18, 2)), 1, NULL, NULL, N'admin@admin.com', N'0901020304', N'system', NULL, NULL, N'1234567888', CAST(5000000.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'anhdv', N'$2a$11$sk3BE3zkzYBKaqdfxuBRXOa3eY0AXoTHpDtulp.ePq6h/4ad2614K', N'Đào Văn Anh', N'1', CAST(N'1980-12-20' AS Date), NULL, N'Đại học công nghiệp Hà Nội', N'Hà Nội', 1, 0, CAST(N'2020-12-20T23:57:05.080' AS DateTime), CAST(N'2020-12-21T00:36:40.577' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Trưởng phòng', N'dev.nghianh@gmail.com', N'0962590546', N'nghianh', 2, N'A1,A2,A3', NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'Ha.vu', N'$2a$11$hdz/M5ziqe8gjkGUUAzL6uz/7v0dovkAqbeUR1U3tfz7Q5SbBEiyC', N'Hạ Vũ', N'1', CAST(N'2020-12-01' AS Date), NULL, N'Bách Khoa', N'Hai Bà Trưng, Hà Nội, Việt Nam', 1, 0, CAST(N'2020-12-22T19:51:03.007' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 2, NULL, NULL, N'havditbk@gmail.com', N'0344355127', N'admin', 3, N'DICH_VU_DAOTAO', N'017144127', NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'hieulv', N'$2a$11$h1ly4mDJIMibbqFw0s0t6.nfP1ok6PW20.isscqbu1ZC7OLH4zAja', N'hieulv', N'1', CAST(N'2020-12-10' AS Date), NULL, N'test', NULL, 1, 0, CAST(N'2020-12-15T23:12:19.203' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, NULL, NULL, NULL, N'admin', NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'hoangnh', N'$2a$11$cK9aw.ul4vobg/QVGMvH4.Ye/7WUxhmRJDLGPdOs0NyqwVf3nsJDm', N'Nguyễn Ngọc Hoàng', N'1', CAST(N'1886-12-19' AS Date), NULL, N'Đại học công nghiệp Hà Nội', N'Hà Nội', 1, 0, CAST(N'2020-12-19T10:57:51.347' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 2, NULL, NULL, NULL, NULL, N'admin', NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'nghianh', N'$2a$11$HuuQbCwH.xGS8xkYTjwE0O.NiZpRNDkpf.93DIKj16C7o4XacmLTm', N'Nguyễn Hữu Nghĩa', N'1', CAST(N'1993-12-08' AS Date), N'http://103.145.63.73:8080/Uploads/nghianh_8f3330d6163782b88b506d396f5d156f.jpg', N'Đại học công nghiệp Hà Nội', N'Hà Nội', 1, 0, CAST(N'2020-12-16T00:05:44.893' AS DateTime), CAST(N'2021-03-15T10:50:07.810' AS DateTime), NULL, CAST(0.00 AS Decimal(18, 2)), 4, N'admin', N'Giám đốc', N'dev.nghianh@gmail.com', N'0962590546', N'admin', 3, N'DICH_VU_DAOTAO', N'123456789', CAST(100000.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'testpermission', N'$2a$11$sC8pI77/.uD85gjANyshlepgUA6fwPq9ioo.C4CvfWZdVhahHg0OG', N'TestPermission', N'1', CAST(N'2021-03-03' AS Date), NULL, NULL, N'Kim Mã - Ba Đình', 2, 0, CAST(N'2021-03-16T09:09:55.967' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 1, NULL, NULL, N'shootingstar.ldc@gmail.com', N'0336533544', N'admin', 2, N'A1,A2,A3', NULL, CAST(10000.00 AS Decimal(18, 2)), CAST(1.00 AS Decimal(18, 2)), N'LB')
GO
INSERT [dbo].[User] ([Username], [Password], [Fullname], [Gender], [Birthday], [Avatar], [School], [Address], [Status], [IsParents], [CreatedDate], [ModifyDate], [LastLogin], [Amount], [Type], [ChildrenAccount], [Title], [Email], [Phone], [CreateBy], [Services], [UserServices], [IdentityCard], [BackAmount], [TotalPay], [Branch]) VALUES (N'trangnv', N'$2a$11$EEhCvxR9gcaIjTESkzdl/O4MFTYETuAVRU07BSG9aUL2L3sY4cuv6', N'Nguyễn Văn Trang', N'1', CAST(N'1993-12-27' AS Date), NULL, N'Đại học công nghiệp Hà Nội', NULL, 1, 0, CAST(N'2020-12-27T11:01:22.657' AS DateTime), NULL, NULL, CAST(0.00 AS Decimal(18, 2)), 4, NULL, N'Nhân viên', N'trangnv@gmail.com', N'0962590546', N'admin', 1, N'DICH_VU_DAOTAO', NULL, CAST(100000.00 AS Decimal(18, 2)), NULL, NULL)
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 24, 10, 0, CAST(N'2021-03-14T17:37:41.500' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 25, 12, 0, CAST(N'2021-03-14T16:45:02.850' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 26, 7, 1, CAST(N'2021-03-14T17:37:54.453' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 27, 7, 0, CAST(N'2021-03-14T17:38:56.563' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 28, 0, 0, CAST(N'2021-03-14T23:09:23.003' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0111111111', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 24, NULL, NULL, CAST(N'2021-02-27T06:54:52.880' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 25, NULL, NULL, CAST(N'2021-02-27T07:07:04.680' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 26, NULL, NULL, CAST(N'2021-03-03T22:26:18.477' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 27, NULL, NULL, CAST(N'2021-03-03T07:30:24.483' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 28, NULL, NULL, CAST(N'2021-03-14T16:50:59.060' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0222222222', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 21, NULL, NULL, CAST(N'2021-02-27T06:33:16.653' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 22, NULL, NULL, CAST(N'2021-02-27T06:38:30.503' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 23, NULL, NULL, CAST(N'2021-02-27T06:49:38.203' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 24, NULL, NULL, CAST(N'2021-02-27T06:54:51.973' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 25, NULL, NULL, CAST(N'2021-02-27T07:07:03.727' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 26, NULL, NULL, CAST(N'2021-03-03T22:26:18.237' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 27, NULL, NULL, CAST(N'2021-03-03T07:30:23.563' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 28, NULL, NULL, CAST(N'2021-03-14T16:50:59.043' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533533', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'03365335666', 4, 70, 1, CAST(N'2021-01-18T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'03365335666', 20, NULL, NULL, CAST(N'2021-02-03T22:05:40.020' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'03365335666', 30, NULL, NULL, CAST(N'2021-03-16T12:41:53.880' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0336533599', 31, 4, 0, CAST(N'2021-03-16T17:32:37.603' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355120', 30, NULL, NULL, CAST(N'2021-03-16T12:41:53.880' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355121', 26, NULL, NULL, CAST(N'2021-03-03T22:26:18.537' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355121', 27, NULL, NULL, CAST(N'2021-03-03T07:30:24.717' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355121', 28, NULL, NULL, CAST(N'2021-03-14T16:50:59.060' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355121', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 21, NULL, NULL, CAST(N'2021-02-27T06:33:16.887' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 22, NULL, NULL, CAST(N'2021-02-27T06:38:30.723' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 23, NULL, NULL, CAST(N'2021-02-27T06:49:38.437' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 24, NULL, NULL, CAST(N'2021-02-27T06:54:52.193' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 25, NULL, NULL, CAST(N'2021-02-27T07:07:03.960' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 26, NULL, NULL, CAST(N'2021-03-03T22:26:18.297' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 27, NULL, NULL, CAST(N'2021-03-03T07:30:23.797' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 28, NULL, NULL, CAST(N'2021-03-14T16:50:59.043' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'0344355127', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 21, NULL, NULL, CAST(N'2021-02-27T06:33:17.120' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 22, NULL, NULL, CAST(N'2021-02-27T06:38:30.957' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 23, NULL, NULL, CAST(N'2021-02-27T06:49:38.657' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 24, NULL, NULL, CAST(N'2021-02-27T06:54:52.427' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 25, NULL, NULL, CAST(N'2021-02-27T07:07:04.197' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 26, NULL, NULL, CAST(N'2021-03-03T22:26:18.357' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 27, NULL, NULL, CAST(N'2021-03-03T07:30:24.030' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 28, NULL, NULL, CAST(N'2021-03-14T16:50:59.060' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'09659565656', 29, NULL, NULL, CAST(N'2021-03-14T16:50:59.403' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'admin', 20, 0, 0, CAST(N'2021-03-16T14:28:20.603' AS DateTime))
GO
INSERT [dbo].[UserExam] ([Username], [ExamId], [Score], [IsPass], [CreateDate]) VALUES (N'admin', 30, 0, 0, CAST(N'2021-03-16T15:02:39.237' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0111111111', N'ADMIN', N'admin', CAST(N'2021-03-16T00:31:28.760' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0111111111', N'HR', N'admin', CAST(N'2021-03-16T00:31:28.773' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0111111111', N'STUDENT', N'admin', CAST(N'2021-03-16T08:55:15.843' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0111111111', N'USER', N'admin', CAST(N'2021-03-04T10:07:00.927' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533400', N'EMPLOYEE', N'0336533500', CAST(N'2021-03-16T09:54:13.060' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533500', N'EMPLOYEE', N'admin', CAST(N'2021-03-16T09:03:49.763' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533501', N'EMPLOYEE', N'0336533500', CAST(N'2021-03-16T09:52:20.057' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533502', N'EMPLOYEE', N'0336533500', CAST(N'2021-03-16T09:55:51.430' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533503', N'EMPLOYEE', N'0336533501', CAST(N'2021-03-16T10:07:12.773' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533533', N'ADMIN', N'admin', CAST(N'2021-03-01T08:01:31.143' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533533', N'HR', N'admin', CAST(N'2021-03-01T08:01:31.157' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533533', N'STUDENT', N'admin', CAST(N'2021-03-01T08:01:31.157' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533533', N'USER', N'admin', CAST(N'2021-03-01T08:01:31.157' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533568', N'STUDENT', N'admin', CAST(N'2021-03-14T18:44:34.173' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533599', N'STUDENT', N'0336533500', CAST(N'2021-03-16T16:38:54.413' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533600', N'STUDENT', N'admin', CAST(N'2021-03-16T11:48:39.777' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533601', N'STUDENT', N'0336533503', CAST(N'2021-03-16T11:50:00.963' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533700', N'EMPLOYEE', N'0336533500', CAST(N'2021-03-16T12:31:02.070' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533700', N'HR', N'admin', CAST(N'2021-03-16T12:31:51.320' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533701', N'ACCOUNTANT', N'admin', CAST(N'2021-03-16T12:34:14.147' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533701', N'EMPLOYEE', N'0336533700', CAST(N'2021-03-16T12:33:31.147' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533800', N'EDUCATION', N'admin', CAST(N'2021-03-16T13:13:18.377' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0336533800', N'EMPLOYEE', N'0977910500', CAST(N'2021-03-16T13:12:23.923' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0344355127', N'STUDENT', N'admin', CAST(N'2021-02-01T07:03:11.407' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'09565656333', N'STUDENT', N'admin', CAST(N'2020-12-19T14:29:12.187' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'09565656656', N'ADMIN', N'admin', CAST(N'2020-12-22T00:38:22.670' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'09565656656', N'HR', N'admin', CAST(N'2020-12-22T00:38:22.670' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'09565656656', N'STUDENT', N'admin', CAST(N'2020-12-22T00:38:22.670' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'09565656656', N'USER', N'admin', CAST(N'2020-12-22T00:38:22.670' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'0977910500', N'TEACHER', N'admin', CAST(N'2021-03-16T05:17:51.373' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'56565631826', N'HR', N'admin', CAST(N'2020-12-21T02:21:53.857' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'56565631826', N'STUDENT', N'admin', CAST(N'2020-12-21T02:43:34.890' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'56565631826', N'USER', N'admin', CAST(N'2020-12-21T02:21:53.860' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'6999999999', N'EMPLOYEE', N'admin', CAST(N'2021-03-16T09:06:57.623' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'86316164656', N'HR', N'admin', CAST(N'2020-12-22T19:10:54.567' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'admin', N'ADMIN', N'admin', CAST(N'2020-12-16T10:07:21.693' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'anhdv', N'TEST', N'admin', CAST(N'2020-12-21T00:37:04.913' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'anhdv', N'USER', N'admin', CAST(N'2020-12-21T00:37:08.570' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'Ha.vu', N'ADMIN', N'admin', CAST(N'2020-12-22T19:51:04.040' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'hieulv', N'ADMIN', N'admin', CAST(N'2020-12-15T23:12:20.260' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'hieulv', N'USER', N'admin', CAST(N'2020-12-15T23:12:20.260' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'hoangnh', N'USER', N'admin', CAST(N'2020-12-19T10:57:52.447' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'nghianh', N'USER', N'admin', CAST(N'2021-01-08T18:02:20.377' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'testpermission', N'EMPLOYEE', N'admin', CAST(N'2021-03-16T09:09:56.233' AS DateTime))
GO
INSERT [dbo].[UserRoleMapping] ([Username], [RoleId], [Usercreated], [DateCreate]) VALUES (N'trangnv', N'USER', N'admin', CAST(N'2020-12-27T11:01:23.377' AS DateTime))
GO
ALTER TABLE [dbo].[Services] ADD  CONSTRAINT [DF_Services_Price]  DEFAULT ((0)) FOR [Price]
GO
ALTER TABLE [dbo].[Services] ADD  CONSTRAINT [DF_Services_Status]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_BackAmount]  DEFAULT ((0)) FOR [BackAmount]
GO
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_TotalPay]  DEFAULT ((0)) FOR [TotalPay]
GO
/****** Object:  StoredProcedure [dbo].[PROC_BackAmount]    Script Date: 03/16/2021 11:08:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[PROC_BackAmount](
	@p_username NVARCHAR(50)
)
AS
BEGIN
	IF OBJECT_ID('tempdb..#DATA_BACKAMOUNT') IS NOT NULL DROP TABLE #DATA_BACKAMOUNT
	;WITH userdata AS 
	(
	   SELECT Username, CreateBy FROM [User] u 
	   WHERE u.Username = @p_username
	   UNION ALL
	   SELECT p.Username, p.CreateBy FROM [User] p 
	   JOIN userdata b ON p.Username = b.CreateBy
	) 
	SELECT dt.Username INTO #DATA_BACKAMOUNT FROM userdata dt 
	WHERE dt.Username <> @p_username

	SELECT * FROM #DATA_BACKAMOUNT
END
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Phương thức thanh toán' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'BalanceHistory', @level2type=N'COLUMN',@level2name=N'Type'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Khóa học' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Class', @level2type=N'COLUMN',@level2name=N'CourseId'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Thời khóa biểu' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Class', @level2type=N'COLUMN',@level2name=N'TimeTable'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Điểm tối thiểu được để hoàn thành' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Exam', @level2type=N'COLUMN',@level2name=N'PassPoint'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'1 - Đã hoàn thành, 0 - Chưa hoàn thành, 2 - Đuổi học' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'StudentClass', @level2type=N'COLUMN',@level2name=N'Status'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'1 - Học sinh, 2 - Giáo viên, 3 - Phụ Huynh, 4 - Khác' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'User', @level2type=N'COLUMN',@level2name=N'Type'
GO
