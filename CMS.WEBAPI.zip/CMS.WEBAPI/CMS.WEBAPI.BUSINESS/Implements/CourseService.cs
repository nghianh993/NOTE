﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class CourseService : ICourseService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<CourseModel> GetListCourses(CourseModel courseModel)
        {
            try
            {
                var model = new PagingModel<CourseModel>();
                var query = _dbContext.Courses
                    .Where(x => (string.IsNullOrEmpty(courseModel.Name) || x.Name.Contains(courseModel.Name))
                    && (string.IsNullOrEmpty(courseModel.Branch) || x.Branch.Equals(courseModel.Branch))
                    && (courseModel.Status == null || x.Status == courseModel.Status)
                    && x.Status != (int)Status.DELETE);

                model.total = query.Count();
                model.page = courseModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(courseModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Name);

                model.data = query.Select(x => new CourseModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    Description = x.Description,
                    CreatedBy = x.CreatedBy,
                    StartDate = x.StartDate,
                    EndDate = x.EndDate,
                    CreatedDate = x.CreatedDate,
                    Status = x.Status,
                    Branch = x.Branch
                }).Skip((courseModel.current - 1) * courseModel.pageSize).Take(courseModel.pageSize).ToList();

                model.data = model.data.Select(x => new CourseModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    Description = x.Description,
                    CreatedBy = x.CreatedBy,
                    StartDate = x.StartDate,
                    EndDate = x.EndDate,
                    CreatedDate = x.CreatedDate,
                    Status = x.Status,
                    Branch = x.Branch,
                    TotalStudent = TotalStudentInCourse(x.Id)
                }).ToList();

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<CourseModel>();
            }
        }

        public ResponseModel CreateCourse(CourseModel courseModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var courseItemExist = _dbContext.Courses.SingleOrDefault(c => c.Name.Equals(courseModel.Name) && c.Status != (int)Status.DELETE);
                if (courseItemExist != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var courseItem = MapperHelper.Map<Course, CourseModel>(courseModel);
                    _dbContext.Courses.Add(courseItem);
                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel UpdateCourse(CourseModel courseModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var courseItem = _dbContext.Courses.SingleOrDefault(c => c.Name.Equals(courseModel.Name) && c.Status != (int)Status.DELETE);
                if (courseItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    courseItem.Name = courseModel.Name;
                    courseItem.Description = courseModel.Description;
                    courseItem.StartDate = courseModel.StartDate;
                    courseItem.EndDate = courseModel.EndDate;
                    courseItem.StartDate = courseModel.StartDate;
                    courseItem.Status = (int)Status.ACTIVE;
                    courseItem.Branch = courseModel.Branch;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteCourse(CourseModel courseModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var courseItem = _dbContext.Courses.SingleOrDefault(c => c.Id.Equals(courseModel.Id) && c.Status != (int)Status.DELETE);
                if (courseItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    courseItem.Status = (int)Status.DELETE;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteMultiCourses(List<int> ids)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var datas = _dbContext.Courses.Where(c => ids.Contains(c.Id)).Select(c => c).ToList();
                if (datas != null && datas.Any())
                {
                    foreach (var item in datas)
                    {
                        item.Status = (int)Status.DELETE;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
        public ResponseModel LockOrUnlock(List<int> ids, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var courses = _dbContext.Courses.Where(c => ids.Contains(c.Id)).Select(c => c).ToList();
                if (courses != null && courses.Any())
                {
                    foreach (var item in courses)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
        private int TotalStudentInCourse(int courseId)
        {
            //get classCode using course ID 
            var classCodes = _dbContext.Classes.Where(x => x.CourseId.Equals(courseId)).Select(x => x.ClassCode).ToList();
            var totalStudent = 0;
            if (classCodes.Count > 0)
            {
                foreach(var classCode in classCodes)
                {
                    //get total student In Class
                    totalStudent += _dbContext.StudentClasses.Where(c => c.ClassId.Equals(classCode) && c.Status != (int)Status.DELETE).Count();
                }
            }

            return totalStudent;
        }
    }
}
