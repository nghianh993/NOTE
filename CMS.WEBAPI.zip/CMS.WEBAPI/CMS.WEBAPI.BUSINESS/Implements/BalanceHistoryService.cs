﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class BalanceHistoryService : IBalanceHistoryService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<BalanceHistoryModel> GetAll(BalanceHistoryModel model)
        {
            try
            {
                var data = new PagingModel<BalanceHistoryModel>();
                var query = from c in _dbContext.BalanceHistories
                            where (string.IsNullOrEmpty(model.Username) || c.Username.Contains(model.Username))
                            && (model.Status == null || c.Status == model.Status)
                            && (model.Type == null || c.Type == model.Type)
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderByDescending(c => c.ID);

                data.data = query.Select(p => new BalanceHistoryModel
                {
                    ID = p.ID,
                    Username = p.Username,
                    Amount = p.Amount,
                    Type = p.Type,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    CreatedUser = p.CreatedUser,
                    Note = p.Note
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<BalanceHistoryModel>();
            }
        }

        public ResponseModel Add(BalanceHistoryModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var history = MapperHelper.Map<BalanceHistory, BalanceHistoryModel>(model);
                history.CreatedDate = DateTime.Now;
                history.Status = (int)Status.NOT_APPROVE;
                _dbContext.BalanceHistories.Add(history);
                _dbContext.SaveChanges();

                response.Success = true;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Approve(int id, string currentUser)
        {
            var response = new ResponseModel();
            try
            {
                //Get Balance 
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var balance = _dbContext.BalanceHistories.Where(c => c.ID == id).FirstOrDefault();
                if (balance != null)
                {
                    //Get backamount cate 
                    var lstBackAmount = _dbContext.BackAmounts.Select(c => c).ToList();
                    //Get user 
                    var param = new SqlParameter
                    {
                        ParameterName = "p_username",
                        Value = balance.Username
                    };
                    var lstUser = _dbContext.Database.SqlQuery<string>("EXEC [dbo].[PROC_BackAmount] @p_username", param).ToList();
                    //lstUser.Reverse();
                    //Calculate the percentage add money
                    var payer = _dbContext.Users.Where(c => c.Username.Equals(balance.Username)).Select(c => c).FirstOrDefault();
                    decimal percent = 0;
                    if ((payer.TotalPay ?? 0) > 0 && balance.Amount < (payer.TotalPay ?? 0))
                    {
                        percent = balance.Amount / (payer.TotalPay ?? 0);
                    }
                    else
                    {
                        percent = 1;
                    }
                    decimal outTotal = 0;
                    //If two lists have data => make a refund
                    if (lstUser != null && lstUser.Any())
                    {
                        for (int i = 0; i < lstUser.Count; i++)
                        {
                            decimal outBackAmount = 0;
                            decimal totalCurrentAmount = 0;
                            AddAmount(lstUser[i], percent, currentUser, i == 0, out outBackAmount, out totalCurrentAmount, ref outTotal);
                            //Send notification
                            var content = string.Format(Message.BACK_AMOUNT, string.IsNullOrEmpty(string.Format("{0:#,###}", outBackAmount)) ? "0" : string.Format("{0:#,###}", outBackAmount),
                                string.IsNullOrEmpty(string.Format("{0:#,###}", totalCurrentAmount)) ? "0" : string.Format("{0:#,###}", totalCurrentAmount));
                            new NotificationService().PushNotification(content.ToString(), "system", lstUser[i]);
                        }
                        balance.ApproveDate = DateTime.Now;
                        balance.Status = (int)Status.ACTIVE;
                        _dbContext.SaveChanges();
                    }

                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Reject(int id)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var balance = _dbContext.BalanceHistories.SingleOrDefault(c => c.ID == id);
                if (balance == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    //Reject status
                    balance.Status = (int)Status.NOT_ACTIVE;

                    _dbContext.SaveChanges();

                    //Send notification
                    var content = string.Format(Message.REJECT_AMOUNT, string.Format("{0:#,###}", balance.Amount));
                    new NotificationService().PushNotification(content.ToString(), "system", balance.CreatedUser);
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        #region Help method
        private void AddAmount(string username, decimal percent, string currentUser, bool isFirst, out decimal outBackAmount, out decimal outTotalAmount, ref decimal outTotal)
        {
            try
            {
                using (var context = new BEDATAEntities())
                {
                    var user = context.Users.Where(c => c.Username.Equals(username)).FirstOrDefault();
                    if (user != null)
                    {
                        var currentAmount = user.Amount;
                        decimal backamount = isFirst ? user.BackAmount ?? 0 : (user.BackAmount ?? 0) - outTotal;

                        user.Amount = Math.Round(currentAmount + (percent * backamount), 0);

                        //Save history
                        var backAmountHis = new BackAmountHistory()
                        {
                            Amount = Math.Round(percent * backamount, 0),
                            CreateDate = DateTime.Now,
                            CurrentAmount = currentAmount,
                            NewAmount = user.Amount,
                            UserCreate = currentUser,
                            UserId = user.Username
                        };
                        context.BackAmountHistories.Add(backAmountHis);
                        context.SaveChanges();

                        outBackAmount = Math.Round(percent * backamount, 0);
                        outTotalAmount = user.Amount;
                        outTotal = user.BackAmount ?? 0;
                    }
                    else
                    {
                        outBackAmount = 0;
                        outTotalAmount = 0;
                        outTotal = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                outBackAmount = 0;
                outTotalAmount = 0;
                outTotal = 0;
            }
        }
        #endregion
    }
}
