﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.COMMON.Helper;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class UserService : IUserService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<UserModel> GetAllUser(UserModel userModel)
        {
            try
            {
                var model = new PagingModel<UserModel>();
                var query = from c in _dbContext.Users
                            where (string.IsNullOrEmpty(userModel.Username) || c.Username.Contains(userModel.Username))
                            && (string.IsNullOrEmpty(userModel.Fullname) || c.Fullname.Contains(userModel.Fullname))
                            && (userModel.Gender == null || c.Gender.Equals(userModel.Gender))
                            && (userModel.Status == null || (c.Status == userModel.Status && c.Status != (int)Status.WAITING))
                            && (userModel.Type == null || c.Type == userModel.Type)
                            && (userModel.UserCreated == null || c.CreateBy == userModel.UserCreated)
                            select c;

                model.total = query.Count();
                model.page = userModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(userModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Username);

                model.data = query.Select(p => new UserModel
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    IdentityCard = p.IdentityCard,
                    BackAmount = p.BackAmount,
                    TotalPay = p.TotalPay,
                    TotalPayEUR = p.TotalPayEUR,
                    Branch = p.Branch,
                    UserCreated = p.CreateBy
                }).Skip((userModel.current - 1) * userModel.pageSize).Take(userModel.pageSize).ToList();

                model.data = model.data.Select(p => new UserModel()
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    roleIds = GetRole(p.Username),
                    IdentityCard = p.IdentityCard,
                    BackAmount = p.BackAmount,
                    TotalPay = p.TotalPay,
                    TotalPayEUR = p.TotalPayEUR,
                    Branch = p.Branch,
                    UserCreated = p.UserCreated
                }).ToList();
                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<UserModel>();
            }

        }

        public PagingModel<UserModel> GetAllUserStaff(UserModel userModel)
        {
            try
            {
                var model = new PagingModel<UserModel>();
                var lstType = new List<int>() { 2, 4 };
                var query = from c in _dbContext.Users
                            where (string.IsNullOrEmpty(userModel.Username) || c.Username.Contains(userModel.Username))
                            && (string.IsNullOrEmpty(userModel.Fullname) || c.Fullname.Contains(userModel.Fullname))
                            && (userModel.Gender == null || c.Gender.Equals(userModel.Gender))
                            && (userModel.Status == null || c.Status == userModel.Status)
                            && (userModel.Type == null || c.Type == userModel.Type)
                            && lstType.Contains(c.Type)
                            select c;

                model.total = query.Count();
                model.page = userModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(userModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Username);

                model.data = query.Select(p => new UserModel
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    IdentityCard = p.IdentityCard,
                    BackAmount = p.BackAmount
                }).Skip((userModel.current - 1) * userModel.pageSize).Take(userModel.pageSize).ToList();

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<UserModel>();
            }
        }

        public ResponseModel Add(UserModel userModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var user = _dbContext.Users.SingleOrDefault(c => c.Username.Equals(userModel.Username));
                if (user != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    var newUser = MapperHelper.Map<User, UserModel>(userModel);
                    newUser.CreatedDate = DateTime.Now;
                    newUser.Status = (userModel.Type == (int)UserType.OTHER ? (int)Status.WAITING : (int)Status.NOT_APPROVE);
                    newUser.CreateBy = userModel.UserCreated;
                    newUser.Password = PasswordHelper.GeneratePassword(userModel.Username, WebUtils.GetAppSettingsConfigValue(WebConstant.DEFAULT_PASS));
                    _dbContext.Users.Add(newUser);
                    _dbContext.SaveChanges();

                    //Lưu thông tin nhóm quyền
                    if (userModel.roleIds != null)
                    {
                        foreach (var role in userModel.roleIds)
                        {
                            var userRoleMapping = new UserRoleMapping();
                            userRoleMapping.RoleId = role;
                            userRoleMapping.Username = newUser.Username;
                            userRoleMapping.DateCreate = DateTime.Now;
                            userRoleMapping.Usercreated = userModel.UserCreated;
                            _dbContext.UserRoleMappings.Add(userRoleMapping);
                        }
                        _dbContext.SaveChanges();
                    }

                    //add exam for user type = 4
                    if(userModel.Type == (int)UserType.OTHER)
                    {
                        var examItem = new UserExam()
                        {
                            Username = userModel.Username.Trim(),
                            ExamId = (int)ExamIdDefault.EXAMID,
                            CreateDate = DateTime.Now
                        };
                        _dbContext.UserExams.Add(examItem);
                        _dbContext.SaveChanges();
                    }

                    response.Success = true;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(UserModel userModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var user = _dbContext.Users.SingleOrDefault(c => c.Username.Equals(userModel.Username));
                if (user == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    user.Fullname = userModel.Fullname;
                    user.Gender = userModel.Gender;
                    user.Birthday = userModel.Birthday;
                    user.Address = userModel.Address;
                    user.School = userModel.School;
                    user.ModifyDate = DateTime.Now;
                    user.Title = userModel.Title;
                    user.Type = userModel.Type ?? 1;
                    user.ChildrenAccount = userModel.ChildrenAccount;
                    user.Email = userModel.Email;
                    user.Phone = userModel.Phone;
                    user.Services = userModel.Services;
                    user.UserServices = userModel.UserServices;
                    user.IdentityCard = userModel.IdentityCard;
                    user.BackAmount = userModel.BackAmount;
                    user.Branch = userModel.Branch;
                    user.TotalPay = userModel.TotalPay;
                    user.TotalPayEUR = userModel.TotalPayEUR;

                    _dbContext.SaveChanges();

                    //Lưu thông tin nhóm quyền
                    if (userModel.roleIds != null)
                    {
                        //Xóa nhóm quyền cũ
                        var userRoles = _dbContext.UserRoleMappings.Where(c => c.Username.Equals(userModel.Username))
                            .Select(c => c).ToList();
                        foreach (var role in userRoles)
                        {
                            _dbContext.UserRoleMappings.Remove(role);
                        }

                        _dbContext.SaveChanges();
                        foreach (var role in userModel.roleIds)
                        {
                            var userRoleMapping = new UserRoleMapping();
                            userRoleMapping.RoleId = role;
                            userRoleMapping.Username = userModel.Username;
                            userRoleMapping.DateCreate = DateTime.Now;
                            userRoleMapping.Usercreated = userModel.UserCreated;
                            _dbContext.UserRoleMappings.Add(userRoleMapping);
                        }
                        _dbContext.SaveChanges();
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel ChangeInfo(UserModel userModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var user = _dbContext.Users.SingleOrDefault(c => c.Username.Equals(userModel.Username));
                if (user == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    response.Message = Message.UPDATE_SUCCESS;
                    user.Fullname = userModel.Fullname;
                    user.Gender = userModel.Gender;
                    user.Birthday = userModel.Birthday;
                    user.Address = userModel.Address;
                    user.School = userModel.School;
                    user.ModifyDate = DateTime.Now;
                    user.Email = userModel.Email;
                    user.Phone = userModel.Phone;
                    user.IdentityCard = userModel.IdentityCard;
                    if(!string.IsNullOrEmpty(userModel.Avatar))
                    {
                        user.Avatar = userModel.Avatar;
                    }
                    
                    _dbContext.SaveChanges();

                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel LockOrUnlock(List<string> userIds, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var users = _dbContext.Users.Where(c => userIds.Contains(c.Username)).Select(c => c).ToList();
                if (users != null && users.Any())
                {
                    foreach (var item in users)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<RoleForUserModel> GetAllRoleActive()
        {
            try
            {
                var lstRole = _dbContext.Roles.Where(c => c.Status == (int)Status.ACTIVE)
                    .Select(c => new RoleForUserModel()
                    {
                        value = c.RoleId,
                        label = c.RoleName
                    }).ToList();
                return lstRole ?? new List<RoleForUserModel>();
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<RoleForUserModel>();
            }
        }

        public ResponseModel CheckDuplicateUser(string username)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var user = _dbContext.Users.Where(c => c.Username.Equals(username)).Select(c => c).FirstOrDefault();
                if (user == null)
                {
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<SelectCommonModel> GetAllChildren(string currentUser)
        {
            try
            {
                var user = _dbContext.Users.Where(c => c.Status == (int)Status.ACTIVE
                && c.Type == (int)UserType.STUDENT && !c.Username.Equals(currentUser))
                    .Select(c => new SelectCommonModel()
                    {
                        value = c.Username,
                        label = c.Fullname
                    }).ToList();

                return user ?? new List<SelectCommonModel>();
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<SelectCommonModel>();
            }
        }

        public UserModel GetDetailUser(string currentUser)
        {
            try
            {
                var user = (from c in _dbContext.Users join
                            ps in _dbContext.Users on c.Username equals ps.ChildrenAccount into d
                            from p in d.DefaultIfEmpty()
                            where c.Username.Equals(currentUser)
                            select new UserModel()
                            {
                                Username = c.Username,
                                Birthday = c.Birthday,
                                Fullname = c.Fullname,
                                Amount = c.Amount,
                                Avatar = c.Avatar,
                                Address = c.Address,
                                ChildrenAccount = c.ChildrenAccount,
                                School = c.School,
                                Status = c.Status,
                                CreatedDate = c.CreatedDate,
                                Gender = c.Gender,
                                Type = c.Type,
                                Title = c.Title,
                                IsParents = c.IsParents,
                                Email = c.Email,
                                Phone = c.Phone,
                                Branch = c.Branch,
                                TotalPay = c.TotalPay,
                                TotalPayEUR = c.TotalPayEUR,
                                Services = c.Services,
                                UserServices = c.UserServices,
                                IdentityCard = c.IdentityCard,
                                BackAmount = c.BackAmount,
                                ModifyDate = c.ModifyDate,
                                UserCreated = c.CreateBy,
                                ParentAccount = p.Username,
                                ParentFullname = p.Fullname,
                                ParentPhone = p.Phone
                            }).FirstOrDefault();
                return user;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new UserModel();
            }
        }

        public UserModel GetParentUser(string userGet)
        {
            try
            {
                var user = _dbContext.Users.Where(p => p.ChildrenAccount.Equals(userGet))
                    .Select(p => new UserModel()
                    {
                        Username = p.Username,
                        Fullname = p.Fullname
                    }).FirstOrDefault();

                return user;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new UserModel();
            }
        }

        public ResponseModel Cash(CashModel cashModel)
        {
            var response = new ResponseModel();
            try
            {
                using(var context = new BEDATAEntities())
                {
                    response.StatusCode = (int)HttpStatusCode.SUCCESS;
                    var user = context.Users.Where(c => c.Username.Equals(cashModel.userCash)).Select(c => c).FirstOrDefault();
                    if (user != null)
                    {
                        if (user.Amount < cashModel.amount)
                        {
                            response.Success = false;
                            response.Message = Message.NOT_ENOUGH;
                        }
                        else
                        {
                            //Save history
                            var backAmountHis = new BackAmountHistory()
                            {
                                Amount = (user.BackAmount ?? 0),
                                CreateDate = DateTime.Now,
                                CurrentAmount = user.Amount,
                                NewAmount = user.Amount - cashModel.amount,
                                UserCreate = cashModel.currentUser,
                                UserId = user.Username,
                                Note = cashModel.note
                            };
                            context.BackAmountHistories.Add(backAmountHis);

                            //Lưu lại số tiền bị rút
                            user.Amount = user.Amount - cashModel.amount;

                            context.SaveChanges();

                            //Gửi thông báo rút tiền
                            var content = string.Format(Message.CHANGE_AMOUNT, string.Format("{0:#,###}", cashModel.amount), cashModel.note);
                            new NotificationService().PushNotification(content.ToString(), "system", user.Username);

                            response.Success = true;
                        }
                    }
                    else
                    {
                        response.Success = false;
                        response.Message = Message.NOT_EXISTS;
                    }

                    return response;
                }
                
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel ChangePassword(ChangePasswordModel changePW)
        {
            var response = new ResponseModel();
            try
            {
                if (!changePW.NewPassword.Equals(changePW.ReNewPassword))
                {
                    response.Success = false;
                    response.Message = Message.PW_ERROR1;
                }
                else
                {
                    using (var context = new BEDATAEntities())
                    {
                        response.StatusCode = (int)HttpStatusCode.SUCCESS;
                        var user = context.Users.Where(c => c.Username.Equals(changePW.CurrentUser)).Select(c => c).FirstOrDefault();
                        if (user != null)
                        {
                            //Kiểm tra mật khẩu cũ có đúng không?
                            var check = PasswordHelper.VerifyPassword(changePW.CurrentUser, changePW.CurrentPassword, user.Password);
                            if (check)
                            {
                                user.Password = PasswordHelper.GeneratePassword(changePW.CurrentUser, changePW.NewPassword);
                                context.SaveChanges();
                                response.Success = true;
                                response.Message = Message.UPDATE_SUCCESS;
                            }
                            else
                            {
                                response.Success = false;
                                response.Message = Message.PW_ERROR;
                            }
                        }
                        else
                        {
                            response.Success = false;
                            response.Message = Message.NOT_EXISTS;
                        }
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
        
        #region Help method
        private List<string> GetRole(string username)
        {
            try
            {
                var lstRole = (from a in _dbContext.Users
                               join b in _dbContext.UserRoleMappings on a.Username equals b.Username
                               join c in _dbContext.Roles on b.RoleId equals c.RoleId
                               where c.Status == (int)Status.ACTIVE
                               && a.Username.Equals(username)
                               select c.RoleId).ToList();
                return lstRole;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<string>();
            }
        }

        #endregion
    }
}
