﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class UserClassService : IUserClassService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public PagingModel<UserModel> GetUsersNoClass(UserModel userModel)
        {
            var model = new PagingModel<UserModel>();
            try
            {
                var query = from user in _dbContext.Users
                            join s in _dbContext.StudentClasses on user.Username equals s.StudentId into us
                            from studentClass in us.DefaultIfEmpty()
                            where user.Status == (int)Status.ACTIVE && user.Type == 1
                            && (userModel.IsArrange == 1 ? !string.IsNullOrEmpty(studentClass.ClassId) : string.IsNullOrEmpty(studentClass.ClassId))
                            && (string.IsNullOrEmpty(userModel.Username) || user.Username.Contains(userModel.Username))
                            && (string.IsNullOrEmpty(userModel.Fullname) || user.Fullname.Contains(userModel.Fullname))
                            && (userModel.Gender == null || user.Gender.Equals(userModel.Gender))
                            select new { user, studentClass};
                model.total = query.Count();
                model.page = userModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(userModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.user.Username);

                model.data = query.Select(p => new UserModel
                {
                    Username = p.user.Username,
                    Birthday = p.user.Birthday,
                    Fullname = p.user.Fullname,
                    Amount = p.user.Amount,
                    Avatar = p.user.Avatar,
                    Address = p.user.Address,
                    ChildrenAccount = p.user.ChildrenAccount,
                    School = p.user.School,
                    Status = p.user.Status,
                    CreatedDate = p.user.CreatedDate,
                    Gender = p.user.Gender,
                    Type = p.user.Type,
                    Title = p.user.Title,
                    IsParents = p.user.IsParents,
                    Email = p.user.Email,
                    Phone = p.user.Phone,
                    Services = p.user.Services,
                    UserServices = p.user.UserServices,
                    IdentityCard = p.user.IdentityCard,
                    ClassCode = p.studentClass.ClassId
                }).Skip((userModel.current - 1) * userModel.pageSize).Take(userModel.pageSize).ToList();

                model.data = model.data.Select(p => new UserModel()
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    roleIds = GetRole(p.Username),
                    IdentityCard = p.IdentityCard,
                    ClassCode = p.ClassCode
                }).ToList();
                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<UserModel>();
            }
        }

        public PagingModel<UserModel> GetUsersByClassCode(UserModel userModel)
        {
            var model = new PagingModel<UserModel>();
            try
            {
                var query = from p in _dbContext.Users
                            join s in _dbContext.StudentClasses on p.Username equals s.StudentId into user
                            from studentClass in user.DefaultIfEmpty()
                            where p.Status == (int)Status.ACTIVE && p.Type == 1 
                            && studentClass.ClassId.Equals(userModel.ClassCode)
                            && (string.IsNullOrEmpty(userModel.Username) || p.Username.Contains(userModel.Username))
                            && (string.IsNullOrEmpty(userModel.Fullname) || p.Fullname.Contains(userModel.Fullname))
                            && (userModel.Gender == null || p.Gender.Equals(userModel.Gender))
                            && (userModel.Status == null || p.Status == userModel.Status)
                            select p;
                model.total = query.Count();
                model.page = userModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(userModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Username);

                model.data = query.Select(p => new UserModel
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    //roleIds = GetRole(p.Username),
                    IdentityCard = p.IdentityCard
                }).Skip((userModel.current - 1) * userModel.pageSize).Take(userModel.pageSize).ToList(); ;

                model.data = model.data.Select(p => new UserModel()
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    roleIds = GetRole(p.Username),
                    IdentityCard = p.IdentityCard
                }).ToList();
                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<UserModel>();
            }
        }

        public ResponseModel AddStudentToClass(StudentClassModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var item = _dbContext.StudentClasses.SingleOrDefault(c => c.ClassId.Equals(model.ClassId)
                && c.StudentId.Equals(model.StudentId) && c.Status != (int)Status.DELETE);

                if (item != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    //check total
                    if (CheckTotalCurrentStudent(model.ClassId))
                    {
                        response.Success = true;
                        var studentClass = MapperHelper.Map<StudentClass, StudentClassModel>(model);
                        _dbContext.StudentClasses.Add(studentClass);
                        _dbContext.SaveChanges();

                        //update total current student
                        var result = UpdateTotalCurrentStudent(model.ClassId);
                    }
                    else
                    {
                        response.Success = false;
                        response.Message = Message.MAX_STUDENT;
                    }

                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel CheckInStudent(CheckInRequestModel model, string teacherId)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                foreach(var item in model.CheckIns)
                {
                    //get student
                    var student = _dbContext.StudentClasses.SingleOrDefault(c => c.ClassId.Equals(model.ClassId)
                    && c.StudentId.Equals(item.StudentId) && c.Status == (int)Status.ACTIVE);

                    if(student == null)
                    {
                        response.Success = false;
                        response.Message = "Không tồn tại học sinh " + item.StudentId + " trong lớp " + model.ClassId;
                        break;
                    }
                    else
                    {
                        item.DateCheckIn = DateTime.Now;
                        item.TeacherId = teacherId;
                        //update info checkin for student
                        var listCheckin = JsonConvert.DeserializeObject<List<CheckInModel>>(student.Checkin) ?? new List<CheckInModel>();
                        listCheckin.Add(item);
                        student.Checkin = JsonConvert.SerializeObject(listCheckin, Formatting.Indented);
                        if(item.Status != 1)
                        {
                            student.TotalLeave = (student.TotalLeave ?? 0) + 1;
                        }
                    }
                }

                //update total have learnt to class
                var classitem = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(model.ClassId)
                    && c.Status == (int)Status.ACTIVE);

                classitem.TotalHaveLearnt = (classitem.TotalHaveLearnt ?? 0) + 1;
                
                _dbContext.SaveChanges();
                response.Success = true;

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }


        public ResponseModel DeleteStudentClass(StudentClassModel studentClassModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var item = _dbContext.StudentClasses.FirstOrDefault(x => x.ClassId.Equals(studentClassModel.ClassId)
                && x.StudentId.Equals(studentClassModel.StudentId));
                if(item == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;

                }
                else
                {

                    response.Success = true;
                    _dbContext.StudentClasses.Remove(item);
                    _dbContext.SaveChanges();
                }
                return response;

            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public string GetCheckInUserByClassCode(StudentClassModel studentClassModel)
        {
            try
            {
                var checkIn = "";
                var userItem = _dbContext.StudentClasses.SingleOrDefault(c => c.ClassId.Equals(studentClassModel.ClassId) && c.StudentId.Equals(studentClassModel.StudentId));
                if (userItem != null)
                {
                    checkIn = userItem.Checkin;
                }

                return checkIn;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return "";
            }

        }
        #region Help method
        private List<string> GetRole(string username)
        {
            try
            {
                var lstRole = (from a in _dbContext.Users
                               join b in _dbContext.UserRoleMappings on a.Username equals b.Username
                               join c in _dbContext.Roles on b.RoleId equals c.RoleId
                               where c.Status == (int)Status.ACTIVE
                               && a.Username.Equals(username)
                               select c.RoleId).ToList();
                return lstRole;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<string>();
            }
        }

        private bool UpdateTotalCurrentStudent(string classCode)
        {
            try
            {
                var data = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(classCode) && c.Status != (int)Status.DELETE);
                if (data != null)
                {
                    data.TotalCurrentStudent++;
                    _dbContext.SaveChanges();

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return false;
            }
        }

        private bool CheckTotalCurrentStudent(string classCode)
        {
            var data = _dbContext.Classes.SingleOrDefault(x => x.ClassCode.Equals(classCode));

            return (data.TotalCurrentStudent < data.MaxTotalStudent);

        }

        #endregion
    }
}
