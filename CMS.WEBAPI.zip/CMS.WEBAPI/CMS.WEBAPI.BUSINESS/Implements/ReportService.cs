﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class ReportService : IReportService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public DataSet GetReportData(string username, DateTime? fromDate, DateTime? endDate)
        {
            try
            {
                var adapter = (IObjectContextAdapter)_dbContext;
                var objectContext = adapter.ObjectContext;
                var parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@username", username));
                parameters.Add(new SqlParameter("@fromDate", fromDate));
                parameters.Add(new SqlParameter("@toDate", endDate));

                var dataSet = Common.ExecuteStoredProcedure(objectContext, "PROC_Report", parameters);
                return dataSet;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new DataSet();
            }
        }

        public PagingModel<UserModel> GetAllData(UserModel userModel)
        {
            try
            {
                var model = new PagingModel<UserModel>();
                using (var conn = _dbContext.Database.Connection)
                {
                    conn.Open();
                    var cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "[dbo].[PROC_Report_Data_For_Web]";

                    var username = cmd.CreateParameter();
                    username.Direction = ParameterDirection.Input;
                    username.DbType = DbType.String;
                    username.ParameterName = "@username";
                    username.Value = userModel.Username;
                    cmd.Parameters.Add(username);

                    var fromDate = cmd.CreateParameter();
                    fromDate.Direction = ParameterDirection.Input;
                    fromDate.DbType = DbType.Date;
                    fromDate.ParameterName = "@fromDate";
                    fromDate.Value = userModel.fromDate;
                    cmd.Parameters.Add(fromDate);

                    var endDate = cmd.CreateParameter();
                    endDate.Direction = ParameterDirection.Input;
                    endDate.DbType = DbType.Date;
                    endDate.ParameterName = "@toDate";
                    endDate.Value = userModel.endDate;
                    cmd.Parameters.Add(endDate);

                    var pageIndex = cmd.CreateParameter();
                    pageIndex.Direction = ParameterDirection.Input;
                    pageIndex.DbType = DbType.Int32;
                    pageIndex.ParameterName = "@pageIndex";
                    pageIndex.Value = userModel.current;
                    cmd.Parameters.Add(pageIndex);

                    var pageSize = cmd.CreateParameter();
                    pageSize.Direction = ParameterDirection.Input;
                    pageSize.DbType = DbType.Int32;
                    pageSize.ParameterName = "@pagesize";
                    pageSize.Value = userModel.pageSize;
                    cmd.Parameters.Add(pageSize);

                    var reader = cmd.ExecuteReader();
                    model.data = ((IObjectContextAdapter)_dbContext)
                        .ObjectContext
                        .Translate<UserModel>(reader).ToList();
                    reader.NextResult();
                    model.total = ((IObjectContextAdapter)_dbContext)
                        .ObjectContext
                        .Translate<int>(reader).FirstOrDefault();

                    model.page = userModel.current;
                    model.success = true;
                    conn.Close();
                }
                return model;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new PagingModel<UserModel>();
            }
        }

        public PagingModel<UserReportCreated> GetUserUnder(ReportUserModel userModel)
        {
            try { 
                var model = new PagingModel<UserReportCreated>();
                var parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userFilter", userModel.username));
                parameters.Add(new SqlParameter("@UserCreated", userModel.userCreated));
                parameters.Add(new SqlParameter("@Status", userModel.status));
                parameters.Add(new SqlParameter("@PageNumber", userModel.pageIndex));
                parameters.Add(new SqlParameter("@PageSize", userModel.pageSize));
                parameters.Add(new SqlParameter("@Type", userModel.type));
                parameters.Add(new SqlParameter("@FromDate", userModel.fromDate ?? (object)DBNull.Value));
                parameters.Add(new SqlParameter("@ToDate", userModel.toDate ?? (object)DBNull.Value));

                var totalUnder = new SqlParameter("@TotalUnder", SqlDbType.Int, 10);
                totalUnder.Direction = ParameterDirection.Output;
                parameters.Add(totalUnder);

                var total = new SqlParameter("@Total", SqlDbType.Int, 10);
                total.Direction = ParameterDirection.Output;
                parameters.Add(total);

                var sql = "exec PROC_GetUserUnder @userFilter, @UserCreated, @Status, @PageNumber, @PageSize, @Type, @FromDate, @ToDate, @TotalUnder OUT, @Total OUT";
                model.data = _dbContext.Database.SqlQuery<UserReportCreated>(sql, parameters.ToArray()).ToList();
                model.success = true;
                model.total = Convert.ToInt32(total.Value == DBNull.Value ? "0" : total.Value.ToString());
                model.totalUnder = Convert.ToInt32(totalUnder.Value == DBNull.Value ? "0" : totalUnder.Value.ToString());
                model.page = userModel.pageIndex;

                return model;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new PagingModel<UserReportCreated>();
            }
        }
    }
}
