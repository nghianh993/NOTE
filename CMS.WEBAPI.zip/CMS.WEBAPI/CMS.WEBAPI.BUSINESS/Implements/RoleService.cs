﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class RoleService : IRoleService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<RoleModel> GetAllRole(RoleModel roleModel)
        {
            try
            {
                PagingModel<RoleModel> model = new PagingModel<RoleModel>();
                var query = from c in _dbContext.Roles
                            where (string.IsNullOrEmpty(roleModel.RoleId) || c.RoleId.Contains(roleModel.RoleId))
                            && (string.IsNullOrEmpty(roleModel.RoleName) || c.RoleName.Contains(roleModel.RoleName))
                            && (roleModel.Status == null|| c.Status == roleModel.Status)
                            select c;
                
                model.total = query.Count();
                model.page = roleModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(roleModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.RoleId);

                model.data = query.Select(p => new RoleModel
                {
                    RoleId = p.RoleId,
                    RoleName = p.RoleName,
                    Status = p.Status,
                    Description = p.Description,
                    CreatedDate = p.CreatedDate,
                    UserCreate = p.UserCreate
                }).Skip((roleModel.current - 1) * roleModel.pageSize).Take(roleModel.pageSize).ToList();                

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<RoleModel>();
            }
        }

        public List<PermissionModel> GetFirstNodePermissionByRole(string roleId, string parentId)
        {
            try
            {
                var lstPermission = (from c in _dbContext.Permissions
                                     join p in _dbContext.RolePermissionMappings on c.PermistionId equals p.PermissionId into g
                                     from x in g.DefaultIfEmpty()
                                     where c.Status == (int)Status.ACTIVE
                                     && (string.IsNullOrEmpty(c.ParentId) || c.ParentId.Equals(parentId))
                                     select new PermissionModel()
                                     {
                                         PermistionId = c.PermistionId,
                                         Description = c.Description,
                                         Url = c.Url,
                                         Method = c.Method,
                                         IsCheck = string.IsNullOrEmpty(x.PermissionId) ? false : true
                                     }).ToList();
                return lstPermission;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<PermissionModel>();
            }
        }

        public ResponseModel AddRole(RoleModel roleModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var role = _dbContext.Roles.SingleOrDefault(c => c.RoleId.Equals(roleModel.RoleId));
                if (role != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var newRole = MapperHelper.Map<Role, RoleModel>(roleModel);
                    _dbContext.Roles.Add(newRole);
                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel UpdateRole(RoleModel roleModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var role = _dbContext.Roles.SingleOrDefault(c => c.RoleId.Equals(roleModel.RoleId));
                if (role == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    role.Description = roleModel.Description;
                    role.Status = role.Status;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteRole(string roleId)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var role = _dbContext.Roles.SingleOrDefault(c => c.RoleId.Equals(roleId));
                if (role == null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    role.Status = (int)Status.DELETE;
                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel AddOrRemovePermissionToRole(string permissionId, string roleId, string userCreate, bool isAdd)
        {
            var response = new ResponseModel();
            try
            {
                var rolePermissionMapping = _dbContext.RolePermissionMappings.Where(c => c.RoleId.Equals(roleId) && c.PermissionId.Equals(permissionId))
                    .Select(c => c).ToList();

                foreach (var item in rolePermissionMapping)
                {
                    _dbContext.RolePermissionMappings.Remove(item);
                }
                if (isAdd)
                {
                    var newItem = new RolePermissionMapping();
                    newItem.RoleId = roleId;
                    newItem.PermissionId = permissionId;
                    newItem.Usercreate = userCreate;
                    newItem.DateCreate = DateTime.Now;

                    _dbContext.RolePermissionMappings.Add(newItem);
                }
                _dbContext.SaveChanges();

                response.Message = Message.UPDATE_SUCCESS;
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                response.Success = true;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<MenuModel> GetMenuByUser(string userName)
        {
            try
            {
                var permissions = (from a in _dbContext.Roles
                                   join b in _dbContext.UserRoleMappings on a.RoleId equals b.RoleId
                                   join c in _dbContext.Users on b.Username equals c.Username
                                   join d in _dbContext.RolePermissionMappings on b.RoleId equals d.RoleId
                                   join e in _dbContext.Permissions on d.PermissionId equals e.PermistionId
                                   where c.Username.Equals(userName) && c.Status == (int)Status.ACTIVE 
                                   && e.Status == (int)Status.ACTIVE
                                   && a.Status == (int)Status.ACTIVE && (e.IsMenu ?? false)
                                   && string.IsNullOrEmpty(e.ParentId) 
                                   orderby e.Position ascending
                                   select new MenuModel()
                                   {
                                       key = e.PermistionId,
                                       path = e.Url,
                                       name = e.Description,
                                       icon = e.Icon,
                                       locale = false,
                                       authority = e.PermistionId,
                                       exact = true
                                   }).ToList();

                foreach (var item in permissions)
                {
                    GetMenuByUserAndParentId(item, userName, item.key);
                }
                return permissions;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<MenuModel>();
            }
        }

        private void GetMenuByUserAndParentId(MenuModel model, string userName, string parentId)
        {
            var permissions = (from a in _dbContext.Roles
                               join b in _dbContext.UserRoleMappings on a.RoleId equals b.RoleId
                               join c in _dbContext.Users on b.Username equals c.Username
                               join d in _dbContext.RolePermissionMappings on b.RoleId equals d.RoleId
                               join e in _dbContext.Permissions on d.PermissionId equals e.PermistionId
                               where c.Username.Equals(userName) && c.Status == (int)Status.ACTIVE
                               && e.Status == (int)Status.ACTIVE
                               && a.Status == (int)Status.ACTIVE && (e.IsMenu ?? false)
                               && e.ParentId.Equals(parentId)
                               select new MenuModel()
                               {
                                   key = e.PermistionId,
                                   path = e.Url,
                                   name = e.Description,
                                   icon = e.Icon,
                                   locale = false,
                                   authority = e.PermistionId,
                                   parentKeys = parentId,
                                   exact = true
                               }).ToList();
            //Get children menu
            foreach (var item in permissions)
            {
                GetMenuByUserAndParentId(item, userName, item.key);
            }
            model.children = permissions;
        }

        public List<PermissionModel> GetPermissionByUser(string userName)
        {
            try
            {
                var permissions = (from a in _dbContext.Roles
                                   join b in _dbContext.UserRoleMappings on a.RoleId equals b.RoleId
                                   join c in _dbContext.Users on b.Username equals c.Username
                                   join d in _dbContext.RolePermissionMappings on b.RoleId equals d.RoleId
                                   join e in _dbContext.Permissions on d.PermissionId equals e.PermistionId
                                   where c.Username.Equals(userName) && c.Status == (int)Status.ACTIVE
                                   && a.Status == (int)Status.ACTIVE
                                   select new PermissionModel()
                                   {
                                       PermistionId = e.PermistionId,
                                       Url = e.Url,
                                       Method = e.Method
                                   }).Distinct().ToList();

                return permissions;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<PermissionModel>();
            }
        }

        public ResponseModel LockOrUnlock(List<string> roleIds, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var roles = _dbContext.Roles.Where(c => roleIds.Contains(c.RoleId)).Select(c => c).ToList();
                if (roles != null && roles.Any())
                {
                    foreach (var item in roles)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public TreeRole GetDataTreeRole(string roleId)
        {
            var data = new TreeRole();
            try
            {
                var permissions = (from d in _dbContext.Permissions 
                                orderby d.Position ascending
                                select d).ToList();
                var firstNode = permissions.Where(c => string.IsNullOrEmpty(c.ParentId)).Select(c => new PermissionTreeModel()
                {
                    key = c.PermistionId,
                    title = c.Description,
                    children = GetChildrenPermission(c.PermistionId, permissions)
                }).ToList();

                data.treeData = firstNode;
                data.treeSelected = (from d in _dbContext.RolePermissionMappings
                                     join e in _dbContext.Permissions on d.PermissionId equals e.PermistionId
                                     where e.Status == (int)Status.ACTIVE && d.RoleId.Equals(roleId)
                                     select e.PermistionId).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return data;
            }
        }

        public ResponseModel UpdatePermission(List<string> permissionId, string roleId, string userCreate)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var roles = _dbContext.RolePermissionMappings.Where(c => c.RoleId.Equals(roleId)).ToList();
                foreach (var item in roles) { _dbContext.RolePermissionMappings.Remove(item); }
                _dbContext.SaveChanges();

                //Add new permission
                foreach (var item in permissionId)
                {
                    var rolePermissionMapping = new RolePermissionMapping() {
                        RoleId = roleId,
                        PermissionId = item,
                        Usercreate = userCreate,
                        DateCreate = DateTime.Now
                    };
                    _dbContext.RolePermissionMappings.Add(rolePermissionMapping);
                }
                _dbContext.SaveChanges();
                response.Success = true;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        #region Help Method
        private List<PermissionTreeModel> GetChildrenPermission(string parentId, List<Permission> permissions)
        {
            var lstChildren = permissions.Where(c => !string.IsNullOrEmpty(c.ParentId) && c.ParentId.Equals(parentId)).Select(c => new PermissionTreeModel()
            {
                key = c.PermistionId,
                title = c.Description,
                children = GetChildrenPermission(c.PermistionId, permissions)
            }).ToList();
            return lstChildren;
        }
        #endregion
    }
}
