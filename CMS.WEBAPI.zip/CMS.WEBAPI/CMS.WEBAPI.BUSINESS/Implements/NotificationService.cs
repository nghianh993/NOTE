﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.COMMON.Helper;
using CMS.WEBAPI.MODEL;
using Newtonsoft.Json.Linq;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class NotificationService : INotificationService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public int SaveNotification(string content, string userCreated, string userReceiver)
        {
            using(var _context = new BEDATAEntities())
            {
                var notification = new Notification();
                notification.Message = content;
                notification.DateCreate = DateTime.Now;
                notification.Usercreate = userCreated;
                notification.UserReceived = userReceiver;
                //Trạng thái 1 chưa đọc
                notification.Type = (int)Status.ACTIVE;
                _context.Notifications.Add(notification);
                _context.SaveChanges();

                return notification.MessageId;
            }
        }

        public void UpdateRead(List<int> messageId)
        {
            if (messageId != null)
            {
                using (var _context = new BEDATAEntities())
                {
                    var lstMessage = _context.Notifications.Where(c => messageId.Contains(c.MessageId)).Select(c => c).ToList();
                    foreach (var item in lstMessage)
                    {
                        item.Type = (int)Status.NOT_ACTIVE;
                    }
                    _context.SaveChanges();
                }
            }
        }

        public PagingModel<NoticeModel> GetAll(NoticeModel model)
        {
            try
            {
                var data = new PagingModel<NoticeModel>();
                var query = from c in _dbContext.Notifications
                            where c.UserReceived.Equals(model.UserReceived)
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                data.data = query.OrderByDescending(p => p.MessageId).Select(p => new NoticeModel
                {
                    MessageId = p.MessageId,
                    Message = p.Message,
                    DateCreate = p.DateCreate,
                    ModifyDate = p.ModifyDate,
                    Status = p.Type == 1 ? "Chưa đọc" : "Đã đọc"
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<NoticeModel>();
            }
        }

        public void PushNotification(string content, string userSend, string userReceiver)
        {
            //Save data
            var messageId = new NotificationService().SaveNotification(content, userSend, userReceiver);

            //Push notification
            var request = WebRequest.Create(WebUtils.GetAppSettingsConfigValue(WebConstant.URL_NOTIFICATIONS)) as HttpWebRequest;

            request.KeepAlive = true;
            request.Method = "POST";
            request.ContentType = "application/json; charset=utf-8";
            request.Headers.Add("authorization", "Basic " + WebUtils.GetAppSettingsConfigValue(WebConstant.SECRET_KEY));

            var serializer = new JavaScriptSerializer();
            var obj = new
            {
                app_id = WebUtils.GetAppSettingsConfigValue(WebConstant.APP_ID),
                contents = new { en = content },
                filters = new object[] { new { field = "tag", key = "user", relation = "=", value = userReceiver } },
                data = new { messageId }
            };
            var param = serializer.Serialize(obj);
            byte[] byteArray = Encoding.UTF8.GetBytes(param);

            JObject objResult = new JObject();

            try
            {
                using (var writer = request.GetRequestStream())
                {
                    writer.Write(byteArray, 0, byteArray.Length);
                }

                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {

                        JObject Jobject = JObject.Parse(reader.ReadToEnd());

                        objResult.Add("status", NUMARATOR.SUCCESS.ToString());
                        objResult.Add("id", Jobject.GetValue("id"));
                        objResult.Add("recipients", Jobject.GetValue("recipients"));
                    }
                }

            }
            catch (WebException ex)
            {
                logger.Error(ex);
            }
        }

        /// <summary>
        /// Đẩy thông báo cho tất cả user
        /// </summary>
        /// <param name="content"></param>
        /// <param name="userSend"></param>
        public void PushNotifications(string content, string userSend, string segment)
        {
            //Save data
            var messageId = new NotificationService().SaveNotification(content, userSend, segment);

            //Push notification
            var request = WebRequest.Create(WebUtils.GetAppSettingsConfigValue(WebConstant.URL_NOTIFICATIONS)) as HttpWebRequest;

            request.KeepAlive = true;
            request.Method = "POST";
            request.ContentType = "application/json; charset=utf-8";
            request.Headers.Add("authorization", "Basic " + WebUtils.GetAppSettingsConfigValue(WebConstant.SECRET_KEY));

            var serializer = new JavaScriptSerializer();
            var obj = new
            {
                app_id = WebUtils.GetAppSettingsConfigValue(WebConstant.APP_ID),
                contents = new { en = content },
                included_segments = new object[] { segment },
                data = new { messageId }
            };
            var param = serializer.Serialize(obj);
            byte[] byteArray = Encoding.UTF8.GetBytes(param);

            JObject objResult = new JObject();

            try
            {
                using (var writer = request.GetRequestStream())
                {
                    writer.Write(byteArray, 0, byteArray.Length);
                }

                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {

                        JObject Jobject = JObject.Parse(reader.ReadToEnd());

                        objResult.Add("status", NUMARATOR.SUCCESS.ToString());
                        objResult.Add("id", Jobject.GetValue("id"));
                        objResult.Add("recipients", Jobject.GetValue("recipients"));
                    }
                }

            }
            catch (WebException ex)
            {
                logger.Error(ex);
            }
        }
    }
}
