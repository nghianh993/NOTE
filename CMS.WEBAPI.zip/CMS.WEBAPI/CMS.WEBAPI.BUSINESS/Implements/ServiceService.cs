﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class ServiceService : IServiceService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<ServiceModel> GetAll(ServiceModel model)
        {
            try
            {
                var data = new PagingModel<ServiceModel>();
                var query = from c in _dbContext.Services
                            where (string.IsNullOrEmpty(model.ServiceCode) || c.ServiceCode.Contains(model.ServiceCode))
                            && (string.IsNullOrEmpty(model.ServiceName) || c.ServiceName.Contains(model.ServiceName))
                            && (model.Type == null || c.Type == model.Type)
                            && (model.Status == null || c.Status == model.Status)
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.ServiceCode);

                data.data = query.Select(p => new ServiceModel
                {
                    ServiceCode = p.ServiceCode,
                    ServiceName = p.ServiceName,
                    CreateDate = p.CreateDate,
                    Type = p.Type,
                    Status = p.Status,
                    Training = p.Training,
                    Price = p.Price,
                    UserCreated = p.UserCreated

                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<ServiceModel>();
            }
        }

        public ResponseModel Add(ServiceModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var service = _dbContext.Services.SingleOrDefault(c => c.ServiceCode.Equals(model.ServiceCode));
                if (service != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    var newService = MapperHelper.Map<Service, ServiceModel>(model);
                    newService.CreateDate = DateTime.Now;
                    newService.Status = (int)Status.ACTIVE;
                    _dbContext.Services.Add(newService);
                    _dbContext.SaveChanges();

                    response.Success = true;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(ServiceModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var service = _dbContext.Services.SingleOrDefault(c => c.ServiceCode.Equals(model.ServiceCode));
                if (service == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    var check = _dbContext.Services.SingleOrDefault(c => !c.ServiceCode.Equals(model.ServiceCode) && c.ServiceName.Equals(model.ServiceName));
                    if (check != null)
                    {
                        response.Success = false;
                        response.Message = Message.ADD_EXISTS;
                    }
                    else
                    {
                        response.Success = true;
                        service.ServiceName = model.ServiceName;
                        service.Type = model.Type;
                        service.Price = model.Price;
                        service.Training = model.Training;
                        _dbContext.SaveChanges();
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel LockOrUnlock(List<string> ids, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var cates = _dbContext.Services.Where(c => ids.Contains(c.ServiceCode)).Select(c => c).ToList();
                if (cates != null && cates.Any())
                {
                    foreach (var item in cates)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<SelectCommonModel> GetAllByType(int type)
        {
            try
            {
                var lstData = (from c in _dbContext.Services
                               where (c.Type == type) && c.Status == (int)Status.ACTIVE 
                               select new SelectCommonModel()
                               {
                                   value = c.ServiceCode,
                                   label = c.ServiceName
                               }).ToList();
                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<SelectCommonModel>();
            }
        }

        public List<ServiceModel> GetAllByTypeV2(int type)
        {
            try
            {
                var lstData = (from c in _dbContext.Services
                               where (c.Type == type) && c.Status == (int)Status.ACTIVE
                               select new ServiceModel()
                               {
                                   ServiceCode = c.ServiceCode,
                                   ServiceName = c.ServiceName,
                                   CreateDate = c.CreateDate,
                                   Type = c.Type,
                                   Price = c.Price,
                                   UserCreated = c.UserCreated
                               }).ToList();
                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<ServiceModel>();
            }
        }
    }
}
