﻿using AutoMapper;
using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.COMMON.Helper;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class LoginService : ILoginService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public UserModel GetCurrentUser(string account, string password)
        {
            try
            {
                var user = _dbContext.Users.SingleOrDefault(c => c.Username.Equals(account));
                if (user == null) return null;
                if (!PasswordHelper.VerifyPassword(account, password, user.Password)) return null;

                return MapperHelper.Map<UserModel, User>(user);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new UserModel();
            }
        }

        public List<PermissionModel> GetPermissionsByUser(string account)
        {
            try
            {
                var permissions = (from a in _dbContext.Roles
                                    join b in _dbContext.UserRoleMappings on a.RoleId equals b.RoleId
                                    join c in _dbContext.Users on b.Username equals c.Username
                                    join d in _dbContext.RolePermissionMappings on b.RoleId equals d.RoleId
                                    join e in _dbContext.Permissions on d.PermissionId equals e.PermistionId
                                    where c.Username.Equals(account) && c.Status == (int)Status.ACTIVE
                                    && a.Status == (int)Status.ACTIVE
                                    select e).ToList();
                return MapperHelper.Map<List<PermissionModel >, List <Permission>>(permissions);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<PermissionModel>();
            }
        }
    }
}
