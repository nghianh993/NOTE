﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class ExamQuestionMappingService : IExamQuestionMappingService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public ResponseModel CreateExamQuestionMappings(List<int> listQuestionIds, int examId)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                foreach(var item in listQuestionIds)
                {
                    var examQuestionItem = _dbContext.ExamQuestionMappings.SingleOrDefault(c => c.QuestionId.Equals(item) && c.ExamId.Equals(examId));
                    if(examQuestionItem == null)
                    {
                        
                        var newExamQuestionMapping = new ExamQuestionMapping()
                        {
                            ExamId = examId,
                            QuestionId = item,
                            CreateDate = DateTime.Now
                        };

                        _dbContext.ExamQuestionMappings.Add(newExamQuestionMapping);
                    }
                }
                _dbContext.SaveChanges();
                response.Success = true;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteExamQuestionMappings(List<int> listQuestionIds, int examId)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                foreach (var item in listQuestionIds)
                {
                    var examItem = _dbContext.ExamQuestionMappings.FirstOrDefault(x => x.ExamId.Equals(examId) && x.QuestionId.Equals(item));
                    _dbContext.ExamQuestionMappings.Remove(examItem);
                    
                }
                _dbContext.SaveChanges();
                response.Success = true;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
    }
}
