﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.COMMON.Helper;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{

    public class ClassService : IClassService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public ClassResponseModel CreateClass(ClassModel classModel)
        {
            var response = new ClassResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var classItemExist = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(classModel.ClassCode) && c.Status != (int)Status.DELETE);
                if (classItemExist != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var classItem = MapperHelper.Map<Class, ClassModel>(classModel);
                    _dbContext.Classes.Add(classItem);
                    _dbContext.SaveChanges();

                    response.Data = classItem;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
        public ResponseModel UpdateClass(ClassModel classModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var classItem = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(classModel.ClassCode) && c.Status != (int)Status.DELETE);
                if (classItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    classItem.ClassName = classModel.ClassName;
                    classItem.Avatar = classModel.Avatar;
                    classItem.BeginDate = classModel.BeginDate;
                    classItem.EndDate = classModel.EndDate;
                    classItem.MaxTotalStudent = classModel.MaxTotalStudent;
                    classItem.ModifyDate = DateTime.Now;
                    classItem.MaxDayOff = classModel.MaxDayOff;
                    classItem.CourseId = classModel.CourseId ?? 0;
                    classItem.TimeTable = classModel.TimeTable;
                    classItem.Services = classModel.Services;
                    classItem.NumberLesson = classModel.NumberLesson;
                    classItem.ClassLevel = classModel.ClassLevel;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteClass(ClassModel classModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var classItem = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(classModel.ClassCode) && c.Status != (int)Status.DELETE);
                if (classItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    classItem.Status = classModel.Status;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ClassModel GetClassByClassCode(string classCode)
        {
            try
            {
                var classItem = _dbContext.Classes.SingleOrDefault(c => c.ClassCode.Equals(classCode) && c.Status != (int)Status.DELETE);
                if (classItem == null) return new ClassModel();

                return MapperHelper.Map<ClassModel, Class>(classItem);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new ClassModel();
            }
        }

        public PagingModel<ClassModel> GetListClasses(ClassModel classModel)
        {
            try
            {
                var model = new PagingModel<ClassModel>();
                var query = _dbContext.Classes
                    .Where(x => (string.IsNullOrEmpty(classModel.ClassName) || x.ClassName.Contains(classModel.ClassName))
                    && (string.IsNullOrEmpty(classModel.ClassCode) || x.ClassCode.Contains(classModel.ClassCode))
                    && (string.IsNullOrEmpty(classModel.ClassLevel) || x.ClassCode.Contains(classModel.ClassLevel))
                    && (classModel.CourseId == null || x.CourseId == classModel.CourseId)
                    && (classModel.Status == null || x.Status == classModel.Status)
                    && x.Status != (int)Status.DELETE);

                model.total = query.Count();
                model.page = classModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(classModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.ClassCode);

                model.data = query.Select(x => new ClassModel
                {
                    Avatar = x.Avatar,
                    BeginDate = x.BeginDate,
                    ClassCode = x.ClassCode,
                    ClassName = x.ClassName,
                    CreateDate = x.CreateDate,
                    EndDate = x.EndDate,
                    MaxTotalStudent = x.MaxTotalStudent,
                    ModifyDate = x.ModifyDate,
                    Status = x.Status,
                    UserCreate = x.UserCreate,
                    CourseId = x.CourseId,
                    TimeTable = x.TimeTable,
                    MaxDayOff = x.MaxDayOff,
                    Services = x.Services,
                    ClassLevel = x.ClassLevel,
                    TotalCurrentStudent = x.TotalCurrentStudent ?? 0,
                    NumberLesson = x.NumberLesson ?? 0
                }).Skip((classModel.current - 1) * classModel.pageSize).Take(classModel.pageSize).ToList();

                model.data = model.data.Select(x => new ClassModel
                {
                    Avatar = x.Avatar,
                    BeginDate = x.BeginDate,
                    ClassCode = x.ClassCode,
                    ClassName = x.ClassName,
                    CreateDate = x.CreateDate,
                    EndDate = x.EndDate,
                    MaxTotalStudent = x.MaxTotalStudent,
                    ModifyDate = x.ModifyDate,
                    Status = x.Status,
                    UserCreate = x.UserCreate,
                    CourseId = x.CourseId,
                    TimeTable = x.TimeTable,
                    MaxDayOff = x.MaxDayOff,
                    Services = x.Services,
                    ClassLevel = x.ClassLevel,
                    TotalCurrentStudent = x.TotalCurrentStudent,
                    NumberLesson = x.NumberLesson,
                    Total = GetTotalStudentInClass(x.ClassCode)
                }).ToList();

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<ClassModel>();
            }
        }
        public List<SelectIntCommonModel> GetAllCourse()
        {
            try
            {
                var lstData = (from c in _dbContext.Courses
                               where c.Status == (int)Status.ACTIVE
                               select new SelectIntCommonModel()
                               {
                                   value = c.Id,
                                   label = c.Name
                               }).ToList();
                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<SelectIntCommonModel>();
            }
        }

        public PagingModel<ClassModel> GetListClassesByUserServices(ClassModel classModel)
        {
            var model = new PagingModel<ClassModel>();
            try
            {
                var service = string.IsNullOrEmpty(classModel.Services) ? new List<string>() : classModel.Services.Split(',').ToList();
                var query = from x in _dbContext.Classes
                            //join s in _dbContext.StudentClasses on x.ClassCode equals s.ClassId into user
                            //from studentClass in user.DefaultIfEmpty()
                            where x.Status == (int)Status.ACTIVE
                            && (x.TotalCurrentStudent == null || x.TotalCurrentStudent < x.MaxTotalStudent)
                            && (!service.Any() || service.Any(c => x.Services.Contains(c)))
                            && (string.IsNullOrEmpty(classModel.ClassName) || x.ClassName.Contains(classModel.ClassName))
                            && (string.IsNullOrEmpty(classModel.ClassCode) || x.ClassCode.Contains(classModel.ClassCode))
                            && (string.IsNullOrEmpty(classModel.ClassLevel) || x.ClassCode.Contains(classModel.ClassLevel))
                            && (classModel.CourseId == null || x.CourseId == classModel.CourseId)
                            select x;

                model.total = query.Count();
                model.page = classModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(classModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.ClassCode);
                model.data = query.Select(x => new ClassModel
                {
                    Avatar = x.Avatar,
                    BeginDate = x.BeginDate,
                    ClassCode = x.ClassCode,
                    ClassName = x.ClassName,
                    CreateDate = x.CreateDate,
                    EndDate = x.EndDate,
                    MaxTotalStudent = x.MaxTotalStudent,
                    ModifyDate = x.ModifyDate,
                    Status = x.Status,
                    UserCreate = x.UserCreate,
                    CourseId = x.CourseId,
                    TimeTable = x.TimeTable,
                    MaxDayOff = x.MaxDayOff,
                    Services = x.Services,
                    ClassLevel = x.ClassLevel,
                    TotalCurrentStudent = x.TotalCurrentStudent ?? 0,
                    NumberLesson = x.NumberLesson ?? 0

                }).Skip((classModel.current - 1) * classModel.pageSize).Take(classModel.pageSize).ToList();

                model.data = model.data.Select(x => new ClassModel
                {
                    Avatar = x.Avatar,
                    BeginDate = x.BeginDate,
                    ClassCode = x.ClassCode,
                    ClassName = x.ClassName,
                    CreateDate = x.CreateDate,
                    EndDate = x.EndDate,
                    MaxTotalStudent = x.MaxTotalStudent,
                    ModifyDate = x.ModifyDate,
                    Status = x.Status,
                    UserCreate = x.UserCreate,
                    CourseId = x.CourseId,
                    TimeTable = x.TimeTable,
                    MaxDayOff = x.MaxDayOff,
                    Services = x.Services,
                    ClassLevel = x.ClassLevel,
                    TotalCurrentStudent = x.TotalCurrentStudent,
                    NumberLesson = x.NumberLesson,
                    Total = GetTotalStudentInClass(x.ClassCode)
                }).ToList();
                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return model;
            }
        }
        public PagingModel<ClassModel> GetListClassesNoTeacher(ClassModel classModel)
        {
            var model = new PagingModel<ClassModel>();
            try
            {
                var query = from x in _dbContext.Classes
                            join s in _dbContext.TeacherClasses on x.ClassCode equals s.ClassCode into user
                            from teacherClass in user.DefaultIfEmpty()
                            where x.Status == (int)Status.ACTIVE && (classModel.IsArrange != null ? teacherClass.Username.Equals(classModel.UserName) : string.IsNullOrEmpty(teacherClass.Username))
                            && (string.IsNullOrEmpty(classModel.ClassName) || x.ClassName.Contains(classModel.ClassName))
                            && (string.IsNullOrEmpty(classModel.ClassCode) || x.ClassCode.Contains(classModel.ClassCode))
                            && (string.IsNullOrEmpty(classModel.ClassLevel) || x.ClassCode.Contains(classModel.ClassLevel))
                            && (classModel.CourseId == null || x.CourseId == classModel.CourseId)
                            select x;

                model.total = query.Count();
                model.page = classModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(classModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.ClassCode);
                model.data = query.Select(x => new ClassModel
                {
                    Avatar = x.Avatar,
                    BeginDate = x.BeginDate,
                    ClassCode = x.ClassCode,
                    ClassName = x.ClassName,
                    CreateDate = x.CreateDate,
                    EndDate = x.EndDate,
                    MaxTotalStudent = x.MaxTotalStudent,
                    ModifyDate = x.ModifyDate,
                    Status = x.Status,
                    UserCreate = x.UserCreate,
                    CourseId = x.CourseId,
                    TimeTable = x.TimeTable,
                    MaxDayOff = x.MaxDayOff,
                    Services = x.Services,
                    ClassLevel = x.ClassLevel,
                    TotalCurrentStudent = x.TotalCurrentStudent ?? 0,
                    NumberLesson = x.NumberLesson ?? 0

                }).Skip((classModel.current - 1) * classModel.pageSize).Take(classModel.pageSize).ToList();

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return model;
            }
        }

        // get total student in class
                
        private int GetTotalStudentInClass(string classCode)
        {
            try
            {
                var totalStudent = _dbContext.StudentClasses.Where(c => c.ClassId.Equals(classCode) && c.Status != (int)Status.DELETE).Count();
                return totalStudent;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return 0;
            }

        }
    }
}
