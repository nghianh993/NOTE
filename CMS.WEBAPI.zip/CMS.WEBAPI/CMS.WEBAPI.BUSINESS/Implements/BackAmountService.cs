﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class BackAmountService : IBackAmountService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<BackAmountModel> GetAll(BackAmountModel model)
        {
            try
            {
                var data = new PagingModel<BackAmountModel>();
                var query = from c in _dbContext.BackAmounts
                            where (string.IsNullOrEmpty(model.Code) || c.Code.Contains(model.Code))
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Code);

                data.data = query.Select(p => new BackAmountModel
                {
                    Code = p.Code,
                    BackAmount1 = p.BackAmount1,
                    CreateDate = p.CreateDate,
                    CreateBy = p.CreateBy
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<BackAmountModel>();
            }
        }

        public ResponseModel Add(BackAmountModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var service = _dbContext.BackAmounts.SingleOrDefault(c => c.Code.Equals(model.Code));
                if (service != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    var newService = MapperHelper.Map<BackAmount, BackAmountModel>(model);
                    newService.CreateDate = DateTime.Now;
                    _dbContext.BackAmounts.Add(newService);
                    _dbContext.SaveChanges();

                    response.Success = true;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(BackAmountModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var service = _dbContext.BackAmounts.SingleOrDefault(c => c.Code.Equals(model.Code));
                if (service == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    service.BackAmount1 = model.BackAmount1;
                    _dbContext.SaveChanges();
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Delete(List<string> ids)
        {
            var response = new ResponseModel();
            try
            {
                var lstData = _dbContext.BackAmounts.Where(c => ids.Contains(c.Code)).Select(c => c).ToList();
                if (lstData == null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    foreach (var item in lstData)
                    {
                        _dbContext.BackAmounts.Remove(item);
                    }
                    _dbContext.SaveChanges();
                }
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
    }
}
