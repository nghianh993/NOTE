﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.COMMON.Helper;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class QuestionCateService : IQuestionCateService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<CateQuestionModel> GetAll(CateQuestionModel model)
        {
            try
            {
                var data = new PagingModel<CateQuestionModel>();
                var query = from c in _dbContext.QuestionCates
                            where (string.IsNullOrEmpty(model.Name) || c.Name.Contains(model.Name))
                            && (model.Status == null || c.Status == model.Status)
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Name);

                data.data = query.Select(p => new CateQuestionModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description,
                    Status = p.Status,
                    DateCreated = p.DateCreated,
                    UserCreated = p.UserCreated,
                    ParentId = p.ParentId
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<CateQuestionModel>();
            }
        }
        public ResponseModel Add(CateQuestionModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var user = _dbContext.QuestionCates.SingleOrDefault(c => c.Name.Equals(model.Name));
                if (user != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    var cate = MapperHelper.Map<QuestionCate, CateQuestionModel>(model);
                    cate.DateCreated = DateTime.Now;
                    cate.Status = (int)Status.ACTIVE;
                    _dbContext.QuestionCates.Add(cate);
                    _dbContext.SaveChanges();

                    response.Success = true;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(CateQuestionModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var cate = _dbContext.QuestionCates.SingleOrDefault(c => c.Id.Equals(model.Id));
                if (cate == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    var check = _dbContext.QuestionCates.SingleOrDefault(c => !c.Id.Equals(model.Id) && c.Name.Equals(model.Name));
                    if (check != null)
                    {
                        response.Success = false;
                        response.Message = Message.ADD_EXISTS;
                    }
                    else
                    {
                        response.Success = true;
                        cate.Name = model.Name;
                        cate.Description = model.Description;
                        cate.ParentId = model.ParentId;
                        cate.ModifyDate = DateTime.Now;
                        _dbContext.SaveChanges();
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel LockOrUnlock(List<int> ids, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var cates = _dbContext.QuestionCates.Where(c => ids.Contains(c.Id)).Select(c => c).ToList();
                if (cates != null && cates.Any())
                {
                    foreach (var item in cates)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<SelectCommonModel> GetAll()
        {
            try
            {
                var data = (from c in _dbContext.QuestionCates
                            where c.Status == (int)Status.ACTIVE
                            select c).ToList();
                var lstData = data.Select(c => new SelectCommonModel()
                {
                    label = c.Name,
                    value = c.Id.ToString()
                }).ToList();
                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<SelectCommonModel>();
            }
        }
    }
}
