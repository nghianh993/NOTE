﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class AnswerService : IAnswerService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<AnswerModel> GetAnswerByQuestionId(AnswerModel model)
        {
            try
            {
                var data = new PagingModel<AnswerModel>();
                var query = from c in _dbContext.Answers
                            where c.QuestionId == model.QuestionId
                            select c;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.AnswerId);

                data.data = query.Select(p => new AnswerModel
                {
                    AnswerId = p.AnswerId,
                    AnswerName = p.AnswerName,
                    AnswerType = p.AnswerType,
                    IsRightAnswer = p.IsRightAnswer,
                    Status = p.Status,
                    CreateDate = p.CreateDate,
                    UserCreate = p.UserCreate
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<AnswerModel>();
            }
        }

        public ResponseModel Add(AnswerModel model)
        {
            var response = new ResponseModel();
            try
            {
                
                var data = MapperHelper.Map<Answer, AnswerModel>(model);
                data.CreateDate = DateTime.Now;
                data.Status = (int)Status.ACTIVE;
                _dbContext.Answers.Add(data);
                _dbContext.SaveChanges();

                response.Success = true;
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(AnswerModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var data = _dbContext.Answers.SingleOrDefault(c => c.AnswerId.Equals(model.AnswerId));
                if (data == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    var check = _dbContext.Answers.SingleOrDefault(c => !c.AnswerId.Equals(model.AnswerId) && c.AnswerName.Equals(model.AnswerName));
                    if (check != null)
                    {
                        response.Success = false;
                        response.Message = Message.ADD_EXISTS;
                    }
                    else
                    {
                        response.Success = true;
                        data.AnswerName = model.AnswerName;
                        data.IsRightAnswer = model.IsRightAnswer;
                        data.AnswerType = model.AnswerType;
                        
                        data.ModifyDate = DateTime.Now;
                        _dbContext.SaveChanges();
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Delete(int answerId)
        {
            var response = new ResponseModel();
            try
            {
                var answer = _dbContext.Answers.Where(c => c.AnswerId == answerId).Select(c => c).FirstOrDefault();
                if (answer == null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    _dbContext.Answers.Remove(answer);
                    _dbContext.SaveChanges();
                }
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
    }
}
