﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class QuestionService : IQuestionService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public PagingModel<QuestionModel> GetAll(QuestionModel model)
        {
            try
            {
                var data = new PagingModel<QuestionModel>();
                var query = from c in _dbContext.Questions
                            join b in _dbContext.Levels on c.Level equals b.LevelCode
                            join a in _dbContext.Answers on c.QuestionId equals a.QuestionId into subs
                            from sub in subs.DefaultIfEmpty()
                            where (string.IsNullOrEmpty(model.QuestionName) || c.QuestionName.Contains(model.QuestionName))
                            && (model.Status == null || c.Status == model.Status)
                            && (sub.Status == (int)Status.ACTIVE || sub.Status == null)
                            && (model.CateId == null || c.CateId == model.CateId)
                            group sub by new { c.QuestionId, c.QuestionName, c.Status, c.CateId, c.CreateDate, c.UserCreate, b.LevelCode, b.LevelName } into gr
                            select gr;

                data.total = query.Count();
                data.page = model.current;
                data.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(model.sorter, ref column, ref sortDes);
                if (column.Equals("QuestionName"))
                {
                    query = sortDes ? query.OrderByDescending(c => c.Key.QuestionName) : query.OrderBy(c => c.Key.QuestionName);
                }
                else if (column.Equals("Level"))
                {
                    query = sortDes ? query.OrderByDescending(c => c.Key.LevelName) : query.OrderBy(c => c.Key.LevelName);
                }
                else if (column.Equals("CreateDate"))
                {
                    query = sortDes ? query.OrderByDescending(c => c.Key.CreateDate) : query.OrderBy(c => c.Key.CreateDate);
                } else
                {
                    query = query.OrderByDescending(c => c.Key.CreateDate);
                }

                data.data = query.Select(p => new QuestionModel
                {
                    QuestionId = p.Key.QuestionId,
                    QuestionName = p.Key.QuestionName,
                    Status = p.Key.Status,
                    Level = p.Key.LevelCode,
                    LevelName = p.Key.LevelName,
                    CateId = p.Key.CateId,
                    CreateDate = p.Key.CreateDate,
                    UserCreate = p.Key.UserCreate,
                    TotalAnswer = p.Count(x => x != null)
                }).Skip((model.current - 1) * model.pageSize).Take(model.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<QuestionModel>();
            }
        }
        public ResponseModel Add(QuestionModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var data = _dbContext.Questions.SingleOrDefault(c => c.QuestionName.Equals(model.QuestionName));
                if (data != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    var cate = MapperHelper.Map<Question, QuestionModel>(model);
                    cate.CreateDate = DateTime.Now;
                    cate.Status = (int)Status.ACTIVE;
                    _dbContext.Questions.Add(cate);
                    _dbContext.SaveChanges();

                    response.Success = true;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel Update(QuestionModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var data = _dbContext.Questions.SingleOrDefault(c => c.QuestionId.Equals(model.QuestionId));
                if (data == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    var check = _dbContext.Questions.SingleOrDefault(c => !c.QuestionId.Equals(model.QuestionId) && c.QuestionName.Equals(model.QuestionName));
                    if (check != null)
                    {
                        response.Success = false;
                        response.Message = Message.ADD_EXISTS;
                    }
                    else
                    {
                        response.Success = true;
                        data.QuestionName = model.QuestionName;
                        data.CateId = model.CateId;
                        data.Level = model.Level;
                        data.ModifyDate = DateTime.Now;
                        _dbContext.SaveChanges();
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel LockOrUnlock(List<int> ids, int status)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var datas = _dbContext.Questions.Where(c => ids.Contains(c.QuestionId)).Select(c => c).ToList();
                if (datas != null && datas.Any())
                {
                    foreach (var item in datas)
                    {
                        item.Status = status;
                    }
                    _dbContext.SaveChanges();
                    response.Success = true;
                }
                else
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public Tree GetAllQuestionCate()
        {
            try
            {
                var lstTree = _dbContext.QuestionCates.Where(c => c.Status == (int)Status.ACTIVE && c.ParentId == 0)
                    .Select(c => c).ToList();

                var lstData = lstTree.Select(c => new TreeModel()
                {
                    key = c.Id.ToString(),
                    title = c.Name,
                    children = GetChildrenCate(c.Id)
                }).ToList();
                var tree = new Tree();
                tree.treeData = lstData;
                tree.treeSelected = tree.treeData.Select(c => c.key.ToString()).ToList();
                return tree;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new Tree();
            }
        }
        public PagingModel<QuestionModel> GetAllQuestionByExamId(QuestionModel questionModel)
        {

            try
            {
                var data = new PagingModel<QuestionModel>();
                var query = from c in _dbContext.ExamQuestionMappings
                            join a in _dbContext.Questions on c.QuestionId equals a.QuestionId into subs
                            from sub in subs.DefaultIfEmpty()
                            where (sub.Status == (int)Status.ACTIVE || sub.Status == null)
                            && c.ExamId == questionModel.Examid
                            select sub;

                data.total = query.Count();
                data.page = questionModel.current;
                data.success = true;

                //Sorting
                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(questionModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.QuestionName);

                data.data = query.Select(p => new QuestionModel
                {
                    QuestionId = p.QuestionId,
                    QuestionName = p.QuestionName,
                    Status = p.Status,
                    Level = p.Level,
                    CateId = p.CateId,
                    CreateDate = p.CreateDate,
                    UserCreate = p.UserCreate
                }).Skip((questionModel.current - 1) * questionModel.pageSize).Take(questionModel.pageSize).ToList();

                return data;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<QuestionModel>();
            }
        }

        public List<BaseObjectModel> GetAllLevel()
        {
            try
            {
                var lstData = _dbContext.Levels.Select(c => new BaseObjectModel()
                {
                    value = c.LevelCode,
                    label = c.LevelName
                }).ToList();

                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new List<BaseObjectModel>();
            }
        }

        #region Help method
        private List<TreeModel> GetChildrenCate(int cateId)
        {
            try
            {
                var lstTree = _dbContext.QuestionCates.Where(c => c.Status == (int)Status.ACTIVE && c.ParentId == cateId)
                    .Select(c => c).ToList();
                var lstData = lstTree.Select(c => new TreeModel() {
                    key = c.Id.ToString(),
                    title = c.Name,
                    children = GetChildrenCate(c.Id)
                }).ToList();

                return lstData;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return null;
            }
        }
        #endregion
    }
}
