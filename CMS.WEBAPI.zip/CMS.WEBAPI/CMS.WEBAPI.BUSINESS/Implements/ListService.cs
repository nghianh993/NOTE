﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class ListService : IListService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        public void CreateList(ListModel listModel)
        {
            try
            {
                var listItem = MapperHelper.Map<List, ListModel>(listModel);
                listItem.DateCreate = DateTime.Now;
                _dbContext.Lists.Add(listItem);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public void DeleteList(int id)
        {
            try
            {
                var listItem = _dbContext.Lists.FirstOrDefault(x => x.Id.Equals(id));
                _dbContext.Lists.Remove(listItem);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public ListModel GetListById(int id)
        {
            try
            {
                var listItem = _dbContext.Lists.SingleOrDefault(c => c.Id.Equals(id));
                if (listItem == null) return new ListModel();

                return MapperHelper.Map<ListModel, List>(listItem);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new ListModel();
            }
        }

        public List<ListModel> GetLists()
        {
            try
            {
                var lists = _dbContext.Lists.Select(x => new ListModel()
                {
                   Id = x.Id,
                   ListCode = x.ListCode,
                   ListName = x.ListName,
                   ListType = x.ListType,
                   Description = x.Description,
                   Status = x.Status,
                   DateCreate = x.DateCreate,
                   UserCreate = x.UserCreate
                }).ToList();
                if (lists == null) return new List<ListModel>();

                return lists;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new List<ListModel>();
            }
        }

        public void UpdateList(ListModel listModel)
        {
            try
            {
                var listItem = _dbContext.Lists.FirstOrDefault(x => x.Id.Equals(listModel.Id));
                listItem.ListCode = listModel.ListCode;
                listItem.ListName = listModel.ListName;
                listItem.ListType = listModel.ListType;
                listItem.Status = listModel.Status;
                listItem.Description = listModel.Description;
                listItem.DateCreate = DateTime.Now;
                listItem.UserCreate = listModel.UserCreate;

                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
    }
}
