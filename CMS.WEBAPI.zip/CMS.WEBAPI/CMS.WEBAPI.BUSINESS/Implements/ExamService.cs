﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class ExamService : IExamService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public ResponseModel CreateExam(ExamModel examModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var examItemExist = _dbContext.Exams.SingleOrDefault(c => c.ExamId.Equals(examModel.ExamId) && c.Status != (int)Status.DELETE);
                if (examItemExist != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var examItem = MapperHelper.Map<Exam, ExamModel>(examModel);
                    _dbContext.Exams.Add(examItem);
                    _dbContext.SaveChanges();

                    //add exam level
                    AddExamLevel(examModel.ExamLevels, examItem.ExamId);
                    //add exam for class
                    var classExam = new ClassExamModel()
                    {
                        ClassCode = examModel.ClassCode,
                        ExamId = examItem.ExamId
                    };
                    if(!String.IsNullOrEmpty(examModel.ClassCode))
                    {
                        AddExamClass(classExam);
                    }
                    _dbContext.SaveChanges();

                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteExam(int id)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var examItem = _dbContext.Exams.SingleOrDefault(c => c.ExamId.Equals(id) && c.Status != (int)Status.DELETE);
                if (examItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    examItem.Status = (int)Status.DELETE;

                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ExamModel GetExamByExamId(int id)
        {
            try
            {
                var examItem = _dbContext.Exams.SingleOrDefault(c => c.ExamId.Equals(id));
                if (examItem == null) return new ExamModel();

                return MapperHelper.Map<ExamModel, Exam>(examItem);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new ExamModel();
            }
        }

        public PagingModel<ExamResponseModel> GetListExams(ExamModel examModel)
        {
            try
            {
                var model = new PagingModel<ExamResponseModel>();
                var query = from e in _dbContext.Exams
                            join ue in _dbContext.UserExams
                            on e.ExamId equals ue.ExamId into ueg
                            from userExam in ueg.DefaultIfEmpty()
                            where (string.IsNullOrEmpty(examModel.ExamName) || e.ExamName.Contains(examModel.ExamName))
                            && (examModel.Status == null || e.Status == examModel.Status)
                            && (string.IsNullOrEmpty(examModel.UserName) || userExam.Username.Equals(examModel.UserName))
                            && (examModel.IsPass == null || (examModel.IsPass == true && userExam.IsPass == true)
                            || (examModel.IsPass == false && (userExam.IsPass == false || userExam.IsPass == null)))
                            && e.Status != (int)Status.DELETE
                            select new ExamResponseModel
                            {
                                ExamName = e.ExamName,
                                ExamId = e.ExamId,
                                UserName = userExam.Username,
                                IsPass = userExam.IsPass,
                                PassPoint = e.PassPoint,
                                Score = userExam.Score,
                                TestTime = e.TestTime,
                                IsMulti = e.IsMulti
                            };

                model.total = query.Count();
                model.page = examModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(examModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.ExamName);

                model.data = query.Select(x => new ExamResponseModel
                {
                    ExamName = x.ExamName,
                    ExamId = x.ExamId,
                    UserName = x.UserName,
                    IsPass = x.IsPass,
                    PassPoint = x.PassPoint,
                    Score = x.Score,
                    TestTime = x.TestTime,
                    IsMulti = x.IsMulti
                }).Skip((examModel.current - 1) * examModel.pageSize).Take(examModel.pageSize).ToList();

                return model;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new PagingModel<ExamResponseModel>();
            }
        }

        public ResponseModel UpdateExam(ExamModel examModel)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var examItem = _dbContext.Exams.SingleOrDefault(c => c.ExamId.Equals(examModel.ExamId) && c.Status != (int)Status.DELETE);
                if (examItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;
                    //update value exam
                    examItem.ExamName = examModel.ExamName;
                    examItem.PassPoint = examModel.PassPoint;
                    examItem.QuestionCateId = examModel.QuestionCateId;
                    examItem.TestTime = examModel.TestTime;
                    examItem.IsMulti = examModel.IsMulti;

                    //delete Exam level
                    var examLevels = _dbContext.ExamLevelMappings.Where(c => c.ExamId.Equals(examModel.ExamId)).ToList();
                    foreach (var item in examLevels)
                    {
                        _dbContext.ExamLevelMappings.Remove(item);
                    }
                    _dbContext.SaveChanges();

                    //add exam level
                    AddExamLevel(examModel.ExamLevels, examItem.ExamId);
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public AnswerResponseModel CalculatorPoint(ExamResultModel model)
        {
            var response = new AnswerResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                response.Success = true;

                //calculator point
                var totalPass = 0;
                foreach (var answer in model.Answers)
                {
                    var check = CheckAnswer(answer);
                    if (check)
                    {
                        totalPass++;
                    }
                }
                var passPoint = 0;
                var exam = _dbContext.Exams.SingleOrDefault(x => x.ExamId.Equals(model.ExamId)); 
                if(exam != null)
                {
                    passPoint = exam.PassPoint;
                }
                 
                var isPass = (totalPass >= passPoint);

                //update user exam
                UpdateUserExam(model.UserId, isPass, totalPass, model.ExamId);
                //save history
                var examHisModel = new ExamHistoryModel
                {
                    ExamId = model.ExamId,
                    PassOrNotPass = isPass,
                    TotalCore = totalPass,
                    UserAnswerKey = model.Answers.ToString(),
                    UserId = model.UserId,
                    CreateDate = DateTime.Now
                };
                SaveHistoryExam(examHisModel);

                //return respon
                var result = new AnswerResultResponseModel()
                {
                    UserId = model.UserId,
                    IsPass = isPass,
                    PassPoint = passPoint,
                    TotalPassQuestion = totalPass,
                    TotalQuestion = model.Answers.Count()
                };
                response.data = result;

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel AddExamForUser(UserExamModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var examItemExist = _dbContext.UserExams.SingleOrDefault(c => c.ExamId.Equals(model.ExamId) && c.Username.Equals(model.UserName.Trim()));
                if (examItemExist != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var examItem = new UserExam()
                    {
                        Username = model.UserName.Trim(),
                        ExamId = model.ExamId,
                        CreateDate = DateTime.Now
                    };
                    _dbContext.UserExams.Add(examItem);
                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel AddExamForClass(ClassExamModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                response.Success = true;
                AddExamClass(model);

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public ResponseModel DeleteExamOfUser(UserExamModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;
                var examItem = _dbContext.UserExams.FirstOrDefault(c => c.ExamId.Equals(model.ExamId) && c.Username.Equals(model.UserName));
                if (examItem == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;
                }
                else
                {
                    response.Success = true;

                    _dbContext.UserExams.Remove(examItem);
                    _dbContext.SaveChanges();
                }

                return response;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public List<QuestionForExamModel> GetQuestionsForExam(int examId)
        {
            var questionModels = new List<QuestionForExamModel>();
            //get list exam level
            var examLevels = _dbContext.ExamLevelMappings.Where(x => x.ExamId.Equals(examId)).ToList();
            var questionCate = _dbContext.Exams.FirstOrDefault(x => x.ExamId.Equals(examId)).QuestionCateId;

            var lstId = questionCate.Split(',').ToList();

            foreach (var item in examLevels)
            {
                if((item.NumOfQuestions ?? 0) > 0)
                {
                    var questions = _dbContext.Questions.Where(x => lstId.Contains(SqlFunctions.StringConvert((double)x.CateId).Trim())
                    && x.Level == item.LevelCode && x.Status != (int)Status.DELETE)
                    .OrderBy(x => Guid.NewGuid()).Take(item.NumOfQuestions ?? 0)
                    .Select(x => new QuestionForExamModel()
                    {
                        Level = x.Level,
                        QuestionId = x.QuestionId,
                        QuestionName = x.QuestionName
                    }).ToList();

                    //get answers
                    foreach (var question in questions)
                    {
                        var answers = _dbContext.Answers.Where(x => x.QuestionId == question.QuestionId && x.Status != (int)Status.DELETE)
                            .OrderBy(x => Guid.NewGuid()).Select(x => new AnswerModel()
                            {
                                AnswerId = x.AnswerId,
                                AnswerName = x.AnswerName,
                                AnswerType = x.AnswerType
                            }).ToList();
                        if (answers != null)
                        {
                            question.Answers = new List<AnswerModel>();

                            question.Answers.AddRange(answers);
                        }
                    }
                    questionModels.AddRange(questions);
                }
                
            }

            return questionModels.OrderBy(x => Guid.NewGuid()).ToList();
        }

        private void SaveHistoryExam(ExamHistoryModel examHistoryModel)
        {
            try
            {
                var examItem = MapperHelper.Map<ExamHistory, ExamHistoryModel>(examHistoryModel);
                _dbContext.ExamHistories.Add(examItem);
                _dbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }
        private bool CheckAnswer(AnswerRequestModel model)
        {
            try
            {

                var countFalse = 1;
                if (model.AnswerIds.Count > 0)
                {
                    var totalRight = _dbContext.Answers.Where(x => x.QuestionId.Equals(model.QuestionId) && x.IsRightAnswer == true).Count();
                    if( totalRight == model.AnswerIds.Count)
                    {
                        countFalse = 0;

                        foreach (var id in model.AnswerIds)
                        {
                            var result = _dbContext.Answers.SingleOrDefault(x => x.QuestionId.Equals(model.QuestionId)
                            && x.AnswerId.Equals(id) && x.IsRightAnswer == true);
                            if (result == null)
                            {
                                countFalse++;
                            }
                        }
                    }
                }

              
                return countFalse == 0;

            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return false;
            }
        }
        private void UpdateUserExam(string userId, bool isPass, int passPoint, int examId)
        {
            try
            {
                var examItem = _dbContext.UserExams.FirstOrDefault(c => c.ExamId.Equals(examId) && c.Username.Equals(userId));
                examItem.IsPass = isPass;
                examItem.Score = passPoint;
                examItem.CreateDate = DateTime.Now;

                _dbContext.SaveChanges();

                //update status user
                if(examId == (int)ExamIdDefault.EXAMID && isPass)
                {
                    var user = _dbContext.Users.SingleOrDefault(c => c.Username.Equals(userId));

                    user.Status = (int)Status.NOT_APPROVE;
                    _dbContext.SaveChanges();
                }


            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

        }

        private void AddExamLevel(List<ExamLevelMappingModel> model, int examId)
        {
            foreach (var item in model)
            {
                var examLevel = new ExamLevelMapping()
                {
                    ExamId = examId,
                    LevelCode = item.LevelCode,
                    NumOfQuestions = item.NumOfQuestions
                };
                _dbContext.ExamLevelMappings.Add(examLevel);
            }
            _dbContext.SaveChanges();
        }
        private void AddExamClass(ClassExamModel model)
        {
            //get list user in class
            var userClasses = _dbContext.StudentClasses.Where(c => c.ClassId.Equals(model.ClassCode) && c.Status != (int)Status.DELETE).ToList();

            //map list user exam
            foreach (var item in userClasses)
            {
                var examItemExist = _dbContext.UserExams.SingleOrDefault(c => c.ExamId.Equals(model.ExamId) && c.Username.Equals(item.StudentId));
                if (examItemExist == null)
                {
                    var examItem = new UserExam()
                    {
                        Username = item.StudentId,
                        ExamId = model.ExamId,
                        CreateDate = DateTime.Now
                    };
                    _dbContext.UserExams.Add(examItem);

                }
            }
            _dbContext.SaveChanges();
        }


    }
}
