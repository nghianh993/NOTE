﻿using CMS.WEBAPI.BASE;
using CMS.WEBAPI.BUSINESS.Helper;
using CMS.WEBAPI.BUSINESS.Interfaces;
using CMS.WEBAPI.BUSINESS.Mappings;
using CMS.WEBAPI.COMMON.Constant;
using CMS.WEBAPI.COMMON.Enum;
using CMS.WEBAPI.MODEL;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Implements
{
    public class TeacherClassService : ITeacherClassService
    {
        private readonly BEDATAEntities _dbContext = new BEDATAEntities();
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public PagingModel<UserModel> GetTeachersNoClass(UserModel userModel)
        {
            var model = new PagingModel<UserModel>();
            try
            {
                var query = from users in _dbContext.Users
                             join s in _dbContext.TeacherClasses on users.Username equals s.Username into user
                             from studentClass in user.DefaultIfEmpty()
                             where users.Status == (int)Status.ACTIVE && users.Type == 2
                             && (userModel.IsArrange != null ? (userModel.IsArrange == 1 ? !string.IsNullOrEmpty(studentClass.ClassCode) : string.IsNullOrEmpty(studentClass.ClassCode)) : "1".Equals("1"))
                             && (string.IsNullOrEmpty(userModel.Username) || users.Username.Contains(userModel.Username))
                             && (string.IsNullOrEmpty(userModel.Fullname) || users.Fullname.Contains(userModel.Fullname))
                             && (userModel.Gender == null || users.Gender.Equals(userModel.Gender))
                             select users;

                model.total = query.Distinct().Count();
                model.page = userModel.current;
                model.success = true;

                //Sorting
                string column = string.Empty; bool sortDes = false;
                Common.GetColumnFilter(userModel.sorter, ref column, ref sortDes);
                query = !string.IsNullOrEmpty(column) ? query.OrderByField(column, sortDes) : query.OrderBy(c => c.Username);

                var dataDistinct = query.Select(p => new UserModel
                {
                    Username = p.Username,
                    Birthday = p.Birthday,
                    Fullname = p.Fullname,
                    Amount = p.Amount,
                    Avatar = p.Avatar,
                    Address = p.Address,
                    ChildrenAccount = p.ChildrenAccount,
                    School = p.School,
                    Status = p.Status,
                    CreatedDate = p.CreatedDate,
                    Gender = p.Gender,
                    Type = p.Type,
                    Title = p.Title,
                    IsParents = p.IsParents,
                    Email = p.Email,
                    Phone = p.Phone,
                    Services = p.Services,
                    UserServices = p.UserServices,
                    IdentityCard = p.IdentityCard,
                    //ClassCode = p.studentClass.ClassCode

                }).Distinct().AsQueryable();

                model.data = dataDistinct.OrderBy(c => c.Username).Skip((userModel.current - 1) * userModel.pageSize).Take(userModel.pageSize).ToList();

                //model.data = model.data.Select(p => new UserModel()
                //{
                //    Username = p.Username,
                //    Birthday = p.Birthday,
                //    Fullname = p.Fullname,
                //    Amount = p.Amount,
                //    Avatar = p.Avatar,
                //    Address = p.Address,
                //    ChildrenAccount = p.ChildrenAccount,
                //    School = p.School,
                //    Status = p.Status,
                //    CreatedDate = p.CreatedDate,
                //    Gender = p.Gender,
                //    Type = p.Type,
                //    Title = p.Title,
                //    IsParents = p.IsParents,
                //    Email = p.Email,
                //    Phone = p.Phone,
                //    Services = p.Services,
                //    UserServices = p.UserServices,
                //    roleIds = GetRole(p.Username),
                //    IdentityCard = p.IdentityCard,
                //    //ClassCode = p.ClassCode

                //}).ToList();
                return model;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new PagingModel<UserModel>();
            }
        }
        public void CreateTeacherClass(TeacherClassModel teacherClassModel)
        {
            try
            {
                var item = MapperHelper.Map<TeacherClass, TeacherClassModel>(teacherClassModel);
                item.DateCreate = DateTime.Now;
                _dbContext.TeacherClasses.Add(item);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public ResponseModel DeleteTeacherClass(TeacherClassModel teacherClassModel)
        {
            var response = new ResponseModel();
            try
            {
                var item = _dbContext.TeacherClasses.FirstOrDefault(x => x.ClassCode.Equals(teacherClassModel.ClassCode)
                && x.Username.Equals(teacherClassModel.Username));
                if(item == null)
                {
                    response.Success = false;
                    response.Message = Message.NOT_EXISTS;

                }
                else
                {
                    response.Success = true;
                    _dbContext.TeacherClasses.Remove(item);
                    _dbContext.SaveChanges();
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }

        public TeacherClassModel GetTeacherClassById(TeacherClassModel teacherClassModel)
        {
            try
            {
                var item = _dbContext.TeacherClasses.SingleOrDefault(c => c.Username.Equals(teacherClassModel.Username) && c.ClassCode.Equals(teacherClassModel.ClassCode));
                if (item == null) return new TeacherClassModel();

                return MapperHelper.Map<TeacherClassModel, TeacherClass>(item);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new TeacherClassModel();
            }
        }
        public TeacherClassModel GetTeacherIdByClassId(TeacherClassModel teacherClassModel)
        {
            try
            {
                var item = _dbContext.TeacherClasses.SingleOrDefault(c => c.ClassCode.Equals(teacherClassModel.ClassCode));
                if (item == null) return new TeacherClassModel();

                return MapperHelper.Map<TeacherClassModel, TeacherClass>(item);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new TeacherClassModel();
            }
        }

        public ResponseModel AddTeacherToClass(TeacherClassModel model)
        {
            var response = new ResponseModel();
            try
            {
                response.StatusCode = (int)HttpStatusCode.SUCCESS;

                var item = _dbContext.TeacherClasses.SingleOrDefault(c => c.ClassCode.Equals(model.ClassCode)
                && c.Username.Equals(model.Username));

                if (item != null)
                {
                    response.Success = false;
                    response.Message = Message.ADD_EXISTS;
                }
                else
                {
                    response.Success = true;
                    var teacherClass = MapperHelper.Map<TeacherClass, TeacherClassModel>(model);
                    _dbContext.TeacherClasses.Add(teacherClass);
                    _dbContext.SaveChanges();

                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.StatusCode = (int)HttpStatusCode.SERVER_ERROR;
                response.Success = false;
                response.Message = Message.SERVER_ERROR;
                return response;
            }
        }
        public List<TeacherClassModel> GetTeacherClasses()
        {
            try
            {
                var lists = _dbContext.TeacherClasses.Select(x => new TeacherClassModel()
                {
                    ClassCode = x.ClassCode,
                    Username = x.Username,
                    IsTeacher = x.IsTeacher,
                    DateCreate = x.DateCreate,
                    UserCreate = x.UserCreate
                }).ToList();
                if (lists == null) return new List<TeacherClassModel>();

                return lists;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new List<TeacherClassModel>();
            }
        }
        #region Help method
        private List<string> GetRole(string username)
        {
            try
            {
                var lstRole = (from a in _dbContext.Users
                               join b in _dbContext.UserRoleMappings on a.Username equals b.Username
                               join c in _dbContext.Roles on b.RoleId equals c.RoleId
                               where c.Status == (int)Status.ACTIVE
                               && a.Username.Equals(username)
                               select c.RoleId).ToList();
                return lstRole;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new List<string>();
            }
        }
        #endregion
    }
}
