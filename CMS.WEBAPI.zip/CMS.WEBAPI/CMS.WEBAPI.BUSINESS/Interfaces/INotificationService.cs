﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface INotificationService
    {
        int SaveNotification(string content, string userCreated, string userReceiver);

        PagingModel<NoticeModel> GetAll(NoticeModel model);

        void PushNotification(string content, string userSend, string userReceiver);

        void PushNotifications(string content, string userSend, string segment);

        void UpdateRead(List<int> messageId);
    }
}
