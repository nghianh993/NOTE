﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IUserClassService
    {
        PagingModel<UserModel> GetUsersNoClass(UserModel userModel);
        PagingModel<UserModel> GetUsersByClassCode(UserModel userModel);
        ResponseModel AddStudentToClass(StudentClassModel model);
        ResponseModel CheckInStudent(CheckInRequestModel model, string teacherId);
        ResponseModel DeleteStudentClass(StudentClassModel studentClassModel);
        string GetCheckInUserByClassCode(StudentClassModel studentClassModel);
    }
}
