﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IExamService
    {
        PagingModel<ExamResponseModel> GetListExams(ExamModel examModel);
        ExamModel GetExamByExamId(int id);
        ResponseModel CreateExam(ExamModel examModel);
        ResponseModel UpdateExam(ExamModel examModel);
        ResponseModel DeleteExam(int id);
        AnswerResponseModel CalculatorPoint(ExamResultModel model);
        ResponseModel AddExamForUser(UserExamModel model);
        ResponseModel AddExamForClass(ClassExamModel model);
        ResponseModel DeleteExamOfUser(UserExamModel model);
        List<QuestionForExamModel> GetQuestionsForExam(int examId);

    }
}
