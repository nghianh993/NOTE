﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IClassService
    {
        PagingModel<ClassModel> GetListClasses(ClassModel classModel);
        ClassModel GetClassByClassCode(string classCode);
        ClassResponseModel CreateClass(ClassModel classModel);
        ResponseModel UpdateClass(ClassModel classModel);
        ResponseModel DeleteClass(ClassModel classModel);
        List<SelectIntCommonModel> GetAllCourse();
        PagingModel<ClassModel> GetListClassesByUserServices(ClassModel classModel);
        PagingModel<ClassModel> GetListClassesNoTeacher(ClassModel classModel);
    }
}
