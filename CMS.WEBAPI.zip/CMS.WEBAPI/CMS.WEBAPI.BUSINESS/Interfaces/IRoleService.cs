﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IRoleService
    {
        PagingModel<RoleModel> GetAllRole(RoleModel model);

        List<PermissionModel> GetFirstNodePermissionByRole(string roleId, string parentId);

        ResponseModel AddRole(RoleModel roleModel);

        ResponseModel UpdateRole(RoleModel roleModel);

        ResponseModel DeleteRole(string roleId);

        ResponseModel LockOrUnlock(List<string> roleIds, int status);

        ResponseModel AddOrRemovePermissionToRole(string permissionId, string roleId, string userCreate, bool isAdd);

        List<MenuModel> GetMenuByUser(string userName);

        List<PermissionModel> GetPermissionByUser(string userName);

        TreeRole GetDataTreeRole(string roleId);

        ResponseModel UpdatePermission(List<string> permissionId, string roleId, string userCreate);
    }
}
