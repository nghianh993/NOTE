﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IQuestionCateService
    {
        PagingModel<CateQuestionModel> GetAll(CateQuestionModel model);

        List<SelectCommonModel> GetAll();

        ResponseModel Add(CateQuestionModel model);

        ResponseModel Update(CateQuestionModel model);

        ResponseModel LockOrUnlock(List<int> ids, int status);
    }
}
