﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IBalanceHistoryService
    {
        PagingModel<BalanceHistoryModel> GetAll(BalanceHistoryModel model);

        ResponseModel Add(BalanceHistoryModel model);
        
        ResponseModel Approve(int id, string currentUser);

        ResponseModel Reject(int id);
    }
}
