﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IExamQuestionMappingService
    {
        ResponseModel CreateExamQuestionMappings(List<int> listQuestionIds, int examId);
        ResponseModel DeleteExamQuestionMappings(List<int> listQuestionIds, int examId);
    }
}
