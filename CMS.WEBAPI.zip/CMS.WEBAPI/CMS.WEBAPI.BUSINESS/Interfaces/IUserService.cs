﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IUserService
    {
        PagingModel<UserModel> GetAllUser(UserModel userModel);

        PagingModel<UserModel> GetAllUserStaff(UserModel userModel);

        ResponseModel Add(UserModel userModel);

        ResponseModel Update(UserModel userModel);

        ResponseModel ChangeInfo(UserModel userModel);

        ResponseModel LockOrUnlock(List<string> userIds, int status);

        List<RoleForUserModel> GetAllRoleActive();

        ResponseModel CheckDuplicateUser(string username);

        List<SelectCommonModel> GetAllChildren(string currentUser);

        UserModel GetDetailUser(string currentUser);

        UserModel GetParentUser(string userGet);

        ResponseModel Cash(CashModel cashModel);

        ResponseModel ChangePassword(ChangePasswordModel changePW);
    }
}
