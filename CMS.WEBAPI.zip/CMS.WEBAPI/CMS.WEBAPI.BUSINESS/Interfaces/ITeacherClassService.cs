﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface ITeacherClassService
    {
        List<TeacherClassModel> GetTeacherClasses();
        TeacherClassModel GetTeacherClassById(TeacherClassModel teacherClassModel);
        void CreateTeacherClass(TeacherClassModel teacherClassModel);
        ResponseModel DeleteTeacherClass(TeacherClassModel teacherClassModel);
        PagingModel<UserModel> GetTeachersNoClass(UserModel userModel);
        ResponseModel AddTeacherToClass(TeacherClassModel model);
        TeacherClassModel GetTeacherIdByClassId(TeacherClassModel teacherClassModel);
    }
}
