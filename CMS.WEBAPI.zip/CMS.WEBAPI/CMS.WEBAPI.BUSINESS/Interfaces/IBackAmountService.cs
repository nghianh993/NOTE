﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IBackAmountService
    {
        PagingModel<BackAmountModel> GetAll(BackAmountModel model);

        ResponseModel Add(BackAmountModel model);

        ResponseModel Update(BackAmountModel model);

        ResponseModel Delete(List<string> ids);
    }
}
