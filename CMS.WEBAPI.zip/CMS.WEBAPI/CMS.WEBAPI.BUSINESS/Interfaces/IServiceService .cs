﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IServiceService
    {
        PagingModel<ServiceModel> GetAll(ServiceModel model);

        ResponseModel Add(ServiceModel model);

        ResponseModel Update(ServiceModel model);

        ResponseModel LockOrUnlock(List<string> ids, int status);

        List<SelectCommonModel> GetAllByType(int type);

        List<ServiceModel> GetAllByTypeV2(int type);
    }
}
