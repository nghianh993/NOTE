﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface ICourseService
    {
        PagingModel<CourseModel> GetListCourses(CourseModel courseModel);
        ResponseModel CreateCourse(CourseModel courseModel);
        ResponseModel UpdateCourse(CourseModel courseModel);
        ResponseModel DeleteCourse(CourseModel courseModel);
        ResponseModel DeleteMultiCourses(List<int> ids);
        ResponseModel LockOrUnlock(List<int> ids, int status);
    }
}
