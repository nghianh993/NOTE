﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface ILoginService
    {
        UserModel GetCurrentUser(string account, string password);

        List<PermissionModel> GetPermissionsByUser(string account);
    }
}
