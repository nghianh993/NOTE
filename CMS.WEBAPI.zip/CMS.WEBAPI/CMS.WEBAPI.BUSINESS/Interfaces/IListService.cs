﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IListService
    {
        List<ListModel> GetLists();
        ListModel GetListById(int id);
        void CreateList(ListModel listModel);
        void UpdateList(ListModel listModel);
        void DeleteList(int id);
    }
}
