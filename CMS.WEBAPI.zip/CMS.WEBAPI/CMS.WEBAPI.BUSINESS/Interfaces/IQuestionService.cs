﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IQuestionService
    {
        PagingModel<QuestionModel> GetAll(QuestionModel model);

        ResponseModel Add(QuestionModel model);

        ResponseModel Update(QuestionModel model);

        ResponseModel LockOrUnlock(List<int> ids, int status);

        Tree GetAllQuestionCate();

        List<BaseObjectModel> GetAllLevel();

        PagingModel<QuestionModel> GetAllQuestionByExamId(QuestionModel questionModel);
    }
}
