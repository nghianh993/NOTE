﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IAnswerService
    {
        PagingModel<AnswerModel> GetAnswerByQuestionId(AnswerModel model);

        ResponseModel Add(AnswerModel model);

        ResponseModel Update(AnswerModel model);

        ResponseModel Delete(int answerId);
    }
}
