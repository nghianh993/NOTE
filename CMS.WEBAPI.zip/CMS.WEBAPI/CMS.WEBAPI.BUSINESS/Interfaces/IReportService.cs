﻿using CMS.WEBAPI.MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Interfaces
{
    public interface IReportService
    {
        DataSet GetReportData(string username, DateTime? fromDate, DateTime? endDate);
        PagingModel<UserModel> GetAllData(UserModel userModel);
        PagingModel<UserReportCreated> GetUserUnder(ReportUserModel model);
    }
}
