﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.EntityClient;
using System.Data.Objects;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Helper
{
    public class Common
    {
        public static void GetColumnFilter(string sort, ref string column, ref bool desending)
        {
            if(!string.IsNullOrEmpty(sort))
            {
                var objSort = sort.Split(',')[0];
                column = objSort.Split(':')[0].ToString();
                desending = objSort.Split(':')[1].Equals("descend") ? true : false;
            }
        }

        public static DataSet ExecuteStoredProcedure(ObjectContext db, string storedProcedureName, IEnumerable<SqlParameter> parameters)
        {
            var connectionString = ((EntityConnection)db.Connection).StoreConnection.ConnectionString;
            var ds = new DataSet();

            using (var conn = new SqlConnection(connectionString))
            {
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = storedProcedureName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (var parameter in parameters)
                    {
                        cmd.Parameters.Add(parameter);
                    }

                    using (var adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }
            }

            return ds;
        }
    }
}
