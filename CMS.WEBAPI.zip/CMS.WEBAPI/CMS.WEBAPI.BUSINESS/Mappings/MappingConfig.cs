﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Mappings
{
    public class MappingConfig : IMapperConfig
    {
        private readonly IMapper mapper;

        public MappingConfig(IMapper mapper)
        {
            this.mapper = mapper;
        }

        public T MapFrom<T>(object entity)
        {
            return mapper.Map<T>(entity);
        }
    }
}
