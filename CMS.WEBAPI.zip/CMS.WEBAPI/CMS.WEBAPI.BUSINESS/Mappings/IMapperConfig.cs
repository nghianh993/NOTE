﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.WEBAPI.BUSINESS.Mappings
{
    public interface IMapperConfig
    {
        T MapFrom<T>(object entity);
    }
}
