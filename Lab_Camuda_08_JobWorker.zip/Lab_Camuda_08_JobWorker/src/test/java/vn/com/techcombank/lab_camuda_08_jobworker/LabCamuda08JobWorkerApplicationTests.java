package vn.com.techcombank.lab_camuda_08_jobworker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabCamuda08JobWorkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
